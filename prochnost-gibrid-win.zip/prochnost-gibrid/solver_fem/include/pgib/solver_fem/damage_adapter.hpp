// pgib/solver_fem/damage_adapter.hpp — переход «элемент решения → замер для
// критериев повреждения», постановка одноосного растяжения и шаг по нагрузке.
//
// Зачем отдельный слой-адаптер: слой failure не имеет права зависеть от
// solver_fem (матрица зависимостей Ф-22), иначе критерии разрушения начнут
// знать про конечные элементы и перестанут быть проверяемыми на аналитике.

#pragma once

#include <array>
#include <cmath>
#include <cstddef>
#include <vector>

#include "pgib/failure/damage.hpp"
#include "pgib/failure/damage_field.hpp"
#include "pgib/solver_fem/mixed_hyperelastic.hpp"
#include "pgib/solver_fem/specimen.hpp"

namespace pgib::sfem {

inline ::pgib::failure::Sample to_sample(const ElementState& st) {
    ::pgib::failure::Sample s;
    s.lambda_max = st.lambda_max;
    s.W = st.W_iso_mean;
    s.hydrostatic_tension = st.hydrostatic_tension;
    return s;
}

inline std::vector<::pgib::failure::Sample> samples_of(const Problem& prob) {
    std::vector<::pgib::failure::Sample> out;
    out.reserve(prob.mesh.element_count());
    for (std::size_t e = 0; e < prob.mesh.element_count(); ++e)
        out.push_back(to_sample(element_state(prob.mesh, e, prob.u, prob.p[e], prob.material, prob.g_of(e))));
    return out;
}

inline std::vector<std::array<double, 3>> centroids_of(const HexMesh& mesh) {
    std::vector<std::array<double, 3>> out;
    out.reserve(mesh.element_count());
    for (std::size_t e = 0; e < mesh.element_count(); ++e) out.push_back(element_centroid(mesh, e));
    return out;
}

// Постановка одноосного растяжения с ПОДВИЖНЫМИ боковыми гранями.
//
// ВАЖНО (ловушка, пойманная при отладке 12.11.2026): если закрепить нижнюю грань
// не только по z, но и по x,y, торец перестаёт сужаться, у него возникает
// трёхосное напряжённое состояние, и «однородный» брус перестаёт быть однородным:
// при приложенном λ = 3,0 максимальное растяжение в элементе выходило 1,76, то есть
// эталон для проверки критериев был бы взят не тот. Поэтому по x,y закрепляется
// только один узел (снятие жёсткого смещения), плюс одна связь от поворота.
inline void setup_uniaxial(Problem& prob, double lz, double lx = 1.0) {
    prob.initialise();
    const double tol = 1e-12;
    for (std::size_t a = 0; a < prob.mesh.node_count(); ++a) {
        const auto& X = prob.mesh.X[a];
        if (X[2] <= tol) prob.fix(prob.dof_u(a, 2), 0.0);                        // низ: u_z = 0
        if (X[2] >= lz - tol) prob.fix(prob.dof_u(a, 2), 0.0);                   // верх: u_z задаётся шагом
        // Снятие жёстких смещений и поворотов, совместимое с однородной деформацией
        const bool origin = X[0] <= tol && X[1] <= tol && X[2] <= tol;
        const bool x_axis = std::fabs(X[0] - lx) <= tol && X[1] <= tol && X[2] <= tol;
        const bool top_origin = X[0] <= tol && X[1] <= tol && X[2] >= lz - tol;
        if (origin) { prob.fix(prob.dof_u(a, 0), 0.0); prob.fix(prob.dof_u(a, 1), 0.0); }
        if (x_axis) prob.fix(prob.dof_u(a, 1), 0.0);
        if (top_origin) { prob.fix(prob.dof_u(a, 0), 0.0); prob.fix(prob.dof_u(a, 1), 0.0); }
    }
}

// Предписанное удлинение: u_z(верх) = (λ − 1)·lz.
inline void set_stretch(Problem& prob, double stretch, double lz) {
    const auto top = nodes_on_plane(prob.mesh, 2, lz, 1e-9);
    for (std::size_t a : top) prob.fix(prob.dof_u(a, 2), (stretch - 1.0) * lz);
}

struct LoadStepReport {
    bool converged = false;
    int iterations = 0;
};

// Шаг по нагрузке с продолжением по решению: стартуем с предыдущего состояния.
// Без продолжения (старт с нуля на каждом шаге) Ньютон на больших растяжениях
// уходит в ветку с отрицательным J.
inline LoadStepReport solve_at_stretch(Problem& prob, double stretch, double lz,
                                       const NewtonOptions& opt = {}) {
    set_stretch(prob, stretch, lz);
    const NewtonReport rep = solve_newton(prob, opt);
    LoadStepReport out;
    out.converged = rep.converged;
    out.iterations = rep.iterations;
    return out;
}

// Реакция ТОЛЬКО по верхней грани (z = lz).
//
// Ловушка: функция reaction() суммирует все закреплённые DOF заданного направления,
// а у образца закреплены ОБА торца — их реакции противоположны и в сумме дают ноль.
// Внешняя сила читается по одной грани (дефект найден при запуске фазового поля
// 12.11.2026: «P = 0,0000» при напряжении 0,3 МПа).
inline double top_reaction(const Problem& prob, double lz) {
    const auto r = global_residual(prob);
    double sum = 0.0;
    for (std::size_t a : nodes_on_plane(prob.mesh, 2, lz, 1e-9)) sum += r[prob.dof_u(a, 2)];
    return sum;
}

// Кадр повреждения из текущего состояния решения.
inline ::pgib::failure::FieldFrame frame_of(const Problem& prob, const ::pgib::failure::Criteria& crit,
                                            int index, double load) {
    return ::pgib::failure::make_frame(index, load, crit, samples_of(prob), centroids_of(prob.mesh));
}

}  // namespace pgib::sfem
