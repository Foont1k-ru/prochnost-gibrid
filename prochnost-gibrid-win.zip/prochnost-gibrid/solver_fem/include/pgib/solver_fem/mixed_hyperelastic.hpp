// pgib/solver_fem/mixed_hyperelastic.hpp — нелинейная смешанная u/P-формулировка
// для почти несжимаемых тел, Hex8, полная лагранжева постановка.
//
// Закрывает (первый, проверяемый на аналитике шаг):
//   Ф-38  — смешанная u/P с конденсацией давления на уровне элемента
//           (постоянное давление в элементе — аналог KEYOPT(6)=1);
//   Ф-40  — работоспособность при ν → 0,49995 без запирания;
//   Ф-41  — используется РЕАЛЬНЫЙ объёмный модуль K, никакого занижения;
//   НФ-33 — изохорная сверхупругая часть (нео-Гук, Йео) собственной реализацией;
//   Ф-58  — поля λ_max, объёмной деформации, плотности энергии.
//
// ЧТО ЭТО НЕ ТАК:
//   * касательная матрица — ЧИСЛЕННАЯ (A-18): корректно, но дорого; аналитическая
//     появится до целевых 280 тыс. DOF (Э3);
//   * линейная алгебра — плотное LU: только для малых моделей и верификации;
//     MUMPS/AMGCL подключаются в Э3 (список S-5, R-07);
//   * элементов Tet10, контакта и адаптации здесь нет.
//
// Формулировка (Bonet & Wood, mixed u/p; Q1P0):
//   Π = ∫ W_iso(Ī1) dV + ∫ p (J-1) dV - ∫ p²/(2K) dV,   Ī1 = J^(-2/3) I1
//   R_u = ∫ [P_dev + p·J·F^(-T)] : ∇δu dV
//   R_p = ∫ [(J-1) - p/K] dV                     (по элементу, p постоянно)

#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdio>
#include <vector>

#include "pgib/units.hpp"

namespace pgib::sfem {

// ---------------------------------------------------------------------------
// Малая линейная алгебра 3×3
// ---------------------------------------------------------------------------
struct Mat3 {
    double m[3][3]{};

    static Mat3 identity() {
        Mat3 r;
        r.m[0][0] = r.m[1][1] = r.m[2][2] = 1.0;
        return r;
    }
};

inline Mat3 operator*(const Mat3& a, const Mat3& b) {
    Mat3 r;
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j) {
            double s = 0.0;
            for (int k = 0; k < 3; ++k) s += a.m[i][k] * b.m[k][j];
            r.m[i][j] = s;
        }
    return r;
}

inline double det(const Mat3& a) {
    return a.m[0][0] * (a.m[1][1] * a.m[2][2] - a.m[1][2] * a.m[2][1]) -
           a.m[0][1] * (a.m[1][0] * a.m[2][2] - a.m[1][2] * a.m[2][0]) +
           a.m[0][2] * (a.m[1][0] * a.m[2][1] - a.m[1][1] * a.m[2][0]);
}

inline Mat3 inverse(const Mat3& a) {
    const double d = det(a);
    Mat3 r;
    r.m[0][0] = (a.m[1][1] * a.m[2][2] - a.m[1][2] * a.m[2][1]) / d;
    r.m[0][1] = (a.m[0][2] * a.m[2][1] - a.m[0][1] * a.m[2][2]) / d;
    r.m[0][2] = (a.m[0][1] * a.m[1][2] - a.m[0][2] * a.m[1][1]) / d;
    r.m[1][0] = (a.m[1][2] * a.m[2][0] - a.m[1][0] * a.m[2][2]) / d;
    r.m[1][1] = (a.m[0][0] * a.m[2][2] - a.m[0][2] * a.m[2][0]) / d;
    r.m[1][2] = (a.m[0][2] * a.m[1][0] - a.m[0][0] * a.m[1][2]) / d;
    r.m[2][0] = (a.m[1][0] * a.m[2][1] - a.m[1][1] * a.m[2][0]) / d;
    r.m[2][1] = (a.m[0][1] * a.m[2][0] - a.m[0][0] * a.m[2][1]) / d;
    r.m[2][2] = (a.m[0][0] * a.m[1][1] - a.m[0][1] * a.m[1][0]) / d;
    return r;
}

inline Mat3 transpose(const Mat3& a) {
    Mat3 r;
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j) r.m[i][j] = a.m[j][i];
    return r;
}

inline double trace(const Mat3& a) { return a.m[0][0] + a.m[1][1] + a.m[2][2]; }

// Собственные числа симметричной 3×3 (тригонометрический метод Кардано).
// Возвращаются в порядке возрастания — нужно для λ_max (главное растяжение).
inline std::array<double, 3> eigenvalues_sym(const Mat3& a) {
    const double p1 = a.m[0][1] * a.m[0][1] + a.m[0][2] * a.m[0][2] + a.m[1][2] * a.m[1][2];
    std::array<double, 3> out{};
    if (p1 == 0.0) {  // уже диагональная
        out = {a.m[0][0], a.m[1][1], a.m[2][2]};
    } else {
        const double q = trace(a) / 3.0;
        const double p2 = (a.m[0][0] - q) * (a.m[0][0] - q) + (a.m[1][1] - q) * (a.m[1][1] - q) +
                          (a.m[2][2] - q) * (a.m[2][2] - q) + 2.0 * p1;
        const double p = std::sqrt(p2 / 6.0);
        Mat3 b;
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j) b.m[i][j] = (a.m[i][j] - (i == j ? q : 0.0)) / p;
        double r = det(b) / 2.0;
        r = std::clamp(r, -1.0, 1.0);
        constexpr double kTwoPi = 6.283185307179586476925286766559;
        const double phi = std::acos(r) / 3.0;
        const double e1 = q + 2.0 * p * std::cos(phi);
        const double e3 = q + 2.0 * p * std::cos(phi + kTwoPi / 3.0);
        out = {e1, 3.0 * q - e1 - e3, e3};  // через след восстанавливаем среднее
        std::sort(out.begin(), out.end());
    }
    std::sort(out.begin(), out.end());
    return out;
}

// ---------------------------------------------------------------------------
// Изохорная часть сверхупругого потенциала
// ---------------------------------------------------------------------------
// W_iso(Ī1) = Σ C_i0 (Ī1 - 3)^i,  Ī1 = J^(-2/3) I1
// Нео-Гук:      C10 = μ/2, остальные 0
// Йео:          C10, C20, C30 — из карточки материала
struct IsochoricYeoh {
    double C10 = 0.0;
    double C20 = 0.0;
    double C30 = 0.0;

    [[nodiscard]] double energy(double I1bar) const {
        const double x = I1bar - 3.0;
        return C10 * x + C20 * x * x + C30 * x * x * x;
    }
    [[nodiscard]] double d_energy(double I1bar) const {
        const double x = I1bar - 3.0;
        return C10 + 2.0 * C20 * x + 3.0 * C30 * x * x;
    }
    // Начальный модуль сдвига μ0 = 2·C10 (соотношение Ф-29).
    [[nodiscard]] double mu0() const { return 2.0 * C10; }
};

inline IsochoricYeoh neo_hookean(double mu) { return IsochoricYeoh{mu / 2.0, 0.0, 0.0}; }

// ---------------------------------------------------------------------------
// Сетка из гексаэдров на прямоугольном блоке
// ---------------------------------------------------------------------------
struct HexMesh {
    std::vector<std::array<double, 3>> X;         // координаты узлов
    std::vector<std::array<int, 8>> conn;         // порядок: обход снизу, затем сверху
    int nx = 0, ny = 0, nz = 0;

    [[nodiscard]] std::size_t node_count() const { return X.size(); }
    [[nodiscard]] std::size_t element_count() const { return conn.size(); }
};

inline HexMesh make_box(int nx, int ny, int nz, double lx, double ly, double lz) {
    HexMesh m;
    m.nx = nx; m.ny = ny; m.nz = nz;
    auto node = [&](int i, int j, int k) { return i + (nx + 1) * (j + (ny + 1) * k); };
    m.X.resize(static_cast<std::size_t>(nx + 1) * (ny + 1) * (nz + 1));
    for (int k = 0; k <= nz; ++k)
        for (int j = 0; j <= ny; ++j)
            for (int i = 0; i <= nx; ++i) {
                const std::size_t id = static_cast<std::size_t>(node(i, j, k));
                m.X[id] = {lx * i / nx, ly * j / ny, lz * k / nz};
            }
    m.conn.reserve(static_cast<std::size_t>(nx) * ny * nz);
    for (int k = 0; k < nz; ++k)
        for (int j = 0; j < ny; ++j)
            for (int i = 0; i < nx; ++i) {
                m.conn.push_back({node(i, j, k), node(i + 1, j, k), node(i + 1, j + 1, k),
                                  node(i, j + 1, k), node(i, j, k + 1), node(i + 1, j, k + 1),
                                  node(i + 1, j + 1, k + 1), node(i, j + 1, k + 1)});
            }
    return m;
}

// ---------------------------------------------------------------------------
// Функции формы Hex8 и точки интегрирования 2×2×2
// ---------------------------------------------------------------------------
inline void shape_hex8(double xi, double eta, double zeta, double N[8], double dN[8][3]) {
    static const double s[8][3] = {{-1, -1, -1}, {1, -1, -1}, {1, 1, -1}, {-1, 1, -1},
                                   {-1, -1, 1},  {1, -1, 1},  {1, 1, 1},  {-1, 1, 1}};
    for (int a = 0; a < 8; ++a) {
        const double xa = s[a][0], ya = s[a][1], za = s[a][2];
        N[a] = 0.125 * (1 + xi * xa) * (1 + eta * ya) * (1 + zeta * za);
        dN[a][0] = 0.125 * xa * (1 + eta * ya) * (1 + zeta * za);
        dN[a][1] = 0.125 * ya * (1 + xi * xa) * (1 + zeta * za);
        dN[a][2] = 0.125 * za * (1 + xi * xa) * (1 + eta * ya);
    }
}

struct GaussPoint {
    double xi, eta, zeta, w;
};

inline const std::array<GaussPoint, 8>& gauss_2x2x2() {
    static const double g = 1.0 / std::sqrt(3.0);
    static const std::array<GaussPoint, 8> gp{{{g, g, g, 1.0}, {-g, g, g, 1.0}, {g, -g, g, 1.0}, {-g, -g, g, 1.0},
                                               {g, g, -g, 1.0}, {-g, g, -g, 1.0}, {g, -g, -g, 1.0}, {-g, -g, -g, 1.0}}};
    return gp;
}

// ---------------------------------------------------------------------------
// Результат по элементу
// ---------------------------------------------------------------------------
struct ElementState {
    double r_u[24]{};   // невязка по перемещениям
    double r_p = 0.0;   // невязка по давлению
    double volume0 = 0.0;
    double J_mean = 0.0;
    double pressure = 0.0;      // p, МПа
    double W_iso_mean = 0.0;    // плотность энергии, МПа
    double lambda_max = 1.0;    // наибольшее главное растяжение
    Mat3 F_mean{};              // средний градиент деформации
    Mat3 sigma{};               // среднее напряжение Коши, МПа
    double hydrostatic_tension = 0.0;  // +tr(σ)/3, МПа (положительно при растяжении)
    // Ψ⁺ — движущая сила фазового поля (В-10): изохорная энергия там, где материал
    // растянут (tr σ > 0). Это ГИБРИДНАЯ формулировка (Ambati), без разбиения на
    // Ψ⁺/Ψ⁻ по главным удлинениям. Разбиение Miehe здесь неприменимо «наполовину»:
    // если отбросить вклады поперечного сжатия, но оставить их в материале, энергия
    // завышается (проверено: 0,0611 против 0,00225 МПа при λ = 1,025). Полное
    // разбиение с деградацией только Ψ⁺ — следующий шаг (A-28).
    double W_tensile = 0.0;            // МПа (движущая сила, см. A-28)
};

// Тип матрицы: K (объёмный модуль) в МПа, единицы согласованы (A-01).
struct Material {
    IsochoricYeoh iso;
    double K = 0.0;  // объёмный модуль, МПа — РЕАЛЬНЫЙ, без занижения (Ф-41)
};

// Вычисление невязки одного элемента.
// u — вектор перемещений (все узлы), p_e — давление элемента.
// degradation — множитель g = (1−d)² + k для изохорной части (фазовое поле, В-10).
// По умолчанию 1,0, поэтому все прежние вызовы и тесты работают без изменений.
inline ElementState element_state(const HexMesh& mesh, std::size_t e,
                                  const std::vector<std::array<double, 3>>& u, double p_e,
                                  const Material& mat, double degradation = 1.0) {
    ElementState st;
    const auto& cn = mesh.conn[e];

    // Градиенты функций формы в начальной конфигурации (для каждого узла)
    static thread_local std::array<std::array<double, 3>, 8> dN_dX;
    std::array<double, 8> N;

    for (const auto& gp : gauss_2x2x2()) {
        double dN[8][3];
        shape_hex8(gp.xi, gp.eta, gp.zeta, N.data(), dN);

        // Якобиан отображения «эталон → начальная конфигурация»
        Mat3 J0;
        for (int a = 0; a < 8; ++a)
            for (int i = 0; i < 3; ++i)
                for (int j = 0; j < 3; ++j) J0.m[i][j] += mesh.X[cn[a]][j] * dN[a][i];
        const double detJ0 = det(J0);
        const Mat3 J0inv = inverse(J0);

        // dN/dX = J0^(-T) · dN/dξ
        for (int a = 0; a < 8; ++a) {
            for (int i = 0; i < 3; ++i) {
                double s = 0.0;
                for (int j = 0; j < 3; ++j) s += J0inv.m[j][i] * dN[a][j];
                dN_dX[a][i] = s;
            }
        }
        const double w = gp.w * detJ0;
        st.volume0 += w;

        // Градиент деформации F = I + Σ u_a ⊗ dN_a/dX
        Mat3 F = Mat3::identity();
        for (int a = 0; a < 8; ++a)
            for (int i = 0; i < 3; ++i)
                for (int j = 0; j < 3; ++j) F.m[i][j] += u[cn[a]][i] * dN_dX[a][j];

        const double J = det(F);
        const Mat3 Finv = inverse(F);
        const Mat3 FinvT = transpose(Finv);

        // I1 и изохорный инвариант
        const Mat3 C = transpose(F) * F;
        const double I1 = trace(C);
        const double Jm23 = std::pow(J, -2.0 / 3.0);
        const double I1bar = Jm23 * I1;

        const double f1 = mat.iso.d_energy(I1bar);
        st.W_iso_mean += mat.iso.energy(I1bar) * w;

        // P_dev = f'(Ī1) · J^(-2/3) · [2F − (2/3)·I1·F^(-T)]
        Mat3 Pdev;
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j)
                Pdev.m[i][j] = f1 * Jm23 * (2.0 * F.m[i][j] - (2.0 / 3.0) * I1 * FinvT.m[i][j]);

        // P = g·P_dev + p·J·F^(-T): деградирует только изохорная (сдвиговая) часть.
        // Объёмная часть не деградируется намеренно — иначе при J ≠ 1 повреждение
        // «размягчало» бы и объёмный отклик, и u/P-формулировка теряла бы смысл.
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j) Pdev.m[i][j] *= degradation;
        Mat3 P = Pdev;
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j) P.m[i][j] += p_e * J * FinvT.m[i][j];

        // Невязка по перемещениям
        for (int a = 0; a < 8; ++a)
            for (int i = 0; i < 3; ++i) {
                double s = 0.0;
                for (int j = 0; j < 3; ++j) s += P.m[i][j] * dN_dX[a][j];
                st.r_u[a * 3 + i] += s * w;
            }

        st.r_p += (J - 1.0) * w;  // вторая часть (−p/K·V0) добавляется после цикла

        // Постобработка: накопление средних величин
        st.J_mean += J * w;
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j) st.F_mean.m[i][j] += F.m[i][j] * w;
        // σ = (1/J)·P·Fᵀ
        const Mat3 PFt = P * transpose(F);
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j) st.sigma.m[i][j] += PFt.m[i][j] / J * w;

        // Ψ⁺: вклады растягивающих главных удлинений, только при общем растяжении
        // (tr σ > 0). Без этого условия повреждение росло бы и при сжатии, где
        // поперечные удлинения формально положительны, — физически это неверно.
        {
            const double tr_sigma_gp = trace(PFt) / J;
            if (tr_sigma_gp > 0.0) st.W_tensile += mat.iso.energy(I1bar) * w;
        }
    }

    const double V0 = st.volume0;
    st.W_tensile /= V0;
    st.W_iso_mean /= V0;
    st.J_mean /= V0;
    for (auto& row : st.F_mean.m)
        for (double& v : row) v /= V0;
    for (auto& row : st.sigma.m)
        for (double& v : row) v /= V0;

    st.r_p = st.r_p - p_e * V0 / mat.K;  // условие p = K·(J−1) в среднем по элементу
    st.pressure = p_e;
    // Растяжение положительно (как и σ), поэтому гидростатическое растяжение
    // это +tr(σ)/3. Для критерия кавитации ПС-2 нужен именно знак растяжения.
    st.hydrostatic_tension = trace(st.sigma) / 3.0;

    // λ_max — корень наибольшего собственного числа C = Fᵀ F
    const Mat3 Cm = transpose(st.F_mean) * st.F_mean;
    const auto ev = eigenvalues_sym(Cm);
    st.lambda_max = std::sqrt(std::max(ev[2], 0.0));
    return st;
}

// ---------------------------------------------------------------------------
// Задача: сетка + материал + граничные условия + решение
// ---------------------------------------------------------------------------
struct Problem {
    HexMesh mesh;
    Material material;
    std::vector<std::array<double, 3>> u;   // перемещения узлов
    std::vector<double> p;                  // давление по элементам
    std::vector<char> fixed;                // 1 — степень свободы закреплена
    std::vector<double> prescribed;         // предписанное значение закреплённой DOF
    // Повреждение фазового поля (В-10): g_e = (1−d_e)² + k. Пустой массив = без
    // повреждения (g = 1), поэтому старые расчёты не меняются.
    std::vector<double> degradation;

    [[nodiscard]] double g_of(std::size_t e) const {
        return (e < degradation.size()) ? degradation[e] : 1.0;
    }

    void initialise() {
        u.assign(mesh.node_count(), {0.0, 0.0, 0.0});
        p.assign(mesh.element_count(), 0.0);
        fixed.assign(dof_count(), 0);
        prescribed.assign(dof_count(), 0.0);
    }
    [[nodiscard]] std::size_t dof_count() const {
        return mesh.node_count() * 3 + mesh.element_count();
    }
    // Индекс DOF: перемещения узла a по направлению i
    [[nodiscard]] std::size_t dof_u(std::size_t a, int i) const { return a * 3 + static_cast<std::size_t>(i); }
    [[nodiscard]] std::size_t dof_p(std::size_t e) const { return mesh.node_count() * 3 + e; }

    void fix(std::size_t dof, double value) {
        fixed[dof] = 1;
        prescribed[dof] = value;
        // Записываем предписанное значение в текущее решение
        if (dof < mesh.node_count() * 3) {
            const std::size_t a = dof / 3;
            u[a][dof % 3] = value;
        } else {
            p[dof - mesh.node_count() * 3] = value;
        }
    }
};

struct NewtonOptions {
    int max_iterations = 50;
    double tolerance = 1e-10;   // относительная норма невязки
    int max_line_search = 8;
    bool verbose = false;
};

struct NewtonReport {
    bool converged = false;
    int iterations = 0;
    double residual_initial = 0.0;
    double residual_final = 0.0;
};

// Глобальная невязка (внутренние силы; внешних нагрузок в этой версии нет).
inline std::vector<double> global_residual(const Problem& prob) {
    std::vector<double> r(prob.dof_count(), 0.0);
    for (std::size_t e = 0; e < prob.mesh.element_count(); ++e) {
        const auto st = element_state(prob.mesh, e, prob.u, prob.p[e], prob.material, prob.g_of(e));
        for (int a = 0; a < 8; ++a) {
            const std::size_t node = static_cast<std::size_t>(prob.mesh.conn[e][a]);
            for (int i = 0; i < 3; ++i) r[prob.dof_u(node, i)] += st.r_u[a * 3 + i];
        }
        r[prob.dof_p(e)] += st.r_p;
    }
    return r;
}

inline double norm2(const std::vector<double>& v) {
    double s = 0.0;
    for (double x : v) s += x * x;
    return std::sqrt(s);
}

// Норма невязки только по свободным DOF: на закреплённых узлах невязка —
// это реакция, и она не должна стремиться к нулю (иначе сходимость недостижима).
inline double norm_free(const std::vector<double>& r, const std::vector<std::size_t>& free_dof) {
    double s = 0.0;
    for (std::size_t d : free_dof) s += r[d] * r[d];
    return std::sqrt(s);
}

// Плотное LU-разложение с выбором главного элемента (для малых систем).
inline bool solve_dense(std::vector<double>& A, std::vector<double>& b, int n) {
    for (int col = 0; col < n; ++col) {
        int piv = col;
        double best = std::fabs(A[static_cast<std::size_t>(col) * n + col]);
        for (int row = col + 1; row < n; ++row) {
            const double v = std::fabs(A[static_cast<std::size_t>(row) * n + col]);
            if (v > best) { best = v; piv = row; }
        }
        if (best < 1e-300) return false;  // вырожденная матрица (недостаток закреплений)
        if (piv != col) {
            for (int j = 0; j < n; ++j)
                std::swap(A[static_cast<std::size_t>(col) * n + j], A[static_cast<std::size_t>(piv) * n + j]);
            std::swap(b[static_cast<std::size_t>(col)], b[static_cast<std::size_t>(piv)]);
        }
        const double d = A[static_cast<std::size_t>(col) * n + col];
        for (int row = col + 1; row < n; ++row) {
            const double f = A[static_cast<std::size_t>(row) * n + col] / d;
            if (f == 0.0) continue;
            for (int j = col; j < n; ++j)
                A[static_cast<std::size_t>(row) * n + j] -= f * A[static_cast<std::size_t>(col) * n + j];
            b[static_cast<std::size_t>(row)] -= f * b[static_cast<std::size_t>(col)];
        }
    }
    for (int row = n - 1; row >= 0; --row) {
        double s = b[static_cast<std::size_t>(row)];
        for (int j = row + 1; j < n; ++j) s -= A[static_cast<std::size_t>(row) * n + j] * b[static_cast<std::size_t>(j)];
        b[static_cast<std::size_t>(row)] = s / A[static_cast<std::size_t>(row) * n + row];
    }
    return true;
}

// Численная касательная по свободным DOF (A-18).
inline void assemble_tangent(const Problem& prob, const std::vector<std::size_t>& free_dof,
                             std::vector<double>& K) {
    const int nf = static_cast<int>(free_dof.size());
    K.assign(static_cast<std::size_t>(nf) * nf, 0.0);
    std::vector<int> local_of(prob.dof_count(), -1);
    for (int k = 0; k < nf; ++k) local_of[free_dof[static_cast<std::size_t>(k)]] = k;

    // Индексы свободных DOF, влияющих на элемент
    std::vector<std::size_t> elem_dofs;
    for (std::size_t e = 0; e < prob.mesh.element_count(); ++e) {
        elem_dofs.clear();
        for (int a = 0; a < 8; ++a) {
            const std::size_t node = static_cast<std::size_t>(prob.mesh.conn[e][a]);
            for (int i = 0; i < 3; ++i) {
                const std::size_t d = prob.dof_u(node, i);
                if (local_of[d] >= 0) elem_dofs.push_back(d);
            }
        }
        const std::size_t dp = prob.dof_p(e);
        if (local_of[dp] >= 0) elem_dofs.push_back(dp);

        const std::size_t m = elem_dofs.size();
        if (m == 0) continue;

        // Базовая невязка элемента и производные по каждому его свободному DOF
        const auto base = element_state(prob.mesh, e, prob.u, prob.p[e], prob.material, prob.g_of(e));
        std::vector<double> cols(m * 25, 0.0);
        for (std::size_t c = 0; c < m; ++c) {
            const std::size_t d = elem_dofs[c];
            Problem perturbed = prob;  // копия: изменяем одно значение
            double h = 0.0;
            if (d < prob.mesh.node_count() * 3) {
                const std::size_t node = d / 3;
                const int comp = static_cast<int>(d % 3);
                const double ref = prob.u[node][comp];
                h = 1e-8 * std::max(1.0, std::fabs(ref));
                perturbed.u[node][comp] = ref + h;
            } else {
                const std::size_t eid = d - prob.mesh.node_count() * 3;
                const double ref = prob.p[eid];
                h = 1e-8 * std::max(1.0, std::fabs(ref));
                perturbed.p[eid] = ref + h;
            }
            const auto st = element_state(perturbed.mesh, e, perturbed.u, perturbed.p[e], perturbed.material, perturbed.g_of(e));
            for (int a = 0; a < 8; ++a)
                for (int i = 0; i < 3; ++i)
                    cols[c * 25 + static_cast<std::size_t>(a * 3 + i)] = (st.r_u[a * 3 + i] - base.r_u[a * 3 + i]) / h;
            cols[c * 25 + 24] = (st.r_p - base.r_p) / h;
        }

        // Сборка: строка — уравнение элемента, столбец — производная по DOF
        for (int a = 0; a < 8; ++a) {
            const std::size_t node = static_cast<std::size_t>(prob.mesh.conn[e][a]);
            for (int i = 0; i < 3; ++i) {
                const std::size_t row_dof = prob.dof_u(node, i);
                const int r = local_of[row_dof];
                if (r < 0) continue;
                const std::size_t local_row = static_cast<std::size_t>(a * 3 + i);
                for (std::size_t c = 0; c < m; ++c) {
                    K[static_cast<std::size_t>(r) * nf + local_of[elem_dofs[c]]] += cols[c * 25 + local_row];
                }
            }
        }
        const int rp = local_of[dp];
        if (rp >= 0) {
            for (std::size_t c = 0; c < m; ++c)
                K[static_cast<std::size_t>(rp) * nf + local_of[elem_dofs[c]]] += cols[c * 25 + 24];
        }
    }
}

// Применение обновления к свободным DOF
inline void apply_delta(Problem& prob, const std::vector<std::size_t>& free_dof,
                        const std::vector<double>& delta, double scale) {
    for (std::size_t k = 0; k < free_dof.size(); ++k) {
        const std::size_t d = free_dof[k];
        const double v = delta[k] * scale;
        if (d < prob.mesh.node_count() * 3) {
            prob.u[d / 3][d % 3] += v;
        } else {
            prob.p[d - prob.mesh.node_count() * 3] += v;
        }
    }
}

// Решение Ньютоном с простым возвратом (line search) по норме невязки.
inline NewtonReport solve_newton(Problem& prob, const NewtonOptions& opt = {}) {
    NewtonReport rep;
    std::vector<std::size_t> free_dof;
    for (std::size_t d = 0; d < prob.dof_count(); ++d)
        if (!prob.fixed[d]) free_dof.push_back(d);
    if (free_dof.empty()) {
        rep.converged = true;
        return rep;
    }

    auto r = global_residual(prob);
    double r0 = norm_free(r, free_dof);
    if (r0 == 0.0) r0 = 1.0;
    rep.residual_initial = r0;
    if (r0 <= opt.tolerance) {
        rep.converged = true;
        rep.residual_final = 0.0;
        return rep;
    }

    for (int it = 0; it < opt.max_iterations; ++it) {
        rep.iterations = it + 1;
        // Собираем касательную и правую часть −R_free
        std::vector<double> K;
        assemble_tangent(prob, free_dof, K);
        std::vector<double> rhs(free_dof.size());
        for (std::size_t k = 0; k < free_dof.size(); ++k) rhs[k] = -r[free_dof[k]];

        if (!solve_dense(K, rhs, static_cast<int>(free_dof.size()))) {
            if (opt.verbose) std::printf("    Ньютон: вырожденная касательная матрица (не хватает закреплений)\n");
            break;
        }

        // Возврат по норме невязки
        double scale = 1.0;
        // Возврат по норме невязки на свободных DOF
        double norm_current = norm_free(r, free_dof);
        bool accepted = false;
        for (int ls = 0; ls < opt.max_line_search; ++ls) {
            Problem trial = prob;
            apply_delta(trial, free_dof, rhs, scale);
            const auto r_trial = global_residual(trial);
            if (norm_free(r_trial, free_dof) < norm_current) {
                prob = trial;
                accepted = true;
                break;
            }
            scale *= 0.5;
        }
        if (!accepted && opt.verbose) std::printf("    Ньютон: шаг не уменьшил невязку\n");

        r = global_residual(prob);  // невязка строго по принятому состоянию
        const double rn = norm_free(r, free_dof);
        if (opt.verbose) std::printf("    итерация %2d: невязка %.3e (%.2e отн.)\n", it + 1, rn, rn / r0);
        if (rn <= opt.tolerance * r0) {
            rep.converged = true;
            break;
        }
    }
    rep.residual_final = norm_free(global_residual(prob), free_dof);
    rep.residual_initial = r0;
    return rep;
}

// Суммарная реакция по направлению (используется в верификации: сумма невязок
// на закреплённых DOF равна внешней силе).
inline double reaction(const Problem& prob, int direction) {
    const auto r = global_residual(prob);
    double sum = 0.0;
    for (std::size_t d = 0; d < prob.mesh.node_count() * 3; ++d)
        if (prob.fixed[d] && static_cast<int>(d % 3) == direction) sum += r[d];
    return sum;
}

}  // namespace pgib::sfem
