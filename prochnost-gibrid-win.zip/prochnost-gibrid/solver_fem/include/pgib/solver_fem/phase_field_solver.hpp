// pgib/solver_fem/phase_field_solver.hpp — дискретизация фазового поля и
// стаггер-схема «перемещения ↔ повреждение» (В-10).
//
// Поле повреждения d — узловое (1 DOF на узел), поэтому трещина получается
// гладкой полосой шириной ~l_c и НЕ зависит от того, как сетка совпала с её
// берегами. Узлы не удаляются, масса не теряется — требование Ф-50 соблюдено.
//
// Схема (стаггер):
//   1. решаем u/P при текущей деградации g_e = (1−d_e)² + k;
//   2. обновляем историю H = max(H, Ψ⁺) — движущая сила не убывает при разгрузке;
//   3. решаем линейную задачу по d:  ∫[(G_c/l_c + 2H)·N_a·N_b + G_c·l_c·∇N_a·∇N_b]·d
//                                   = ∫ 2H·N_a                       (AT2);
//   4. накладываем необратимость d ≥ d_prev и 0 ≤ d ≤ 1;
//   5. повторяем, пока max|Δd| не станет меньше допуска.

#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <vector>

#include "pgib/failure/phase_field.hpp"
#include "pgib/solver_fem/mixed_hyperelastic.hpp"

namespace pgib::sfem {

struct PhaseFieldState {
    std::vector<double> d;       // текущее повреждение по узлам
    std::vector<double> d_prev;  // накопленное (необратимое)
    std::vector<double> H;       // история Ψ⁺ по элементам, МПа
    // Энергия разрушения по элементам. Нужна для НАЧАЛЬНОЙ НЕОДНОРОДНОСТИ:
    // при идеально однородном материале и однородном растяжении однородная ветка
    // повреждения остаётся равновесной, и трещина не зарождается вообще (проверено
    // 12.11.2026: три сетки дали побитово одинаковый результат без локализации).
    // Пустой массив = одинаковая G_c по всему телу.
    std::vector<double> Gc;
};

inline void phase_field_init(Problem& prob, PhaseFieldState& st) {
    st.d.assign(prob.mesh.node_count(), 0.0);
    st.d_prev.assign(prob.mesh.node_count(), 0.0);
    st.H.assign(prob.mesh.element_count(), 0.0);
    prob.degradation.assign(prob.mesh.element_count(), 1.0);
}

// Начальная неоднородность: G_c ослаблена в полосе элементов (доля от номинала).
// Это не «подгонка», а объявленное допущение A-29: реальная резина неоднородна
// (колебания степени вулканизации, включения), и именно неоднородность выбирает
// место зарождения трещины. Без неё однородное решение формально устойчиво.
inline void phase_field_set_weakened_band(PhaseFieldState& st, double G_c, std::size_t count, double factor,
                                          std::size_t start = 0) {
    st.Gc.assign(count, G_c);
    for (std::size_t e = start; e < st.Gc.size(); ++e) st.Gc[e] = G_c * factor;
}

// Обновление истории по текущему решению: H_e = max(H_e, Ψ⁺_e).
inline void phase_field_update_history(const Problem& prob, PhaseFieldState& st) {
    for (std::size_t e = 0; e < prob.mesh.element_count(); ++e) {
        const auto es = element_state(prob.mesh, e, prob.u, prob.p[e], prob.material, prob.g_of(e));
        st.H[e] = std::max(st.H[e], es.W_tensile);
    }
}

// Решение задачи по d. Возвращает max|Δd| по узлам (критерий сходимости стаггера).
inline double phase_field_solve(const Problem& prob, const failure::PhaseFieldParams& pf, PhaseFieldState& st) {
    const HexMesh& m = prob.mesh;
    const std::size_t n = m.node_count();
    std::vector<double> A(n * n, 0.0), b(n, 0.0);
    std::vector<double> N(8);
    std::array<std::array<double, 3>, 8> dN_dX{};

    for (std::size_t e = 0; e < m.element_count(); ++e) {
        const auto& cn = m.conn[e];
        const double H = st.H[e];
        const double Gc = st.Gc.empty() ? pf.G_c : st.Gc[e];
        for (const auto& gp : gauss_2x2x2()) {
            double dN[8][3];
            shape_hex8(gp.xi, gp.eta, gp.zeta, N.data(), dN);

            Mat3 J0;
            for (int a = 0; a < 8; ++a)
                for (int i = 0; i < 3; ++i)
                    for (int j = 0; j < 3; ++j)
                        J0.m[i][j] += m.X[static_cast<std::size_t>(cn[static_cast<std::size_t>(a)])][static_cast<std::size_t>(j)] * dN[a][i];
            const double detJ0 = det(J0);
            const Mat3 J0inv = inverse(J0);
            for (int a = 0; a < 8; ++a)
                for (int i = 0; i < 3; ++i) {
                    double s = 0.0;
                    for (int j = 0; j < 3; ++j) s += J0inv.m[j][i] * dN[a][j];
                    dN_dX[static_cast<std::size_t>(a)][static_cast<std::size_t>(i)] = s;
                }
            const double w = gp.w * detJ0;

            for (int a = 0; a < 8; ++a) {
                const std::size_t ia = static_cast<std::size_t>(cn[static_cast<std::size_t>(a)]);
                const double Na = N[static_cast<std::size_t>(a)];
                b[ia] += 2.0 * H * Na * w;
                for (int c = 0; c < 8; ++c) {
                    const std::size_t ic = static_cast<std::size_t>(cn[static_cast<std::size_t>(c)]);
                    const double Nc = N[static_cast<std::size_t>(c)];
                    double grad_cross = 0.0;
                    for (int i = 0; i < 3; ++i)
                        grad_cross += dN_dX[static_cast<std::size_t>(a)][static_cast<std::size_t>(i)] *
                                      dN_dX[static_cast<std::size_t>(c)][static_cast<std::size_t>(i)];
                    A[ia * n + ic] += (Gc / pf.l_c * Na * Nc + 2.0 * H * Na * Nc +
                                       Gc * pf.l_c * grad_cross) * w;
                }
            }
        }
    }

    std::vector<double> d_new = b;
    if (!solve_dense(A, d_new, static_cast<int>(n))) return 1.0;  // вырожденная матрица — не «успех»

    double max_dd = 0.0;
    for (std::size_t a = 0; a < n; ++a) {
        double val = d_new[a];
        if (!std::isfinite(val)) val = st.d_prev[a];
        val = std::min(1.0, std::max(0.0, val));
        val = failure::irreversible(val, st.d_prev[a]);   // необратимость
        max_dd = std::max(max_dd, std::fabs(val - st.d[a]));
        st.d[a] = val;
        st.d_prev[a] = val;
    }
    return max_dd;
}

// Деградация по элементам: среднее d по его 8 узлам.
inline void phase_field_update_degradation(Problem& prob, const PhaseFieldState& st, double k) {
    prob.degradation.assign(prob.mesh.element_count(), 1.0);
    for (std::size_t e = 0; e < prob.mesh.element_count(); ++e) {
        double sum = 0.0;
        for (int a = 0; a < 8; ++a)
            sum += st.d[static_cast<std::size_t>(prob.mesh.conn[e][static_cast<std::size_t>(a)])];
        prob.degradation[e] = failure::degradation(sum / 8.0, k);
    }
}

struct StaggeredReport {
    bool damage_converged = false;
    bool newton_ok = true;
    int outer_iterations = 0;
    int newton_iterations_total = 0;
    double max_dd = 1.0;
    double d_max = 0.0;
    bool solver_ok = true;
};

// Один шаг нагружения: стаггер до сходимости по d.
inline StaggeredReport solve_staggered(Problem& prob, const failure::PhaseFieldParams& pf,
                                       PhaseFieldState& st, const NewtonOptions& opt = {}) {
    StaggeredReport rep;
    for (int outer = 0; outer < pf.max_stagger; ++outer) {
        const NewtonReport nr = solve_newton(prob, opt);
        rep.newton_iterations_total += nr.iterations;
        if (!nr.converged) { rep.newton_ok = false; break; }

        phase_field_update_history(prob, st);
        const double dd = phase_field_solve(prob, pf, st);
        phase_field_update_degradation(prob, st, pf.k_residual);

        rep.outer_iterations = outer + 1;
        rep.max_dd = dd;
        if (dd < pf.stagger_tol) { rep.damage_converged = true; break; }
    }
    for (double v : st.d) rep.d_max = std::max(rep.d_max, v);
    return rep;
}

// Максимальное повреждение по узлам — для отчёта и визуализации.
inline double phase_field_max(const PhaseFieldState& st) {
    double m = 0.0;
    for (double v : st.d) m = std::max(m, v);
    return m;
}

// Доля узлов с d ≥ threshold — «насколько тело разорвано».
inline double phase_field_damaged_fraction(const PhaseFieldState& st, double threshold = 0.9) {
    if (st.d.empty()) return 0.0;
    std::size_t cnt = 0;
    for (double v : st.d) if (v >= threshold) ++cnt;
    return static_cast<double>(cnt) / static_cast<double>(st.d.size());
}

}  // namespace pgib::sfem
