// pgib/solver_fem/bushing.hpp — сайлентблок (металлическая втулка + резина +
// внутренняя втулка) как расчётная постановка для проверки на разрыв.
//
// Геометрия по заданию заказчика (12.11.2026):
//   внешняя втулка:  D_нар = 60 мм, стенка 2 мм  → D_внутр = 56 мм, длина 60 мм
//   внутренняя:      D_внутр = 20 мм, стенка 3 мм → D_нар = 26 мм, длина 65 мм
//                    (по 2,5 мм выступает с каждого торца)
//   между ними залита резина: кольцо от r = 13 мм до r = 28 мм, толщина 15 мм
//
// Постановка: внутренняя втулка закреплена (зажата в опоре), внешняя поворачивается
// вокруг общей оси на заданный угол — это «ход подвески с большим углом».
// Металл не моделируется: его роль — кинематические связи на границах резины.
//
// ТОЧНОЕ РЕШЕНИЕ для несжимаемого нео-Гука (Rivlin, осесимметричный сдвиг):
//   r = R, θ = Θ + ψ(r), z = Z            (изохорно: det F = 1)
//   равновесие ∂(r²τ)/∂r = 0  →  ψ' = C/r³
//   C = 2·φ / (1/r_в² − 1/r_н²),   τ(r) = μ·C/r²
//   момент: M = 2π·L·μ·C = 4π·L·μ·φ / (1/r_в² − 1/r_н²)
//   мера сдвига: γ(r) = r·ψ' = C/r²,   λ_max = √((2 + γ² + γ·√(4+γ²))/2)
// Это решение ТОЧНОЕ при любых углах (не только малых) — поэтому оно годится как
// эталон для проверки больших поворотов.

#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <vector>

#include "pgib/solver_fem/mixed_hyperelastic.hpp"

namespace pgib::sfem {

// 2π локально: M_PI в MSVC не определён без _USE_MATH_DEFINES (найдено 12.11.2026).
constexpr double kBushingTwoPi = 6.283185307179586476925286766559;

// Геометрия сайлентблока, мм.
struct BushingGeometry {
    double outer_od = 60.0;      // наружный диаметр внешней втулки
    double outer_wall = 2.0;     // толщина стенки внешней втулки
    double inner_od = 20.0;      // внутренний диаметр внутренней втулки
    double inner_wall = 3.0;     // толщина стенки внутренней втулки
    double outer_length = 60.0;  // длина внешней втулки
    double inner_length = 65.0;  // длина внутренней втулки

    [[nodiscard]] double rubber_inner_radius() const { return 0.5 * inner_od + inner_wall; }  // 13 мм
    [[nodiscard]] double rubber_outer_radius() const { return 0.5 * outer_od - outer_wall; }  // 28 мм
    [[nodiscard]] double rubber_thickness() const { return rubber_outer_radius() - rubber_inner_radius(); }
    // Резина залита в пределах внешней втулки; выступ внутренней втулки на 2,5 мм
    // с каждой стороны резиной не занят — он нужен, чтобы втулку зажать в опоре.
    [[nodiscard]] double rubber_length() const { return outer_length; }
    [[nodiscard]] double inner_protrusion() const { return 0.5 * (inner_length - outer_length); }
};

// Объём сетки: кольцо в цилиндрических координатах.
// nr — по радиусу, nt — по окружности, nz — по длине.
// Радиальное сгущение к внутренней поверхности (power > 1): там измеряемый
// сдвиг максимален (γ ∝ 1/r²), и без сгущения пик размазывается по элементу.
inline HexMesh make_bushing_mesh(const BushingGeometry& g, int nr, int nt, int nz,
                                 double radial_power = 1.0) {
    HexMesh m;
    m.nx = nr;
    m.ny = nt;
    m.nz = nz;

    const double ri = g.rubber_inner_radius();
    const double ro = g.rubber_outer_radius();
    const double L = g.rubber_length();

    // Кольцо ЗАМКНУТО: узел с j = nt — это тот же узел, что j = 0 (свёртка по
    // окружности). Дефект первой версии: узлы j = 0 и j = nt были разными, тело
    // получалось разрезанным по образующей — незамкнутая скоба вместо втулки,
    // и момент выходил в 6–8 раз больше аналитики.
    auto node = [&](int i, int j, int k) { return i + (nr + 1) * ((j % nt) + nt * k); };
    m.ny = nt;  // узлов по окружности ровно nt
    m.X.resize(static_cast<std::size_t>(nr + 1) * nt * (nz + 1));
    for (int k = 0; k <= nz; ++k)
        for (int j = 0; j < nt; ++j)
            for (int i = 0; i <= nr; ++i) {
                const double t = static_cast<double>(i) / nr;
                const double r = ri + (ro - ri) * std::pow(t, radial_power);
                const double th = kBushingTwoPi * static_cast<double>(j) / nt;
                const std::size_t id = static_cast<std::size_t>(node(i, j, k));
                m.X[id] = {r * std::cos(th), r * std::sin(th), L * static_cast<double>(k) / nz};
            }

    m.conn.reserve(static_cast<std::size_t>(nr) * nt * nz);
    for (int k = 0; k < nz; ++k)
        for (int j = 0; j < nt; ++j)
            for (int i = 0; i < nr; ++i) {
                m.conn.push_back({node(i, j, k), node(i + 1, j, k), node(i + 1, j + 1, k), node(i, j + 1, k),
                                  node(i, j, k + 1), node(i + 1, j, k + 1), node(i + 1, j + 1, k + 1),
                                  node(i, j + 1, k + 1)});
            }
    return m;
}

// Узлы на радиусе r с допуском.
inline std::vector<std::size_t> nodes_at_radius(const HexMesh& m, double r, double tol = 1e-6) {
    std::vector<std::size_t> out;
    for (std::size_t a = 0; a < m.X.size(); ++a) {
        const double ra = std::hypot(m.X[a][0], m.X[a][1]);
        if (std::fabs(ra - r) <= tol) out.push_back(a);
    }
    return out;
}

// Постановка кручения.
//
// ВАЖНО: инициализация и смена угла разделены. В первой версии одна функция
// вызывала prob.initialise() при каждом шаге — это СТИРАЛО решение, «продолжения
// по нагрузке» не было вовсе, Ньютон стартовал с нуля на большом угле и сходился
// в мусор: момент выходил в 5–8 раз больше аналитики при почти правильном λ_max
// (дефект найден 12.11.2026 при запуске сайлентблока).
inline void bushing_init(Problem& prob, const BushingGeometry& g) {
    prob.initialise();
    const auto inner = nodes_at_radius(prob.mesh, g.rubber_inner_radius());
    for (std::size_t a : inner) {
        prob.fix(prob.dof_u(a, 0), 0.0);
        prob.fix(prob.dof_u(a, 1), 0.0);
        prob.fix(prob.dof_u(a, 2), 0.0);
    }
    const auto outer = nodes_at_radius(prob.mesh, g.rubber_outer_radius());
    for (std::size_t a : outer) {
        prob.fix(prob.dof_u(a, 0), 0.0);
        prob.fix(prob.dof_u(a, 1), 0.0);
        prob.fix(prob.dof_u(a, 2), 0.0);
    }
}

// Поворот внешней втулки на angle (радианы) вокруг оси z; внутренняя закреплена.
inline void set_bushing_angle(Problem& prob, const BushingGeometry& g, double angle) {
    const auto outer = nodes_at_radius(prob.mesh, g.rubber_outer_radius());
    const double c = std::cos(angle), s = std::sin(angle);
    for (std::size_t a : outer) {
        const double x = prob.mesh.X[a][0], y = prob.mesh.X[a][1];
        prob.fix(prob.dof_u(a, 0), (c - 1.0) * x - s * y);
        prob.fix(prob.dof_u(a, 1), s * x + (c - 1.0) * y);
        prob.fix(prob.dof_u(a, 2), 0.0);
    }
}

// Момент на внешней втулке: M_z = Σ (X × f)_z по узлам внешней поверхности.
inline double bushing_torque(const Problem& prob, const BushingGeometry& g) {
    const auto r = global_residual(prob);
    double M = 0.0;
    for (std::size_t a : nodes_at_radius(prob.mesh, g.rubber_outer_radius())) {
        const double x = prob.mesh.X[a][0] + prob.u[a][0];
        const double y = prob.mesh.X[a][1] + prob.u[a][1];
        const double fx = r[prob.dof_u(a, 0)];
        const double fy = r[prob.dof_u(a, 1)];
        M += x * fy - y * fx;
    }
    return M;  // Н·мм
}

// --- Точное решение (Rivlin) -------------------------------------------------
struct BushingAnalytic {
    double C = 0.0;        // постоянная решения, мм²
    double torque = 0.0;   // Н·мм
    double gamma_inner = 0.0;
    double lambda_max_inner = 1.0;
    double gamma_outer = 0.0;
};

inline double lambda_max_from_shear(double gamma) {
    const double g2 = gamma * gamma;
    return std::sqrt(0.5 * (2.0 + g2 + gamma * std::sqrt(4.0 + g2)));
}

// Обратная задача: какой сдвиг даёт заданное λ_max.
inline double shear_for_lambda_max(double lambda_max) {
    if (lambda_max <= 1.0) return 0.0;
    const double l2 = lambda_max * lambda_max;
    // Из λ² = (2 + γ² + γ√(4+γ²))/2 → γ = (λ⁴ − 2λ² + 1)/... решаем численно
    double lo = 0.0, hi = 1.0;
    while (lambda_max_from_shear(hi) < lambda_max && hi < 1e3) hi *= 2.0;
    for (int i = 0; i < 200; ++i) {
        const double mid = 0.5 * (lo + hi);
        if (lambda_max_from_shear(mid) < lambda_max) lo = mid; else hi = mid;
    }
    (void)l2;
    return 0.5 * (lo + hi);
}

inline BushingAnalytic bushing_analytic(const BushingGeometry& g, double mu, double angle) {
    BushingAnalytic a;
    const double ri = g.rubber_inner_radius();
    const double ro = g.rubber_outer_radius();
    const double L = g.rubber_length();
    a.C = 2.0 * angle / (1.0 / (ri * ri) - 1.0 / (ro * ro));
    a.torque = kBushingTwoPi * L * mu * a.C;              // Н·мм
    a.gamma_inner = a.C / (ri * ri);
    a.gamma_outer = a.C / (ro * ro);
    a.lambda_max_inner = lambda_max_from_shear(a.gamma_inner);
    return a;
}

// Угол поворота (рад), при котором у внутренней поверхности достигается λ_крит.
inline double bushing_angle_for_lambda(const BushingGeometry& g, double lambda_crit) {
    const double ri = g.rubber_inner_radius();
    const double ro = g.rubber_outer_radius();
    const double gamma_c = shear_for_lambda_max(lambda_crit);
    const double C = gamma_c * ri * ri;
    return 0.5 * C * (1.0 / (ri * ri) - 1.0 / (ro * ro));
}

}  // namespace pgib::sfem
