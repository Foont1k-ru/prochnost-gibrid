// pgib/solver_fem/specimen.hpp — образцы для проверки зарождения разрушения.
//
// Зачем отдельный заголовок: чтобы тесты и инструмент визуализации строили ОДНУ
// И ТУ ЖЕ геометрию. Дублирование сетки в тесте и в демонстрации — источник
// расхождения «в тесте проходит, в отчёте нет».
//
// Надрез делается удалением элементов (геометрический концентратор), а не
// «занижением прочности» в узле: концентрация напряжения должна возникнуть из
// решения, а не быть подставленной.

#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <vector>

#include "pgib/solver_fem/mixed_hyperelastic.hpp"

namespace pgib::sfem {

// Удалить элементы, для которых keep[e] == false, и узлы, не принадлежащие ни
// одному оставшемуся элементу. Без уплотнения узлов в системе остаются нулевые
// строки — матрица вырождена, и Ньютон «сходится» к мусору.
inline HexMesh compact(const HexMesh& src, const std::vector<char>& keep) {
    HexMesh out;
    out.nx = src.nx;
    out.ny = src.ny;
    out.nz = src.nz;

    std::vector<int> new_id(src.X.size(), -1);
    auto touch = [&](int node) {
        if (new_id[static_cast<std::size_t>(node)] < 0) {
            new_id[static_cast<std::size_t>(node)] = static_cast<int>(out.X.size());
            out.X.push_back(src.X[static_cast<std::size_t>(node)]);
        }
    };
    for (std::size_t e = 0; e < src.conn.size(); ++e) {
        if (e >= keep.size() || !keep[e]) continue;
        for (int a = 0; a < 8; ++a) touch(src.conn[e][static_cast<std::size_t>(a)]);
    }
    for (std::size_t e = 0; e < src.conn.size(); ++e) {
        if (e >= keep.size() || !keep[e]) continue;
        std::array<int, 8> c{};
        for (int a = 0; a < 8; ++a)
            c[static_cast<std::size_t>(a)] = new_id[static_cast<std::size_t>(src.conn[e][static_cast<std::size_t>(a)])];
        out.conn.push_back(c);
    }
    return out;
}

// Порядок обхода элементов в make_box: e = i + nx·(j + ny·k).
inline void element_ijk(const HexMesh& m, std::size_t e, int& i, int& j, int& k) {
    i = static_cast<int>(e) % m.nx;
    j = (static_cast<int>(e) / m.nx) % m.ny;
    k = static_cast<int>(e) / (m.nx * m.ny);
}

// Брус lx×ly×lz с боковым надрезом на грани +x.
// notch_layer — номер слоя по z, на котором вырезается надрез; notch_thickness —
// сколько слоёв по z он занимает; notch_depth — сколько элементов по x удаляется.
// Надрез на всю толщину по y: так он виден в проекции и даёт плоскую деформацию
// у вершины (концентрация растяжения в плоскости x–z).
inline HexMesh make_notched_bar(int nx, int ny, int nz, double lx, double ly, double lz,
                                int notch_layer, int notch_thickness, int notch_depth) {
    HexMesh box = make_box(nx, ny, nz, lx, ly, lz);
    std::vector<char> keep(box.element_count(), 1);
    for (std::size_t e = 0; e < box.element_count(); ++e) {
        int i = 0, j = 0, k = 0;
        element_ijk(box, e, i, j, k);
        (void)j;
        const bool in_z = (k >= notch_layer && k < notch_layer + notch_thickness);
        const bool in_x = (i >= nx - notch_depth);
        if (in_z && in_x) keep[e] = 0;
    }
    return compact(box, keep);
}

// Узлы на плоскости axis = value (допуск относительный, по габариту).
inline std::vector<std::size_t> nodes_on_plane(const HexMesh& m, int axis, double value, double tol = 1e-9) {
    std::vector<std::size_t> out;
    for (std::size_t a = 0; a < m.X.size(); ++a) {
        if (std::fabs(m.X[a][static_cast<std::size_t>(axis)] - value) <= tol) out.push_back(a);
    }
    return out;
}

// Центр элемента — нужен для визуализации и для проверки локализации.
inline std::array<double, 3> element_centroid(const HexMesh& m, std::size_t e) {
    std::array<double, 3> c{0.0, 0.0, 0.0};
    for (int a = 0; a < 8; ++a)
        for (int d = 0; d < 3; ++d) c[static_cast<std::size_t>(d)] += m.X[static_cast<std::size_t>(m.conn[e][static_cast<std::size_t>(a)])][static_cast<std::size_t>(d)] / 8.0;
    return c;
}

}  // namespace pgib::sfem
