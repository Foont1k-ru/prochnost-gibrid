// solver_fem/src/verify_report.cpp — протокол верификации (Приложение П5 ТЗ).
//
// Печатает таблицу «эталон — расчёт — отклонение — допуск» по аналитическим
// решениям для несжимаемой сверхупругости. Запускается в конвейере
// (tools/build_linux.sh, build.cmd) и прикладывается к протоколу этапа.
//
// Это НЕ отчёт о расчёте изделия: здесь нет геометрии, контакта и сетки детали.

#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

#include "pgib/solver_fem/mixed_hyperelastic.hpp"

using namespace pgib::sfem;

namespace {

struct Row {
    std::string name;
    std::string reference;
    double exact = 0.0;
    double computed = 0.0;
    double tolerance = 0.0;   // допуск по разделу 12 ТЗ
    bool percentage = true;   // отклонение в процентах или абсолютное
};

std::vector<Row> rows;

void add(std::string name, std::string reference, double exact, double computed, double tol,
         bool percentage = true) {
    rows.push_back({std::move(name), std::move(reference), exact, computed, tol, percentage});
}

Problem make_uniaxial(int n, double lambda, double mu, double K, double h = 10.0) {
    Problem prob;
    prob.mesh = make_box(n, n, n, h, h, h);
    prob.material.iso = neo_hookean(mu);
    prob.material.K = K;
    prob.initialise();
    auto& m = prob.mesh;
    for (std::size_t a = 0; a < m.node_count(); ++a) {
        const auto& X = m.X[a];
        if (X[2] < 1e-12) prob.fix(prob.dof_u(a, 2), 0.0);
        if (X[2] > h - 1e-12) prob.fix(prob.dof_u(a, 2), (lambda - 1.0) * h);
        const bool origin = X[0] < 1e-12 && X[1] < 1e-12 && X[2] < 1e-12;
        const bool x_axis = std::fabs(X[0] - h) < 1e-12 && X[1] < 1e-12 && X[2] < 1e-12;
        const bool top_origin = X[0] < 1e-12 && X[1] < 1e-12 && std::fabs(X[2] - h) < 1e-12;
        if (origin) { prob.fix(prob.dof_u(a, 0), 0.0); prob.fix(prob.dof_u(a, 1), 0.0); }
        if (x_axis) prob.fix(prob.dof_u(a, 1), 0.0);
        if (top_origin) { prob.fix(prob.dof_u(a, 0), 0.0); prob.fix(prob.dof_u(a, 1), 0.0); }
    }
    return prob;
}

}  // namespace

int main() {
    const double h = 10.0;

    // --- 1. Одноосное растяжение и сжатие (нео-Гук) -------------------------
    for (double lambda : {1.5, 0.7}) {
        const double mu = 2.0;
        Problem prob = make_uniaxial(1, lambda, mu, 2000.0);
        const auto rep = solve_newton(prob);
        const auto st = element_state(prob.mesh, 0, prob.u, prob.p[0], prob.material);
        const double exact = mu * (lambda * lambda - 1.0 / lambda);
        char ref[128];
        std::snprintf(ref, sizeof(ref), "σ = μ(λ²−1/λ), μ = 2 МПа, λ = %.1f", lambda);
        add(std::string("Одноосное ") + (lambda > 1 ? "растяжение" : "сжатие"), ref, exact,
            st.sigma.m[2][2], 0.01);
        if (!rep.converged) std::printf("ВНИМАНИЕ: не сошлось (λ = %.2f)\n", lambda);
    }

    // --- 2. Несжимаемый предел: при росте K решение → аналитике -------------
    {
        const double mu = 2.0, lambda = 1.5;
        const double exact = mu * (lambda * lambda - 1.0 / lambda);
        Problem prob = make_uniaxial(1, lambda, mu, 2.0e6);
        solve_newton(prob);
        const auto st = element_state(prob.mesh, 0, prob.u, prob.p[0], prob.material);
        add("Несжимаемый предел, K = 2·10⁶ МПа", "σ = μ(λ²−1/λ), λ = 1,5", exact, st.sigma.m[2][2],
            0.01);
    }

    // --- 3. ν = 0,49995: проверка отсутствия запирания ----------------------
    {
        const double mu = 2.0, nu = 0.49995, lambda = 0.8;
        const double G = mu / 2.0;
        const double K = 2.0 * G * (1.0 + nu) / (3.0 * (1.0 - 2.0 * nu));
        Problem prob = make_uniaxial(1, lambda, mu, K);
        solve_newton(prob);
        const auto st = element_state(prob.mesh, 0, prob.u, prob.p[0], prob.material);
        const double exact = mu * (lambda * lambda - 1.0 / lambda);
        add("Стеснённое сжатие, ν = 0,49995", "σ = μ(λ²−1/λ), λ = 0,8", exact, st.sigma.m[2][2], 0.03);
        add("Стеснённое сжатие: J → 1", "J = 1", 1.0, st.J_mean, 1e-4, false);
    }

    // --- 4. Простой сдвиг --------------------------------------------------
    {
        const double mu = 2.0, gamma = 0.5;
        Problem prob;
        prob.mesh = make_box(1, 1, 1, h, h, h);
        prob.material.iso = neo_hookean(mu);
        prob.material.K = 2000.0;
        prob.initialise();
        for (std::size_t a = 0; a < prob.mesh.node_count(); ++a) {
            prob.fix(prob.dof_u(a, 0), gamma * prob.mesh.X[a][2]);
            prob.fix(prob.dof_u(a, 1), 0.0);
            prob.fix(prob.dof_u(a, 2), 0.0);
        }
        solve_newton(prob);
        const auto st = element_state(prob.mesh, 0, prob.u, prob.p[0], prob.material);
        add("Простой сдвиг", "σ₁₂ = μγ, γ = 0,5", mu * gamma, st.sigma.m[0][2], 0.01);
    }

    // --- 5. Чистый сдвиг ---------------------------------------------------
    {
        const double mu = 2.0, lambda = 1.6;
        Problem prob;
        prob.mesh = make_box(1, 1, 1, h, h, h);
        prob.material.iso = neo_hookean(mu);
        prob.material.K = 2000.0;
        prob.initialise();
        for (std::size_t a = 0; a < prob.mesh.node_count(); ++a) {
            const auto& X = prob.mesh.X[a];
            prob.fix(prob.dof_u(a, 0), (lambda - 1.0) * X[0]);
            prob.fix(prob.dof_u(a, 1), 0.0);
            prob.fix(prob.dof_u(a, 2), (1.0 / lambda - 1.0) * X[2]);
        }
        solve_newton(prob);
        const auto st = element_state(prob.mesh, 0, prob.u, prob.p[0], prob.material);
        add("Чистый сдвиг", "σ₁₁ − σ₃₃ = μ(λ²−1/λ²), λ = 1,6",
            mu * (lambda * lambda - 1.0 / (lambda * lambda)), st.sigma.m[0][0] - st.sigma.m[2][2],
            0.01);
    }

    // --- 6. Плотность энергии ---------------------------------------------
    {
        const double mu = 2.0, lambda = 1.5;
        Problem prob = make_uniaxial(2, lambda, mu, 2000.0);
        solve_newton(prob);
        const auto st = element_state(prob.mesh, 0, prob.u, prob.p[0], prob.material);
        add("Плотность энергии деформации", "W = μ/2·(λ² + 2/λ − 3)",
            0.5 * mu * (lambda * lambda + 2.0 / lambda - 3.0), st.W_iso_mean, 0.01);
    }

    // --- 7. Патч-тест: независимость от сетки ------------------------------
    {
        const double mu = 2.0, lambda = 1.4;
        const double sigma[3] = {0, 0, 0};
        double s[3];
        for (int i = 0; i < 3; ++i) {
            Problem prob = make_uniaxial(i + 1, lambda, mu, 2000.0);
            solve_newton(prob);
            const auto st = element_state(prob.mesh, 0, prob.u, prob.p[0], prob.material);
            s[i] = st.sigma.m[2][2];
        }
        (void)sigma;
        add("Патч-тест: сетка 2×2×2 против 1×1×1", "σ совпадает", 1.0, s[1] / s[0], 1e-5, false);
        add("Патч-тест: сетка 3×3×3 против 1×1×1", "σ совпадает", 1.0, s[2] / s[0], 1e-5, false);
    }

    // --- 8. Кавитационный порог 5·C10 (ПС-2, Ф-46) -------------------------
    {
        const double C10 = 1.0, mu = 2.0 * C10, K = 2000.0;
        const double threshold = 5.0 * C10;
        const double lambda = std::cbrt(1.0 + 1.02 * threshold / K);
        Problem prob;
        prob.mesh = make_box(2, 2, 2, h, h, h);
        prob.material.iso = neo_hookean(mu);
        prob.material.K = K;
        prob.initialise();
        for (std::size_t a = 0; a < prob.mesh.node_count(); ++a) {
            const auto& X = prob.mesh.X[a];
            const bool boundary = X[0] < 1e-12 || std::fabs(X[0] - h) < 1e-12 || X[1] < 1e-12 ||
                                  std::fabs(X[1] - h) < 1e-12 || X[2] < 1e-12 || std::fabs(X[2] - h) < 1e-12;
            if (!boundary) continue;
            for (int i = 0; i < 3; ++i) prob.fix(prob.dof_u(a, i), (lambda - 1.0) * X[static_cast<std::size_t>(i)]);
        }
        solve_newton(prob);
        const auto st = element_state(prob.mesh, 0, prob.u, prob.p[0], prob.material);
        add("Кавитация: гидростатическое растяжение при 1,02·5·C10", "1,02·5·C10 = 5,1 МПа",
            1.02 * threshold, st.hydrostatic_tension, 0.10);
    }

    // --- Печать ------------------------------------------------------------
    std::printf("\n");
    std::printf("===============================================================\n");
    std::printf(" ПРОТОКОЛ ВЕРИФИКАЦИИ: смешанная u/P, несжимаемая сверхупругость\n");
    std::printf("===============================================================\n");
    std::printf("%-46s %12s %12s %10s\n", "Проверка", "Эталон", "Расчёт", "Отклонение");
    std::printf("---------------------------------------------------------------\n");
    int exceeded = 0;
    for (const auto& r : rows) {
        double dev = 0.0;
        if (r.percentage) {
            dev = std::fabs(r.computed / r.exact - 1.0);
        } else {
            dev = std::fabs(r.computed - r.exact);
        }
        const bool ok = dev <= r.tolerance;
        if (!ok) ++exceeded;
        if (r.percentage) {
            std::printf("%-46s %12.6g %12.6g %9.4f %%  %s\n", r.name.c_str(), r.exact, r.computed,
                        dev * 100.0, ok ? "в допуске" : "ПРЕВЫШЕН");
        } else {
            std::printf("%-46s %12.6g %12.6g %10.2e  %s\n", r.name.c_str(), r.exact, r.computed, dev,
                        ok ? "в допуске" : "ПРЕВЫШЕН");
        }
    }
    std::printf("---------------------------------------------------------------\n");
    std::printf("Проверок: %zu, превышений допуска: %d\n", rows.size(), exceeded);
    std::printf("Допуски — раздел 12 ТЗ (позиции по несжимаемости и кавитации).\n");
    return exceeded == 0 ? 0 : 1;
}
