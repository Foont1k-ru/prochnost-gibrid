// pgib_damage_view — построение кадров зарождения разрушения (Э8′).
//
// Назначение: получить ВИДИМЫЕ кадры поля повреждения и точный момент зарождения
// для образца с концентратором, не дожидаясь интерфейса на Qt.
//
// Что делает:
//   1. решает образец с боковым надрезом шагами по удлинению (смешанная u/P,
//      нео-Гук, реальный K — Ф-41);
//   2. находит момент зарождения БИСЕКЦИЕЙ по нагрузке (точность 1e-3 по λ),
//      то есть «когда именно» определяется, а не угадывается по шагу сетки;
//   3. пишет:
//        out/damage/damage_timeline.csv     — числа по кадрам (для отчёта и проверки);
//        out/damage/damage_frames/*.svg     — кадры по отдельности;
//        out/damage/damage_animation.svg    — самопроигрывающаяся анимация кадров
//                                             (чистый SVG, без скриптов и сети);
//   4. печатает протокол «что найдено — где — по какому механизму».
//
// Чего этот инструмент НЕ делает (и не должен выдавать за сделанное):
//   * не показывает разделение тела на части: здесь индикатор повреждения (Ф-49),
//     геометрия трещины — фазовое поле/CZM (В-10), следующий шаг;
//   * не является интерфейсом продукта: интерфейс на Qt берёт те же FieldFrame
//     из слоя failure, второго формата данных не будет.

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>

#include "pgib/failure/damage.hpp"
#include "pgib/failure/damage_field.hpp"
#include "pgib/solver_fem/damage_adapter.hpp"
#include "pgib/solver_fem/mixed_hyperelastic.hpp"
#include "pgib/solver_fem/specimen.hpp"

namespace fs = std::filesystem;
using namespace pgib::sfem;
namespace fail = pgib::failure;

namespace {

// --- Параметры образца -------------------------------------------------------
constexpr int kNx = 6, kNy = 2, kNz = 6;
constexpr double kLx = 6.0, kLy = 2.0, kLz = 6.0;
constexpr int kNotchLayer = 2, kNotchThickness = 2, kNotchDepth = 2;

// Резина В-14 по паспорту ТУ 38 0051166-98: λ_разрыва = 1 + δ/100 = 2,6.
// C10 — оценка по твёрдости (A-22), поэтому на кадрах стоит пометка «оценка».
constexpr double kC10 = 1.2072;
constexpr double kMu = 2.0 * kC10;
constexpr double kNu = 0.4995;
constexpr double kK = 2.0 * kMu * (1.0 + kNu) / (3.0 * (1.0 - 2.0 * kNu));
constexpr double kLambdaBreak = 2.6;

fail::Criteria criteria() {
    fail::Criteria c;
    c.has_lambda_break = true;
    c.lambda_break = kLambdaBreak;
    c.has_Wc = true;
    c.W_c = fail::Wc_from_uniaxial_break(kC10, kLambdaBreak);
    c.has_cavitation = true;
    c.cavitation_threshold = 5.0 * kC10;
    return c;
}

// --- Цветовая шкала повреждения ---------------------------------------------
std::string color_for(double D) {
    struct Stop { double d; int r, g, b; };
    static const Stop stops[] = {{0.0, 43, 108, 176}, {0.5, 250, 204, 21}, {1.0, 220, 38, 38}, {2.0, 120, 0, 0}};
    if (D <= stops[0].d) return "rgb(43,108,176)";
    for (std::size_t i = 1; i < std::size(stops); ++i) {
        if (D <= stops[i].d) {
            const double t = (D - stops[i - 1].d) / (stops[i].d - stops[i - 1].d);
            const int r = static_cast<int>(stops[i - 1].r + t * (stops[i].r - stops[i - 1].r));
            const int g = static_cast<int>(stops[i - 1].g + t * (stops[i].g - stops[i - 1].g));
            const int b = static_cast<int>(stops[i - 1].b + t * (stops[i].b - stops[i - 1].b));
            char buf[32];
            std::snprintf(buf, sizeof(buf), "rgb(%d,%d,%d)", r, g, b);
            return buf;
        }
    }
    return "rgb(120,0,0)";
}

struct Vec2 { double x = 0.0, y = 0.0; };

// Проекция x–z переднего слоя с учётом перемещений.
struct Drawing {
    std::vector<std::vector<Vec2>> quads;  // 4 вершины на элемент
    std::vector<double> D;
    double zmax = 0.0;
};

Drawing project(const Problem& prob, const fail::FieldFrame& frame) {
    Drawing d;
    d.zmax = kLz;
    for (std::size_t e = 0; e < prob.mesh.element_count(); ++e) {
        const auto c = element_centroid(prob.mesh, e);
        if (c[1] > kLy * 0.5 + 1e-9) continue;  // только передний слой (y = 0…1)
        const auto& cn = prob.mesh.conn[e];
        const int order[4] = {0, 1, 5, 4};      // грань y = const: (x0,z0),(x1,z0),(x1,z1),(x0,z1)
        std::vector<Vec2> q;
        for (int a : order) {
            const auto& X = prob.mesh.X[static_cast<std::size_t>(cn[static_cast<std::size_t>(a)])];
            const auto& u = prob.u[static_cast<std::size_t>(cn[static_cast<std::size_t>(a)])];
            q.push_back(Vec2{X[0] + u[0], X[2] + u[2]});
        }
        d.quads.push_back(std::move(q));
        d.D.push_back(e < frame.points.size() ? frame.points[e].D_history : 0.0);
    }
    return d;
}

std::string fmt(const char* pattern, double v) {
    char buf[64];
    std::snprintf(buf, sizeof(buf), pattern, v);
    return buf;
}

// Тело одного кадра: геометрия + подписи. Панель справа — те же числа, что в CSV.
// scale — пикселей на мм, ОДНА на все кадры: считается по предельному растяжению,
// иначе образец на последних кадрах вылезает за холст (дефект первой версии:
// при λ = 2,1 длина 12,6 мм при холсте 430 px давала обрезку сверху).
std::string frame_body(const Drawing& d, const fail::FieldFrame& f, const fail::Criteria& crit,
                       bool mark_onset, double scale) {
    constexpr double kX0 = 40.0, kY0 = 380.0;
    auto sx = [&](double x) { return kX0 + x * scale; };
    auto sy = [&](double z) { return kY0 - z * scale; };

    std::string s;
    // Недеформированный контур (пунктир) — чтобы видеть, насколько растянуто
    s += "<rect x=\"" + fmt("%.1f", sx(0.0)) + "\" y=\"" + fmt("%.1f", sy(kLz)) + "\" width=\"" +
         fmt("%.1f", kLx * scale) + "\" height=\"" + fmt("%.1f", kLz * scale) +
         "\" fill=\"none\" stroke=\"#94a3b8\" stroke-dasharray=\"4 3\" stroke-width=\"1\"/>\n";

    for (std::size_t i = 0; i < d.quads.size(); ++i) {
        const auto& q = d.quads[i];
        char pts[256];
        std::snprintf(pts, sizeof(pts), "%.1f,%.1f %.1f,%.1f %.1f,%.1f %.1f,%.1f",
                      sx(q[0].x), sy(q[0].y), sx(q[1].x), sy(q[1].y),
                      sx(q[2].x), sy(q[2].y), sx(q[3].x), sy(q[3].y));
        s += "<polygon points=\"";
        s += pts;
        s += "\" fill=\"" + color_for(d.D[i]) + "\" stroke=\"#1e293b\" stroke-width=\"0.5\"/>\n";
    }

    if (mark_onset) {
        // Отметка места зарождения: там, где D впервые достиг 1
        const auto& p = f.points[static_cast<std::size_t>(f.element_D_max)];
        const double cx = sx(p.centroid[0]);
        const double cy = sy(p.centroid[2]);
        s += "<circle cx=\"" + fmt("%.1f", cx) + "\" cy=\"" + fmt("%.1f", cy) +
             "\" r=\"9\" fill=\"none\" stroke=\"#ffffff\" stroke-width=\"4\"/>\n";
        s += "<circle cx=\"" + fmt("%.1f", cx) + "\" cy=\"" + fmt("%.1f", cy) +
             "\" r=\"9\" fill=\"none\" stroke=\"#111827\" stroke-width=\"2\"/>\n";
        s += "<line x1=\"" + fmt("%.1f", cx - 13.0) + "\" y1=\"" + fmt("%.1f", cy) +
             "\" x2=\"" + fmt("%.1f", cx + 13.0) + "\" y2=\"" + fmt("%.1f", cy) +
             "\" stroke=\"#111827\" stroke-width=\"1.5\"/>\n";
        s += "<line x1=\"" + fmt("%.1f", cx) + "\" y1=\"" + fmt("%.1f", cy - 13.0) +
             "\" x2=\"" + fmt("%.1f", cx) + "\" y2=\"" + fmt("%.1f", cy + 13.0) +
             "\" stroke=\"#111827\" stroke-width=\"1.5\"/>\n";
        // Выноска: подпись не должна лежать на теле образца
        const double lx = cx + 46.0, ly = cy - 26.0;
        s += "<line x1=\"" + fmt("%.1f", cx + 11.0) + "\" y1=\"" + fmt("%.1f", cy - 8.0) +
             "\" x2=\"" + fmt("%.1f", lx - 4.0) + "\" y2=\"" + fmt("%.1f", ly + 4.0) +
             "\" stroke=\"#111827\" stroke-width=\"1\"/>\n";
        s += "<text x=\"" + fmt("%.1f", lx) + "\" y=\"" + fmt("%.1f", ly) +
             "\" font-size=\"12\" font-weight=\"bold\" fill=\"#111827\">зарождение</text>\n";
    }

    // Панель
    constexpr double kPx = 290.0;
    double y = 40.0;
    auto line = [&](double size, const std::string& text, const char* color = "#111827", bool bold = false) {
        s += "<text x=\"" + fmt("%.1f", kPx) + "\" y=\"" + fmt("%.1f", y) + "\" font-size=\"" +
             fmt("%.0f", size) + "\" fill=\"" + color + "\"" + (bold ? " font-weight=\"bold\"" : "") + ">" +
             text + "</text>\n";
        y += size * 1.55;
    };
    line(15, "Кадр " + std::to_string(f.index), "#111827", true);
    line(13, "Удлинение образца λ = " + fmt("%.3f", f.load));
    line(13, "Максимум повреждения D = " + fmt("%.3f", f.D_max),
         f.D_max >= 1.0 ? "#b91c1c" : "#111827", true);
    if (f.governing == fail::Criterion::None) {
        line(12, "Механизм: нет (повреждения нет)", "#1e293b");
    } else {
        line(12, "Механизм: " + std::string(fail::criterion_name(f.governing)), "#1e293b");
        line(12, "  величина " + fmt("%.3f", f.value_governing) + " при пороге " + fmt("%.3f", f.threshold_governing));
    }
    y += 6.0;
    line(12, "Превысили порог:", "#111827", true);
    line(12, "  ПС-1 растяжение: " + std::to_string(f.over[1]) + " элементов");
    line(12, "  ПС-1 энергия:    " + std::to_string(f.over[2]) + " элементов");
    line(12, "  ПС-2 кавитация:  " + std::to_string(f.over[3]) + " элементов");
    y += 6.0;
    line(11, "Материал: резина В-14 (ТУ 38 0051166-98)", "#475569");
    line(11, "λ_разрыва = 2,60 — из δ = 160 % (документ)", "#475569");
    line(11, "C10 = 1,21 МПа — оценка по твёрдости (A-22)", "#c2410c");
    line(11, "W_c = " + fmt("%.2f", crit.W_c) + " МПа, p_кав = " + fmt("%.2f", crit.cavitation_threshold) + " МПа — оценки", "#c2410c");
    y += 6.0;
    line(11, "Образец 6×2×6 мм, боковой надрез 2×2 эл.", "#475569");
    line(11, "Смешанная u/P, Hex8 2×2×2, нео-Гук, K = " + fmt("%.0f", kK) + " МПа", "#475569");

    // Шкала
    const double bar_y = 392.0;
    for (int i = 0; i < 60; ++i) {
        const double D = i / 30.0;
        s += "<rect x=\"" + fmt("%.1f", kPx + i * 3.0) + "\" y=\"" + fmt("%.1f", bar_y) +
             "\" width=\"3\" height=\"10\" fill=\"" + color_for(D) + "\"/>\n";
    }
    s += "<text x=\"" + fmt("%.1f", kPx) + "\" y=\"" + fmt("%.1f", bar_y + 24.0) +
         "\" font-size=\"10\" fill=\"#475569\">0 — целое</text>\n";
    s += "<text x=\"" + fmt("%.1f", kPx + 70.0) + "\" y=\"" + fmt("%.1f", bar_y + 24.0) +
         "\" font-size=\"10\" fill=\"#475569\">1,0 — порог разрыва</text>\n";
    s += "<text x=\"" + fmt("%.1f", kPx) + "\" y=\"" + fmt("%.1f", bar_y + 40.0) +
         "\" font-size=\"10\" fill=\"#475569\">D = (λ−1)/(λ_разрыва−1): 0 — целое, 1 — зарождение, дальше — за порогом</text>\n";
    return s;
}

std::string svg_head(double w, double h) {
    return "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 " + fmt("%.0f", w) + " " + fmt("%.0f", h) +
           "\" width=\"" + fmt("%.0f", w) + "\" height=\"" + fmt("%.0f", h) +
           "\" font-family=\"Segoe UI, Arial, sans-serif\">\n"
           "<rect width=\"100%\" height=\"100%\" fill=\"#f8fafc\"/>\n";
}

}  // namespace

int main(int argc, char** argv) {
    fs::path out = argc > 1 ? fs::path(argv[1]) : fs::path("out/damage");
    fs::create_directories(out / "damage_frames");

    const auto crit = criteria();

    Problem prob;
    prob.mesh = make_notched_bar(kNx, kNy, kNz, kLx, kLy, kLz, kNotchLayer, kNotchThickness, kNotchDepth);
    prob.material.iso = neo_hookean(kMu);
    prob.material.K = kK;
    setup_uniaxial(prob, kLz, kLx);

    std::printf("===============================================================\n");
    std::printf(" ЗАРОЖДЕНИЕ РАЗРУШЕНИЯ: кадры поля повреждения (Э8')\n");
    std::printf("===============================================================\n");
    std::printf("Образец: %d×%d×%d элементов, узлов %zu, DOF %zu\n", kNx, kNy, kNz,
                prob.mesh.node_count(), prob.dof_count());
    std::printf("Материал: нео-Гук C10 = %.4f МПа, K = %.1f МПа (реальный, Ф-41)\n", kC10, kK);
    std::printf("Критерии: λ_разрыва %.2f (документ), W_c %.2f МПа, кавитация %.2f МПа (оценки)\n\n",
                crit.lambda_break, crit.W_c, crit.cavitation_threshold);

    // Гладкий образец — эталон «когда порвался бы без концентратора».
    Problem smooth;
    smooth.mesh = make_box(1, 1, 4, 1.0, 1.0, 4.0);
    smooth.material = prob.material;
    setup_uniaxial(smooth, 4.0, 1.0);
    // Продолжение по нагрузке обязательно: прыжок с λ = 1,0 сразу на 2,6 из
    // состояния покоя Ньютона не берёт (проверено — расходится, λ_max = 9,35).
    bool smooth_ok = true;
    fail::FieldFrame fs{};
    for (double lam = 1.0; lam <= kLambdaBreak + 1e-12; lam += 0.1) {
        const auto r = solve_at_stretch(smooth, lam, 4.0);
        if (!r.converged) { smooth_ok = false; break; }
        fs = frame_of(smooth, crit, 0, lam);
    }
    const bool rs_converged = smooth_ok;
    std::printf("Эталон (гладкий брус, однородное состояние):\n");
    std::printf("  при λ = %.2f получено λ_max = %.4f, D = %.4f %s\n", kLambdaBreak, fs.value_governing,
                fs.D_max, rs_converged ? "" : "(НЕ СОШЛОСЬ)");

    // Шаги по нагрузке до первого превышения порога
    std::vector<fail::FieldFrame> frames;
    std::vector<Drawing> drawings;
    fail::FieldHistory hist;
    double lo = 1.0, hi = -1.0;
    int idx = 0;
    for (double lam = 1.0; lam <= 2.6 + 1e-12; lam += 0.1) {
        const auto r = solve_at_stretch(prob, lam, kLz);
        if (!r.converged) { std::printf("шаг λ=%.2f не сошёлся — прогон остановлен\n", lam); break; }
        auto f = frame_of(prob, crit, idx++, lam);
        hist.update(f);
        drawings.push_back(project(prob, f));
        frames.push_back(f);
        if (f.D_max >= 1.0) {
            // Этот шаг «перескочил» порог: он не попадает в кадры, потому что его
            // место занимает точный кадр зарождения из бисекции. Иначе в ленте
            // кадров было бы два «зарождения» подряд (дефект первой версии).
            hi = lam;
            frames.pop_back();
            drawings.pop_back();
            break;
        }
        lo = lam;
    }
    if (hi < 0.0) {
        std::printf("Зарождение в диапазоне до 2,60 не обнаружено — кадры не строятся\n");
        return 1;
    }

    // Бисекция: точный момент, а не «на шаге 2,1»
    auto solve_d = [&](double lam) {
        const auto r = solve_at_stretch(prob, lam, kLz);
        if (!r.converged) return -1.0;
        return frame_of(prob, crit, 0, lam).D_max;
    };
    const auto onset = fail::find_onset(lo, hi, solve_d, 1e-3);
    const auto r_on = solve_at_stretch(prob, onset.load, kLz);
    (void)r_on;
    auto f_on = frame_of(prob, crit, static_cast<int>(frames.size()), onset.load);
    hist.update(f_on);
    f_on.onset = true;
    frames.push_back(f_on);
    drawings.push_back(project(prob, f_on));

    const auto& p_on = f_on.points[static_cast<std::size_t>(f_on.element_D_max)];
    std::printf("\nЗАРОЖДЕНИЕ (бисекция, точность 1e-3 по λ):\n");
    std::printf("  момент:    λ = %.4f  (скобка %s, итераций %d)\n", onset.load,
                fmt("%.4f", onset.width).c_str(), onset.iterations);
    std::printf("  место:     элемент %d, координаты центра (%.1f; %.1f; %.1f) мм\n", f_on.element_D_max,
                p_on.centroid[0], p_on.centroid[1], p_on.centroid[2]);
    std::printf("  механизм:  %s\n", fail::criterion_name(f_on.governing));
    std::printf("  величина:  %.3f при пороге %.3f\n", f_on.value_governing, f_on.threshold_governing);
    std::printf("  D в точке: %.4f (должно быть ≈ 1)\n", p_on.evaluation.D);

    // Кадры после зарождения
    for (double lam : {onset.load + 0.1, onset.load + 0.2}) {
        if (lam > 2.7) break;
        const auto r = solve_at_stretch(prob, lam, kLz);
        if (!r.converged) break;
        auto f = frame_of(prob, crit, static_cast<int>(frames.size()), lam);
        hist.update(f);
        drawings.push_back(project(prob, f));
        frames.push_back(f);
    }

    // --- CSV -----------------------------------------------------------------
    const fs::path csv = out / "damage_timeline.csv";
    std::ofstream c(csv);
    c << "кадр;удлинение;D_max;элемент;механизм;величина;порог;"
         "превысили_ПС1_растяжение;превысили_ПС1_энергия;превысили_ПС2_кавитация;зарождение\n";
    for (const auto& f : frames) {
        c << f.index << ';' << fmt("%.4f", f.load) << ';' << fmt("%.4f", f.D_max) << ';' << f.element_D_max << ';'
          << fail::criterion_name(f.governing) << ';' << fmt("%.4f", f.value_governing) << ';'
          << fmt("%.4f", f.threshold_governing) << ';' << f.over[1] << ';' << f.over[2] << ';' << f.over[3]
          << ';' << (f.onset ? "да" : "") << '\n';
    }
    c.close();

    // --- Отдельные кадры и анимация -----------------------------------------
    // Масштаб: по самому растянутому кадру ленты, чтобы ничего не обрезалось.
    double z_deformed_max = 0.0;
    for (const auto& f : frames) z_deformed_max = std::max(z_deformed_max, f.load * kLz);
    const double draw_scale = z_deformed_max > 0.0 ? 330.0 / z_deformed_max : 30.0;

    std::string anim;
    anim += svg_head(720.0, 452.0);
    for (std::size_t i = 0; i < frames.size(); ++i) {
        const auto& f = frames[i];
        // Чертёж снят в момент решения этого кадра. Пересчитывать решение заново
        // (как было в первой версии) — двойная работа: 16 лишних решений Ньютона
        // на кадр, из-за чего инструмент шёл 76 с вместо единиц секунд.
        const Drawing& d = drawings[i];

        std::string one = svg_head(720.0, 452.0);
        one += frame_body(d, f, crit, f.onset, draw_scale);
        one += "</svg>\n";
        char name[64];
        std::snprintf(name, sizeof(name), "frame_%03zu.svg", i);
        std::ofstream of(out / "damage_frames" / name);
        of << one;

        // keyTimes обязаны строго возрастать от 0 до 1, иначе SMIL-анимация
        // не запускается вовсе (проверено на первых кадрах, где begin = 0).
        const double dur = static_cast<double>(frames.size()) * 0.7;
        const double begin = static_cast<double>(i) * 0.7;
        const double t1 = std::max(begin / dur, 1e-4);
        const double t2 = std::min((begin + 0.7) / dur, 1.0);
        anim += "<g opacity=\"0\">\n";
        anim += "<animate attributeName=\"opacity\" calcMode=\"discrete\" values=\"0;1;0\" keyTimes=\"0;" +
                fmt("%.4f", t1) + ";" + fmt("%.4f", t2) +
                "\" dur=\"" + fmt("%.2f", dur) + "s\" repeatCount=\"indefinite\"/>\n";
        anim += frame_body(d, f, crit, f.onset, draw_scale);
        anim += "</g>\n";
    }
    anim += "<text x=\"40\" y=\"424\" font-size=\"11\" fill=\"#64748b\">Поле повреждения по кадрам нагружения. "
            "Порог D = 1 — начало разрыва. Механизмы подписаны раздельно (ПС-1 растяжение, ПС-1 энергия, ПС-2 кавитация).</text>\n";
    anim += "</svg>\n";
    std::ofstream af(out / "damage_animation.svg");
    af << anim;

    std::printf("\nКадров записано: %zu\n", frames.size());
    std::printf("  %s\n", csv.string().c_str());
    std::printf("  %s/damage_frames/*.svg\n", out.string().c_str());
    std::printf("  %s/damage_animation.svg\n", out.string().c_str());

    // Проверка «сколько времени занимает кадр» — то, от чего зависит интерактивность
    const auto t0 = std::chrono::steady_clock::now();
    double sink = 0.0;
    for (int i = 0; i < 100; ++i) sink += frame_of(prob, crit, i, f_on.load).D_max;
    const auto t1 = std::chrono::steady_clock::now();
    const double ms = std::chrono::duration<double, std::milli>(t1 - t0).count() / 100.0;
    std::printf("\nСтоимость кадра поля (%zu элементов): %.3f мс (бюджет 30 кадр/с = 33,3 мс)\n",
                prob.mesh.element_count(), ms);
    (void)sink;
    return 0;
}
