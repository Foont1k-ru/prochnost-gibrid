// pgib_crack_view — кадры РАЗВИВАЮЩЕЙСЯ трещины по фазовому полю (В-10).
//
// Отличие от pgib_damage_view: там индикатор (тело не разделяется, нагрузка не падает),
// здесь — фазовое поле d. Когда d доходит до 1, материал в этой полосе перестаёт
// держать нагрузку, и номинальное напряжение ПАДАЕТ. Это и есть «тело порвалось»,
// видимое как полоса шириной ~l_c (характерная длина), а не как «удалённые элементы».
//
// Что показывает кадр:
//   * геометрию с учётом перемещений (образец удлиняется по-настоящему);
//   * поле d (0 — целое, 1 — разрыв) — трещина видна тёмной полосой;
//   * падающую нагрузку P, долю разорванных узлов, номер стаггер-итерации;
//   * отдельно отмечается кадр пика нагрузки и кадр, где d впервые достигло 0,9.
//
// Чего НЕ делает: не калибрует G_c по паспортной прочности. Для этого нужен
// J-интеграл в больших деформациях (следующий шаг, A-29). Значение G_c = 2 Н/мм
// взято как типичное для наполненных резин и помечено как параметр, а не измерение.

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>

#include "pgib/failure/phase_field.hpp"
#include "pgib/solver_fem/damage_adapter.hpp"
#include "pgib/solver_fem/mixed_hyperelastic.hpp"
#include "pgib/solver_fem/phase_field_solver.hpp"
#include "pgib/solver_fem/specimen.hpp"

namespace fs = std::filesystem;
using namespace pgib::sfem;
namespace fail = pgib::failure;

namespace {

constexpr int kNx = 6, kNy = 2, kNz = 6;
constexpr double kLx = 6.0, kLy = 2.0, kLz = 6.0;
constexpr int kNotchLayer = 2, kNotchThickness = 2, kNotchDepth = 2;

constexpr double kC10 = 1.2072;
constexpr double kMu = 2.0 * kC10;
constexpr double kNu = 0.4995;
constexpr double kK = 2.0 * kMu * (1.0 + kNu) / (3.0 * (1.0 - 2.0 * kNu));

constexpr double kGc = 2.0;   // Н/мм — параметр, не измерение (см. шапку файла)
constexpr double kLc = 3.0;   // мм — характерная длина, 3 элемента при h = 1 мм
constexpr double kThickness = 2.0;  // мм, размер по y (для номинального напряжения)

std::string color_for_d(double d) {
    // 0 — синий (целый материал), 0,5 — жёлтый, 1 — почти чёрный (разрыв)
    struct Stop { double v; int r, g, b; };
    static const Stop stops[] = {{0.0, 43, 108, 176}, {0.35, 250, 204, 21}, {0.7, 214, 79, 30}, {1.0, 30, 20, 20}};
    if (d <= stops[0].v) return "rgb(43,108,176)";
    for (std::size_t i = 1; i < std::size(stops); ++i) {
        if (d <= stops[i].v) {
            const double t = (d - stops[i - 1].v) / (stops[i].v - stops[i - 1].v);
            char buf[32];
            std::snprintf(buf, sizeof(buf), "rgb(%d,%d,%d)",
                          static_cast<int>(stops[i - 1].r + t * (stops[i].r - stops[i - 1].r)),
                          static_cast<int>(stops[i - 1].g + t * (stops[i].g - stops[i - 1].g)),
                          static_cast<int>(stops[i - 1].b + t * (stops[i].b - stops[i - 1].b)));
            return buf;
        }
    }
    return "rgb(30,20,20)";
}

std::string f1(const char* p, double v) {
    char buf[64];
    std::snprintf(buf, sizeof(buf), p, v);
    return buf;
}

struct Frame {
    double lambda = 1.0;
    double P = 0.0;          // номинальное напряжение, МПа
    double d_max = 0.0;
    double damaged = 0.0;    // доля узлов с d ≥ 0,9
    int stagger = 0;
    std::vector<std::array<double, 2>> quads;  // 4 точки на элемент (или меньше при вырождении)
    std::vector<double> d_elem;
    bool crack_event = false;  // кадр, где d впервые ≥ 0,9
    bool peak = false;         // кадр пика нагрузки
};

// Передний слой (y = 0…1) в координатах «x — z» с учётом перемещений.
void capture(const Problem& prob, const PhaseFieldState& st, Frame& f) {
    f.quads.clear();
    f.d_elem.clear();
    for (std::size_t e = 0; e < prob.mesh.element_count(); ++e) {
        const auto c = element_centroid(prob.mesh, e);
        if (c[1] > kLy * 0.5 + 1e-9) continue;
        const auto& cn = prob.mesh.conn[e];
        const int order[4] = {0, 1, 5, 4};
        double dsum = 0.0;
        for (int a : order) {
            const auto& X = prob.mesh.X[static_cast<std::size_t>(cn[static_cast<std::size_t>(a)])];
            const auto& u = prob.u[static_cast<std::size_t>(cn[static_cast<std::size_t>(a)])];
            f.quads.push_back({X[0] + u[0], X[2] + u[2]});
            dsum += st.d[static_cast<std::size_t>(cn[static_cast<std::size_t>(a)])];
        }
        f.d_elem.push_back(dsum / 4.0);
    }
}

std::string svg_head(double w, double h) {
    return "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 " + f1("%.0f", w) + " " + f1("%.0f", h) +
           "\" width=\"" + f1("%.0f", w) + "\" height=\"" + f1("%.0f", h) +
           "\" font-family=\"Segoe UI, Arial, sans-serif\">\n"
           "<rect width=\"100%\" height=\"100%\" fill=\"#f8fafc\"/>\n";
}

std::string body(const Frame& f, int index, double scale, bool mark) {
    constexpr double kX0 = 40.0, kY0 = 380.0;
    auto sx = [&](double x) { return kX0 + x * scale; };
    auto sy = [&](double z) { return kY0 - z * scale; };

    std::string s;
    s += "<rect x=\"" + f1("%.1f", sx(0.0)) + "\" y=\"" + f1("%.1f", sy(kLz)) + "\" width=\"" +
         f1("%.1f", kLx * scale) + "\" height=\"" + f1("%.1f", kLz * scale) +
         "\" fill=\"none\" stroke=\"#94a3b8\" stroke-dasharray=\"4 3\"/>\n";

    for (std::size_t i = 0; i < f.d_elem.size(); ++i) {
        const std::size_t q0 = i * 4;
        if (q0 + 3 >= f.quads.size()) break;
        s += "<polygon points=\"" + f1("%.1f", sx(f.quads[q0][0])) + "," + f1("%.1f", sy(f.quads[q0][1])) + " " +
             f1("%.1f", sx(f.quads[q0 + 1][0])) + "," + f1("%.1f", sy(f.quads[q0 + 1][1])) + " " +
             f1("%.1f", sx(f.quads[q0 + 2][0])) + "," + f1("%.1f", sy(f.quads[q0 + 2][1])) + " " +
             f1("%.1f", sx(f.quads[q0 + 3][0])) + "," + f1("%.1f", sy(f.quads[q0 + 3][1])) +
             "\" fill=\"" + color_for_d(f.d_elem[i]) + "\" stroke=\"#1e293b\" stroke-width=\"0.5\"/>\n";
    }

    // Отметка разрыва: кольцо на элементе с максимальным d (подпись — в панели,
    // иначе она ложится на растянутое тело: дефект первой версии).
    if (mark) {
        std::size_t imax = 0;
        for (std::size_t i = 0; i < f.d_elem.size(); ++i) if (f.d_elem[i] > f.d_elem[imax]) imax = i;
        const std::size_t q0 = imax * 4;
        if (q0 + 3 < f.quads.size()) {
            const double cx = 0.25 * (f.quads[q0][0] + f.quads[q0 + 1][0] + f.quads[q0 + 2][0] + f.quads[q0 + 3][0]);
            const double cz = 0.25 * (f.quads[q0][1] + f.quads[q0 + 1][1] + f.quads[q0 + 2][1] + f.quads[q0 + 3][1]);
            // Белое кольцо + красная точка: видно и на тёмной (разорванной), и на
            // светлой (целой) части — красное кольцо на тёмном фоне не читалось.
            s += "<circle cx=\"" + f1("%.1f", sx(cx)) + "\" cy=\"" + f1("%.1f", sy(cz)) +
                 "\" r=\"13\" fill=\"none\" stroke=\"#ffffff\" stroke-width=\"3\"/>\n";
            s += "<circle cx=\"" + f1("%.1f", sx(cx)) + "\" cy=\"" + f1("%.1f", sy(cz)) +
                 "\" r=\"4.5\" fill=\"#b91c1c\" stroke=\"#ffffff\" stroke-width=\"1.5\"/>\n";
        }
    }

    constexpr double kPx = 300.0;
    double y = 40.0;
    auto line = [&](double size, const std::string& text, const char* color = "#111827", bool bold = false) {
        s += "<text x=\"" + f1("%.1f", kPx) + "\" y=\"" + f1("%.1f", y) + "\" font-size=\"" + f1("%.0f", size) +
             "\" fill=\"" + color + "\"" + (bold ? " font-weight=\"bold\"" : "") + ">" + text + "</text>\n";
        y += size * 1.6;
    };
    line(15, "Кадр " + std::to_string(index), "#111827", true);
    line(13, "Удлинение образца λ = " + f1("%.3f", f.lambda));
    line(14, "Нагрузка P = " + f1("%.3f", f.P) + " МПа", f.P < 0.02 ? "#b91c1c" : "#111827", true);
    line(13, "Максимум повреждения d = " + f1("%.3f", f.d_max), f.d_max > 0.9 ? "#b91c1c" : "#111827", true);
    line(13, "Разорвано узлов: " + f1("%.0f", f.damaged * 100.0) + " %");
    if (mark) line(13, "РАЗРЫВ: d ≥ 0,9 — кольцо на кадре", "#b91c1c", true);
    y += 6.0;
    line(11, "Метод: фазовое поле AT2, гибридная движущая сила", "#475569");
    line(11, "G_c = " + f1("%.1f", kGc) + " Н/мм (параметр, не измерение)", "#c2410c");
    line(11, "l_c = " + f1("%.1f", kLc) + " мм — ширина зоны повреждения", "#475569");
    line(11, "Материал: резина В-14, C10 = " + f1("%.2f", kC10) + " МПа (оценка, A-22)", "#475569");
    line(11, "K = " + f1("%.0f", kK) + " МПа, смешанная u/P, Hex8", "#475569");
    y += 6.0;
    line(11, "Элементы не удаляются, масса сохраняется (Ф-50).", "#475569");
    line(11, "Трещина — полоса шириной ~l_c, а не «дырка» в сетке.", "#475569");

    const double bar_y = 392.0;
    for (int i = 0; i < 60; ++i) {
        s += "<rect x=\"" + f1("%.1f", kPx + i * 3.0) + "\" y=\"" + f1("%.1f", bar_y) +
             "\" width=\"3\" height=\"10\" fill=\"" + color_for_d(i / 60.0) + "\"/>\n";
    }
    s += "<text x=\"" + f1("%.1f", kPx) + "\" y=\"" + f1("%.1f", bar_y + 24.0) +
         "\" font-size=\"10\" fill=\"#475569\">d = 0 — целый материал</text>\n";
    s += "<text x=\"" + f1("%.1f", kPx + 150.0) + "\" y=\"" + f1("%.1f", bar_y + 24.0) +
         "\" font-size=\"10\" fill=\"#475569\">d = 1 — разрыв</text>\n";
    return s;
}

}  // namespace

int main(int argc, char** argv) {
    fs::path out = argc > 1 ? fs::path(argv[1]) : fs::path("out/crack");
    fs::create_directories(out / "crack_frames");

    Problem prob;
    prob.mesh = make_notched_bar(kNx, kNy, kNz, kLx, kLy, kLz, kNotchLayer, kNotchThickness, kNotchDepth);
    prob.material.iso = neo_hookean(kMu);
    prob.material.K = kK;
    setup_uniaxial(prob, kLz, kLx);

    PhaseFieldState st;
    phase_field_init(prob, st);
    fail::PhaseFieldParams pf;
    pf.enabled = true;
    pf.G_c = kGc;
    pf.l_c = kLc;
    st.Gc.assign(prob.mesh.element_count(), kGc);

    std::printf("===============================================================\n");
    std::printf(" РАЗВИТИЕ ТРЕЩИНЫ: фазовое поле (В-10)\n");
    std::printf("===============================================================\n");
    std::printf("Образец %d×%d×%d мм с боковым надрезом, элементов %zu, DOF %zu (+%zu узловых d)\n",
                static_cast<int>(kLx), static_cast<int>(kLy), static_cast<int>(kLz),
                prob.mesh.element_count(), prob.dof_count(), prob.mesh.node_count());
    std::printf("G_c = %.2f Н/мм, l_c = %.1f мм (%.1f элемента при h = 1 мм)\n", kGc, kLc, kLc);
    if (!pf.admissible(1.0)) {
        std::printf("ПАРАМЕТРЫ НЕДОПУСТИМЫ: %s\n", pf.why_inadmissible(1.0).c_str());
        return 1;
    }

    std::vector<Frame> frames;
    double P_peak = -1.0;
    std::size_t i_peak = 0;
    bool crack_seen = false;

    const auto t0 = std::chrono::steady_clock::now();
    for (double lam = 1.0; lam <= 2.001; lam += 0.05) {
        set_stretch(prob, lam, kLz);
        const auto rep = solve_staggered(prob, pf, st);
        if (!rep.newton_ok) {
            std::printf("шаг λ = %.2f: Ньютон не сошёлся — лента кадров остановлена\n", lam);
            break;
        }
        Frame f;
        f.lambda = lam;
        f.P = top_reaction(prob, kLz) / (kLy * kThickness * (1.0 - 0.0));
        f.d_max = phase_field_max(st);
        f.damaged = phase_field_damaged_fraction(st, 0.9);
        f.stagger = rep.outer_iterations;
        capture(prob, st, f);

        if (f.P > P_peak) { P_peak = f.P; i_peak = frames.size(); }
        if (!crack_seen && f.d_max >= 0.9) { f.crack_event = true; crack_seen = true; }
        frames.push_back(std::move(f));
    }
    if (frames.empty()) {
        std::printf("Кадры не построены: решения нет\n");
        return 1;
    }
    frames[i_peak].peak = true;
    const auto t1 = std::chrono::steady_clock::now();

    // --- CSV -----------------------------------------------------------------
    std::ofstream csv(out / "crack_timeline.csv");
    csv << "кадр;удлинение;нагрузка_МПа;d_max;разорвано_узлов_доля;стаггер;пик_нагрузки;разрыв\n";
    for (std::size_t i = 0; i < frames.size(); ++i) {
        const auto& f = frames[i];
        csv << i << ';' << f1("%.3f", f.lambda) << ';' << f1("%.4f", f.P) << ';' << f1("%.3f", f.d_max) << ';'
            << f1("%.3f", f.damaged) << ';' << f.stagger << ';' << (f.peak ? "да" : "") << ';'
            << (f.crack_event ? "да" : "") << '\n';
    }
    csv.close();

    // --- Кадры и анимация ----------------------------------------------------
    double deformed_max = 0.0;
    for (const auto& f : frames) deformed_max = std::max(deformed_max, f.lambda * kLz);
    const double scale = deformed_max > 0.0 ? 330.0 / deformed_max : 30.0;

    std::string anim = svg_head(760.0, 452.0);
    for (std::size_t i = 0; i < frames.size(); ++i) {
        std::string one = svg_head(760.0, 452.0);
        one += body(frames[i], static_cast<int>(i), scale, frames[i].crack_event || frames[i].d_max > 0.95);
        one += "</svg>\n";
        char name[64];
        std::snprintf(name, sizeof(name), "frame_%03zu.svg", i);
        std::ofstream(out / "crack_frames" / name) << one;

        const double dur = static_cast<double>(frames.size()) * 0.6;
        const double begin = static_cast<double>(i) * 0.6;
        const double t1k = std::max(begin / dur, 1e-4);
        const double t2k = std::min((begin + 0.6) / dur, 1.0);
        anim += "<g opacity=\"0\">\n";
        anim += "<animate attributeName=\"opacity\" calcMode=\"discrete\" values=\"0;1;0\" keyTimes=\"0;" +
                f1("%.4f", t1k) + ";" + f1("%.4f", t2k) + "\" dur=\"" + f1("%.2f", dur) +
                "s\" repeatCount=\"indefinite\"/>\n";
        anim += body(frames[i], static_cast<int>(i), scale, frames[i].crack_event || frames[i].d_max > 0.95);
        anim += "</g>\n";
    }
    anim += "<text x=\"40\" y=\"432\" font-size=\"11\" fill=\"#64748b\">Фазовое поле AT2: d = 0 — целый материал, "
            "d = 1 — разрыв. Нагрузка после пика падает — тело рвётся. Ширина полосы задаётся l_c, а не сеткой.</text>\n";
    anim += "</svg>\n";
    std::ofstream(out / "crack_animation.svg") << anim;

    // --- Протокол ------------------------------------------------------------
    std::printf("\nКадров: %zu, время счёта: %.1f с\n", frames.size(),
                std::chrono::duration<double>(t1 - t0).count());
    std::printf("Пик нагрузки: P = %.3f МПа при λ = %.3f (кадр %zu)\n", frames[i_peak].P,
                frames[i_peak].lambda, i_peak);
    double P_end = frames.back().P;
    std::printf("В конце ленты:  P = %.3f МПа при λ = %.3f — падение на %.1f %%\n", P_end,
                frames.back().lambda, 100.0 * (1.0 - P_end / frames[i_peak].P));
    std::size_t i_crack = frames.size();
    for (std::size_t i = 0; i < frames.size(); ++i) if (frames[i].crack_event) { i_crack = i; break; }
    if (i_crack < frames.size()) {
        std::printf("Разрыв (d ≥ 0,9) впервые на кадре %zu, λ = %.3f, P = %.3f МПа (%.0f %% от пика)\n",
                    i_crack, frames[i_crack].lambda, frames[i_crack].P,
                    100.0 * frames[i_crack].P / frames[i_peak].P);
    } else {
        std::printf("Разрыв (d ≥ 0,9) не достигнут в этом диапазоне нагружения\n");
    }
    std::size_t amax = 0;
    for (std::size_t a = 0; a < st.d.size(); ++a) if (st.d[a] > st.d[amax]) amax = a;
    std::printf("Полностью разорванный узел ближе всех к вершине надреза: (%.0f; %.0f; %.0f) мм, d = %.3f\n",
                prob.mesh.X[amax][0], prob.mesh.X[amax][1], prob.mesh.X[amax][2], st.d[amax]);
    std::printf("\nЗаписано:\n  %s\n  %s/crack_frames/*.svg\n  %s/crack_animation.svg\n",
                (out / "crack_timeline.csv").string().c_str(), out.string().c_str(), out.string().c_str());
    return 0;
}
