// pgib_bushing_check — сайлентблок: размеры, точное решение Ривлина, угол разрыва.
//
// ЭТО НЕ РАСЧЁТ FE. Печатается ТОЧНОЕ решение для несжимаемого нео-Гука
// (осесимметричный сдвиг) и из него — угол, при котором достигается λ_разрыва.
// Полное решение выведено аналитически и проверено энергетически (M = dW/dφ).
// FE-модель сайлентблока пока не верифицирована — см. docs/ПРОТОКОЛ_САЙЛЕНТБЛОК.md.

#include <cmath>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <string>

#include "pgib/solver_fem/bushing.hpp"

namespace fs = std::filesystem;
using namespace pgib::sfem;

namespace {
constexpr double kC10 = 1.2072;
constexpr double kMu = 2.0 * kC10;
constexpr double kPi = 3.14159265358979323846;
constexpr double kLambdaBreak = 2.6;

std::string f1(const char* p, double v) {
    char b[64];
    std::snprintf(b, sizeof(b), p, v);
    return b;
}
}  // namespace

int main(int argc, char** argv) {
    const fs::path out = argc > 1 ? fs::path(argv[1]) : fs::path("out/bushing");
    fs::create_directories(out);

    BushingGeometry g;
    std::printf("===============================================================\n");
    std::printf(" САЙЛЕНТБЛОК: геометрия по заданию и предельный угол поворота\n");
    std::printf("===============================================================\n");
    std::printf("Внешняя втулка:  D %.0f мм, стенка %.0f мм, длина %.0f мм\n", g.outer_od, g.outer_wall, g.outer_length);
    std::printf("Внутренняя:      D %.0f мм, стенка %.0f мм, длина %.0f мм (выступ %.1f мм на сторону)\n",
                g.inner_od, g.inner_wall, g.inner_length, g.inner_protrusion());
    std::printf("Резина:          r %.0f…%.0f мм, толщина %.0f мм, длина %.0f мм\n",
                g.rubber_inner_radius(), g.rubber_outer_radius(), g.rubber_thickness(), g.rubber_length());
    std::printf("Материал:        резина В-14, C10 = %.4f МПа (оценка по твёрдости), λ_разрыва = %.2f\n\n",
                kC10, kLambdaBreak);

    std::printf("Точное решение (Rivlin, нео-Гук, осесимметричный сдвиг):\n");
    std::printf("  γ(r) = C/r²,  C = 2φ/(1/r_в² − 1/r_н²),  M = 2π·L·μ·C\n\n");
    std::printf("  угол |  момент, Н·м | λ_max на внутр. | λ_max на внешн. | состояние\n");
    std::printf("  -----+---------------+-----------------+-----------------+----------\n");

    std::string pts;
    double phi_crit = bushing_angle_for_lambda(g, kLambdaBreak);
    for (int deg = 0; deg <= 90; deg += 5) {
        const auto a = bushing_analytic(g, kMu, deg * kPi / 180.0);
        const char* state = a.lambda_max_inner >= kLambdaBreak ? "РАЗРЫВ" : "целая";
        std::printf("  %4d° | %13.1f | %15.3f | %15.3f | %s\n", deg, a.torque / 1000.0,
                    a.lambda_max_inner, lambda_max_from_shear(a.gamma_outer), state);
        char buf[128];
        std::snprintf(buf, sizeof(buf), "%.1f,%.1f ", static_cast<double>(deg), a.lambda_max_inner);
        pts += buf;
    }

    const auto a_crit = bushing_analytic(g, kMu, phi_crit);
    std::printf("\nОТВЕТ: λ_разрыва %.2f достигается при повороте внешней втулки на %.1f° (%.3f рад).\n",
                kLambdaBreak, phi_crit * 180.0 / kPi, phi_crit);
    std::printf("  Момент в этот момент: %.1f Н·м; сдвиг на внутренней поверхности γ = %.3f;\n",
                a_crit.torque / 1000.0, a_crit.gamma_inner);
    std::printf("  разрыв начинается у ВНУТРЕННЕЙ втулки: там γ в %.1f раза больше, чем у внешней.\n",
                std::pow(g.rubber_outer_radius() / g.rubber_inner_radius(), 2.0));

    // График λ_max(φ) с линией порога
    const double x0 = 70.0, y0 = 360.0, w = 620.0, h = 300.0;
    std::ofstream svg(out / "bushing_lambda.svg");
    svg << "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 760 420\" width=\"760\" height=\"420\" "
           "font-family=\"Segoe UI, Arial, sans-serif\">\n";
    svg << "<rect width=\"100%\" height=\"100%\" fill=\"#f8fafc\"/>\n";
    svg << "<line x1=\"" << x0 << "\" y1=\"" << y0 << "\" x2=\"" << (x0 + w) << "\" y2=\"" << y0
        << "\" stroke=\"#334155\"/>\n";
    svg << "<line x1=\"" << x0 << "\" y1=\"" << y0 << "\" x2=\"" << x0 << "\" y2=\"" << (y0 - h)
        << "\" stroke=\"#334155\"/>\n";
    auto px = [&](double deg) { return x0 + w * deg / 90.0; };
    auto py = [&](double lam) { return y0 - h * (lam - 1.0) / 2.5; };
    svg << "<line x1=\"" << x0 << "\" y1=\"" << py(kLambdaBreak) << "\" x2=\"" << (x0 + w) << "\" y2=\""
        << py(kLambdaBreak) << "\" stroke=\"#dc2626\" stroke-dasharray=\"6 4\"/>\n";
    svg << "<text x=\"" << (x0 + w - 150) << "\" y=\"" << (py(kLambdaBreak) - 8)
        << "\" font-size=\"12\" fill=\"#dc2626\">λ_разрыва = 2,60 (В-14)</text>\n";
    svg << "<polyline fill=\"none\" stroke=\"#1d4ed8\" stroke-width=\"2.5\" points=\"" << pts << "\"/>\n";
    svg << "<line x1=\"" << px(phi_crit * 180.0 / kPi) << "\" y1=\"" << y0 << "\" x2=\""
        << px(phi_crit * 180.0 / kPi) << "\" y2=\"" << py(kLambdaBreak) << "\" stroke=\"#111827\" "
        "stroke-dasharray=\"3 3\"/>\n";
    svg << "<text x=\"" << (px(phi_crit * 180.0 / kPi) + 6) << "\" y=\"" << (y0 - 10)
        << "\" font-size=\"12\" font-weight=\"bold\" fill=\"#111827\">разрыв при "
        << f1("%.0f", phi_crit * 180.0 / kPi) << "°</text>\n";
    for (int deg = 0; deg <= 90; deg += 15) {
        svg << "<line x1=\"" << px(deg) << "\" y1=\"" << y0 << "\" x2=\"" << px(deg) << "\" y2=\""
            << (y0 + 5) << "\" stroke=\"#334155\"/>\n";
        svg << "<text x=\"" << (px(deg) - 10) << "\" y=\"" << (y0 + 20) << "\" font-size=\"11\" "
            "fill=\"#334155\">" << deg << "°</text>\n";
    }
    for (double lam = 1.0; lam <= 3.51; lam += 0.5) {
        svg << "<line x1=\"" << (x0 - 5) << "\" y1=\"" << py(lam) << "\" x2=\"" << x0 << "\" y2=\""
            << py(lam) << "\" stroke=\"#334155\"/>\n";
        svg << "<text x=\"" << (x0 - 44) << "\" y=\"" << (py(lam) + 4) << "\" font-size=\"11\" "
            "fill=\"#334155\">" << f1("%.1f", lam) << "</text>\n";
    }
    svg << "<text x=\"" << (x0 + w / 2 - 60) << "\" y=\"" << (y0 + 44) << "\" font-size=\"12\" "
        "fill=\"#334155\">угол поворота внешней втулки</text>\n";
    svg << "<text x=\"20\" y=\"30\" font-size=\"13\" font-weight=\"bold\" fill=\"#111827\">Сайлентблок 60×2 / "
           "20×3, резина В-14: максимальное растяжение в резине</text>\n";
    svg << "<text x=\"20\" y=\"50\" font-size=\"11\" fill=\"#475569\">Точное решение Ривлина для несжимаемого "
           "нео-Гука (аналитика), FE-проверка не пройдена — см. протокол</text>\n";
    svg << "</svg>\n";

    std::printf("\nГрафик: %s\n", (out / "bushing_lambda.svg").string().c_str());
    return 0;
}
