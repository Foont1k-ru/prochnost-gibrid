// tests/units/test_units.cpp — проверка системы единиц (A-01, Ф-37).
//
// Смысл теста: система мм–т–с–Н–МПа должна быть САМОСОГЛАСОВАННОЙ, иначе
// коэффициенты придётся расставлять «на глаз» по коду, что запрещено п. 20.

#include <concepts>
#include <type_traits>

#include "pgib/units.hpp"
#include "tests/framework.hpp"

using namespace pgib::units;

namespace {

template <class A, class B>
concept Addable = requires(A a, B b) { a + b; };

// 1. Согласованность базовых единиц: 1 т · 1 мм / 1 с² = 1 Н
PGIB_TEST(base_force_consistent) {
    const auto m = Quantity<Dim::Mass>::from(1.0, u::t);
    const auto l = Quantity<Dim::Length>::from(1.0, u::mm);
    const auto t = Quantity<Dim::Time>::from(1.0, u::s);
    CHECK_NEAR(force_from_mass(m, l, t).in(u::N), 1.0, 1e-15);
}

// 2. 1 Н / 1 мм² = 1 МПа  (Ф-37)
PGIB_TEST(MPa_equals_N_per_mm2) {
    const auto a = area(Quantity<Dim::Length>::from(1.0, u::mm), Quantity<Dim::Length>::from(1.0, u::mm));
    CHECK_NEAR(stress(Quantity<Dim::Force>::from(1.0, u::N), a).in(u::MPa), 1.0, 1e-15);
}

// 3. Плотность: 1350 кг/м³ = 1,35e-9 т/мм³ (значение из карточки Ф-84)
PGIB_TEST(density_conversion) {
    const auto rho = Quantity<Dim::Density>::from(1350.0, u::kg_m3);
    CHECK_NEAR(rho.in(u::t_mm3), 1.35e-9, 1e-22);
    // обратный ход
    CHECK_NEAR(rho.in(u::kg_m3), 1350.0, 1e-9);
}

// 4. Дюймы -> мм: оправка 3 1/2" = 88,9 мм (LC-1)
PGIB_TEST(inch_to_mm) {
    const auto d = Quantity<Dim::Length>::from(3.5, u::inch);
    CHECK_NEAR(d.in(u::mm), 88.9, 1e-12);
}

// 5. Давление: 35 МПа = 35 000 кПа = 350 000 Па·100
PGIB_TEST(pressure_chain) {
    const auto p = Quantity<Dim::Stress>::from(35.0, u::MPa);
    CHECK_NEAR(p.in(u::kPa), 35000.0, 1e-9);
    CHECK_NEAR(p.in(u::Pa), 35.0e6, 1e-3);
    CHECK_NEAR(p.in(u::GPa), 0.035, 1e-12);
}

// 6. Угол и циклический шаг: 12 клыков -> 30°
PGIB_TEST(angle_step) {
    const auto step = Quantity<Dim::Angle>::from(360.0 / 12.0, u::deg);
    CHECK_NEAR(step.in(u::rad), detail::kPi / 6.0, 1e-12);
}

// 7. Момент и энергия
PGIB_TEST(moment_energy) {
    // 1 кН · 1 м = 1000 Н·м  (проверка, что kN и m дают именно Н·м, а не Н·мм)
    const auto m = moment(Quantity<Dim::Force>::from(1.0, u::kN), Quantity<Dim::Length>::from(1.0, u::m));
    CHECK_NEAR(m.in(u::Nm), 1000.0, 1e-9);
    CHECK_NEAR(m.in(u::Nmm), 1.0e6, 1e-3);
    const auto e = energy(Quantity<Dim::Force>::from(1.0, u::N), Quantity<Dim::Length>::from(1.0, u::mm));
    CHECK_NEAR(e.in(u::mJ), 1.0, 1e-12);
}

// 8. Объём: 1 м³ = 1000 л; расчётный объём оболочки 12 л
PGIB_TEST(volume_litre) {
    const auto v = volume(Quantity<Dim::Length>::from(1.0, u::m), Quantity<Dim::Length>::from(1.0, u::m),
                          Quantity<Dim::Length>::from(1.0, u::m));
    CHECK_NEAR(v.in(u::litre), 1000.0, 1e-6);
    CHECK_NEAR(Quantity<Dim::Volume>::from(12.0, u::litre).in(u::mm3), 12.0e6, 1e-3);
}

// 9. Круговой обход таблицы единиц: from(x).in(unit) == x
PGIB_TEST(roundtrip_units) {
    const Unit<Dim::Length> lengths[] = {u::mm, u::cm, u::m, u::inch};
    for (const auto& un : lengths) {
        CHECK_NEAR(Quantity<Dim::Length>::from(17.0, un).in(un), 17.0, 1e-12);
    }
    const Unit<Dim::Stress> stresses[] = {u::Pa, u::kPa, u::MPa, u::GPa};
    for (const auto& un : stresses) {
        CHECK_NEAR(Quantity<Dim::Stress>::from(7.0, un).in(un), 7.0, 1e-12);
    }
}

// 10. Размерности не смешиваются: на уровне типов это не компилируется
PGIB_TEST(dimensions_do_not_mix) {
    static_assert(!std::is_convertible_v<double, Quantity<Dim::Length>>,
                  "голый double не должен превращаться в размерную величину");
    static_assert(!Addable<Quantity<Dim::Length>, Quantity<Dim::Stress>>,
                  "длина и напряжение не складываются");
    static_assert(!Addable<Quantity<Dim::Length>, double>, "величина и число не складываются");
    static_assert(Addable<Quantity<Dim::Length>, Quantity<Dim::Length>>,
                  "однородные величины складываются");
    CHECK(true);
}

// 11. Арифметика и отношения
PGIB_TEST(arithmetic) {
    const auto a = Quantity<Dim::Length>::from(10.0, u::mm);
    const auto b = Quantity<Dim::Length>::from(0.5, u::cm);  // 5 мм
    CHECK_NEAR((a + b).in(u::mm), 15.0, 1e-12);
    CHECK_NEAR((a - b).in(u::mm), 5.0, 1e-12);
    CHECK_NEAR((a / b), 2.0, 1e-12);  // отношение — безразмерное
    CHECK_NEAR((a * 3.0).in(u::mm), 30.0, 1e-12);
    CHECK(a > b);
    CHECK(Quantity<Dim::Length>::zero() == Quantity<Dim::Length>::from(0.0, u::m));
}

// 12. Оформление по ГОСТ: запятая как десятичный разделитель
PGIB_TEST(format_gost) {
    CHECK_EQ_STR(format(Quantity<Dim::Length>::from(12.5, u::mm), u::mm, 2), "12,50 мм");
    CHECK_EQ_STR(format(Quantity<Dim::Stress>::from(8.72, u::MPa), u::MPa, 2), "8,72 МПа");
    CHECK_EQ_STR(format(Quantity<Dim::Force>::from(1500.0, u::N), u::kN, 3), "1,500 кН");
}

// 13. Температура и градиент (для Ф-35 «температура», Ф-29 «alpha»)
PGIB_TEST(temperature) {
    CHECK_NEAR(Quantity<Dim::Temperature>::from(20.0, u::degC).in(u::degC), 20.0, 1e-12);
    // alpha = 2,0e-4 1/°C на детали 500 мм при перепаде 50 °C -> 5,0 мм
    const double alpha = 2.0e-4;
    const double dT = 50.0;
    const auto elongation = Quantity<Dim::Length>::from(500.0, u::mm) * (alpha * dT);
    CHECK_NEAR(elongation.in(u::mm), 5.0, 1e-12);
    CHECK_NEAR(Quantity<Dim::TemperatureGradient>::from(3.0, u::degC_per_m).in(u::degC_per_mm), 0.003,
               1e-15);
}

}  // namespace
