// tests/data/test_result.cpp — проверка типа результата и кодов ошибок (НФ-04).

#include "pgib/result.hpp"
#include "tests/framework.hpp"

using namespace pgib;

namespace {

PGIB_TEST(result_holds_value) {
    const Result<int> r{42};
    CHECK(r.has_value());
    CHECK(static_cast<bool>(r));
    CHECK(r.value() == 42);
    CHECK(r.value_or(7) == 42);
}

PGIB_TEST(result_holds_error) {
    const Result<int> r{Error{ErrorCode::MaterialInvalid, "err.material.invalid", "nu = 0.7"}};
    CHECK(!r.has_value());
    CHECK(!static_cast<bool>(r));
    CHECK(r.error().code == ErrorCode::MaterialInvalid);
    CHECK(r.error().numeric_code() == 3001);
    CHECK_EQ_STR(r.error().message_key, "err.material.invalid");
    CHECK(r.value_or(7) == 7);
}

PGIB_TEST(status_error_codes_are_stable) {
    // Коды стабильны: они попадают в журнал и в службу поддержки.
    CHECK(static_cast<int>(ErrorCode::UnknownDimension) == 1001);
    CHECK(static_cast<int>(ErrorCode::UnitsAmbiguous) == 2003);
    CHECK(static_cast<int>(ErrorCode::MaterialInconsistent) == 3002);
    CHECK(static_cast<int>(ErrorCode::MemoryInsufficient) == 4003);
    CHECK(static_cast<int>(ErrorCode::ProjectSchemaTooNew) == 5002);
}

PGIB_TEST(status_ok_by_default) {
    const Status ok{};
    CHECK(ok.ok());
    CHECK(static_cast<bool>(ok));
    const Status bad = make_error(ErrorCode::ImportFailed, "err.cad.import", "нет тел в файле");
    CHECK(!bad.ok());
    CHECK(bad.error().code == ErrorCode::ImportFailed);
    CHECK_EQ_STR(bad.error().detail, "нет тел в файле");
}

}  // namespace
