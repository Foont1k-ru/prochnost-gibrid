// tests/solver/test_hyperelastic.cpp — верификация смешанной u/P-формулировки
// по аналитическим решениям (раздел 12 ТЗ, позиции «Одноосное/двухосное
// растяжение нео-Гука ≤ 1 %», «Куб ν = 0,49995, стеснённое сжатие ≤ 3 %»,
// «Кавитационный порог 5·C10 ≤ 10 %»).
//
// Все эталоны — аналитика для несжимаемого нео-Гука:
//   одноосное растяжение:  σ = μ (λ² − 1/λ),  λ_lat = λ^(−1/2),  J = 1
//   номинальное:           P = μ (λ − 1/λ²)
//   простой сдвиг:         σ₁₂ = μ γ
//   чистый сдвиг:          σ₁₁ − σ₃₃ = μ (λ² − 1/λ²)
//   плотность энергии:     W = μ/2 (λ² + 2/λ − 3)

#include <cmath>
#include <cstdio>
#include <vector>

#include "pgib/failure/damage.hpp"
#include "pgib/solver_fem/mixed_hyperelastic.hpp"
#include "tests/framework.hpp"

using namespace pgib::sfem;

namespace {

// --- Вспомогательные построения ---------------------------------------------

// Одноосная задача: сжатие/растяжение по z, боковые грани свободны.
// Закрепления выбраны так, чтобы однородное решение было кинематически
// допустимо, а жёсткие смещения и повороты устранены.
Problem make_uniaxial(int n, double lambda, double mu, double K, double h = 10.0) {
    Problem prob;
    prob.mesh = make_box(n, n, n, h, h, h);
    prob.material.iso = neo_hookean(mu);
    prob.material.K = K;
    prob.initialise();

    auto& m = prob.mesh;
    const double tol = 1e-12;
    for (std::size_t a = 0; a < m.node_count(); ++a) {
        const auto& X = m.X[a];
        if (X[2] < tol) prob.fix(prob.dof_u(a, 2), 0.0);                       // низ: u_z = 0
        if (X[2] > h - tol) prob.fix(prob.dof_u(a, 2), (lambda - 1.0) * h);    // верх: u_z = (λ−1)h
    }
    // Устранение жёстких смещений и поворотов (совместимо с однородным решением)
    for (std::size_t a = 0; a < m.node_count(); ++a) {
        const auto& X = m.X[a];
        const bool origin = X[0] < tol && X[1] < tol && X[2] < tol;
        const bool x_axis = std::fabs(X[0] - h) < tol && X[1] < tol && X[2] < tol;
        const bool top_origin = X[0] < tol && X[1] < tol && std::fabs(X[2] - h) < tol;
        if (origin) { prob.fix(prob.dof_u(a, 0), 0.0); prob.fix(prob.dof_u(a, 1), 0.0); }
        if (x_axis) prob.fix(prob.dof_u(a, 1), 0.0);
        if (top_origin) { prob.fix(prob.dof_u(a, 0), 0.0); prob.fix(prob.dof_u(a, 1), 0.0); }
    }
    return prob;
}

struct UniaxialResult {
    double sigma_zz = 0.0;    // напряжение Коши, МПа
    double P_zz = 0.0;        // номинальное (по начальной площади)
    double lambda_lat = 0.0;
    double J = 1.0;
    double W = 0.0;
    double lambda_max = 1.0;
    double hydrostatic_tension = 0.0;
    bool converged = false;
    int iterations = 0;
};

UniaxialResult run_uniaxial(int n, double lambda, double mu, double K, double h = 10.0) {
    Problem prob = make_uniaxial(n, lambda, mu, K, h);
    const NewtonReport rep = solve_newton(prob);

    UniaxialResult out;
    out.converged = rep.converged;
    out.iterations = rep.iterations;

    // Напряжения — по элементу (однородное поле: любой элемент даёт то же)
    const auto st = element_state(prob.mesh, 0, prob.u, prob.p[0], prob.material);
    out.sigma_zz = st.sigma.m[2][2];
    out.J = st.J_mean;
    out.W = st.W_iso_mean;
    out.lambda_max = st.lambda_max;
    out.hydrostatic_tension = st.hydrostatic_tension;

    // Номинальное напряжение из реакции на верхней грани
    const double area = h * h;
    out.P_zz = reaction(prob, 2) / area;

    // λ_lat — из перемещения углового узла на оси x
    for (std::size_t a = 0; a < prob.mesh.node_count(); ++a) {
        const auto& X = prob.mesh.X[a];
        if (std::fabs(X[0] - h) < 1e-12 && X[1] < 1e-12 && X[2] < 1e-12) {
            out.lambda_lat = 1.0 + prob.u[a][0] / h;
            break;
        }
    }
    return out;
}

// --- Тесты -------------------------------------------------------------------

// 1. Одноосное растяжение нео-Гука (эталон ≤ 1 %)
PGIB_TEST(uniaxial_tension_neo_hookean) {
    const double mu = 2.0, lambda = 1.5;
    const auto r = run_uniaxial(1, lambda, mu, 2000.0);
    CHECK(r.converged);
    const double sigma_exact = mu * (lambda * lambda - 1.0 / lambda);
    // Допуск 3e-3, а не 1e-3: при K = 2000 МПа материал слабо сжимаем, и отличие
    // от несжимаемой формулы имеет порядок σ/K ≈ 1,6e-3. Это физика, а не ошибка
    // дискретизации — чистая сходимость к несжимаемому пределу проверяется
    // отдельным тестом incompressible_limit_as_K_grows (ошибка < 1e-5 при K = 2e6).
    CHECK_NEAR(r.sigma_zz / sigma_exact, 1.0, 3e-3);
    CHECK_NEAR(r.lambda_lat, std::pow(lambda, -0.5), 2e-3);
    CHECK_NEAR(r.J, 1.0, 2e-3);
}

// 2. Одноосное сжатие (тот же эталон, λ < 1)
PGIB_TEST(uniaxial_compression_neo_hookean) {
    const double mu = 2.0, lambda = 0.7;
    const auto r = run_uniaxial(1, lambda, mu, 2000.0);
    CHECK(r.converged);
    const double sigma_exact = mu * (lambda * lambda - 1.0 / lambda);
    CHECK(sigma_exact < 0.0);
    CHECK_NEAR(r.sigma_zz / sigma_exact, 1.0, 1e-3);
    CHECK_NEAR(r.lambda_lat, std::pow(lambda, -0.5), 2e-3);
}

// 3. Предел несжимаемости: при росте K решение стремится к аналитике
//    (проверяет, что мы не «подгоняем» K ради сходимости — Ф-41)
PGIB_TEST(incompressible_limit_as_K_grows) {
    const double mu = 2.0, lambda = 1.5;
    const double sigma_exact = mu * (lambda * lambda - 1.0 / lambda);
    const double e_soft = std::fabs(run_uniaxial(1, lambda, mu, 2.0e3).sigma_zz / sigma_exact - 1.0);
    const double e_stiff = std::fabs(run_uniaxial(1, lambda, mu, 2.0e6).sigma_zz / sigma_exact - 1.0);
    CHECK(e_stiff < e_soft);          // ошибка убывает с ростом K
    CHECK(e_stiff < 1e-5);            // и становится пренебрежимой
}

// 4. ν = 0,49995 (K/G ≈ 1e4): нет запирания, J = 1, аналитика выполняется
PGIB_TEST(near_incompressible_no_locking) {
    const double mu = 2.0;                    // G = μ/2 = 1 МПа
    const double nu = 0.49995;
    // ВАЖНО (дефект, найденный при сборке библиотеки материалов): для нео-Гука
    // G = mu0 = 2·C10. Прежняя запись G = mu/2 занижала K вдвое, из-за чего
    // объявленное ν = 0,49995 не соответствовало фактической сжимаемости модели
    // (реально получалось ν ≈ 0,4999). Ошибка не влияла на знак результата,
    // но делала «эталон» не тем, что заявлен.
    const double G = mu;
    const double K = 2.0 * G * (1.0 + nu) / (3.0 * (1.0 - 2.0 * nu));  // ≈ 20 000 МПа
    const double lambda = 0.8;
    const auto r = run_uniaxial(1, lambda, mu, K);
    CHECK(r.converged);
    const double sigma_exact = mu * (lambda * lambda - 1.0 / lambda);
    CHECK_NEAR(r.sigma_zz / sigma_exact, 1.0, 1e-4);
    CHECK_NEAR(r.J, 1.0, 1e-4);
    // Запирание проявилось бы как кратное занижение перемещений/напряжений;
    // здесь λ_lat должен равняться λ^(−1/2) с высокой точностью.
    CHECK_NEAR(r.lambda_lat, std::pow(lambda, -0.5), 1e-4);
}

// 5. Независимость от сетки (конечнодеформационный patch-test):
//    1×1×1, 2×2×2 и 3×3×3 дают одно и то же однородное решение
PGIB_TEST(mesh_independence_patch_test) {
    const double mu = 2.0, lambda = 1.4, K = 2000.0;
    const auto r1 = run_uniaxial(1, lambda, mu, K);
    const auto r2 = run_uniaxial(2, lambda, mu, K);
    const auto r3 = run_uniaxial(3, lambda, mu, K);
    CHECK(r1.converged && r2.converged && r3.converged);
    CHECK_NEAR(r2.sigma_zz / r1.sigma_zz, 1.0, 1e-6);
    CHECK_NEAR(r3.sigma_zz / r1.sigma_zz, 1.0, 1e-6);
    CHECK_NEAR(r3.lambda_lat / r1.lambda_lat, 1.0, 1e-6);
}

// 6. Простой сдвиг: σ₁₂ = μγ, давление ≈ 0 (изохорная деформация)
PGIB_TEST(simple_shear) {
    const double mu = 2.0, gamma = 0.5, h = 10.0;
    Problem prob;
    prob.mesh = make_box(1, 1, 1, h, h, h);
    prob.material.iso = neo_hookean(mu);
    prob.material.K = 2000.0;
    prob.initialise();
    // Предписываем u = γ·z·e_x на всех узлах (однородный сдвиг)
    for (std::size_t a = 0; a < prob.mesh.node_count(); ++a) {
        const double z = prob.mesh.X[a][2];
        prob.fix(prob.dof_u(a, 0), gamma * z);
        prob.fix(prob.dof_u(a, 1), 0.0);
        prob.fix(prob.dof_u(a, 2), 0.0);
    }
    solve_newton(prob);
    const auto st = element_state(prob.mesh, 0, prob.u, prob.p[0], prob.material);
    CHECK_NEAR(st.sigma.m[0][2] / (mu * gamma), 1.0, 1e-6);
    CHECK_NEAR(st.J_mean, 1.0, 1e-9);
    CHECK_NEAR(st.pressure, 0.0, 1e-6);  // изохорно: давление не нужно
}

// 7. Чистый сдвиг: σ₁₁ − σ₃₃ = μ(λ² − 1/λ²)
PGIB_TEST(pure_shear) {
    const double mu = 2.0, lambda = 1.6, h = 10.0;
    Problem prob;
    prob.mesh = make_box(1, 1, 1, h, h, h);
    prob.material.iso = neo_hookean(mu);
    prob.material.K = 2000.0;
    prob.initialise();
    for (std::size_t a = 0; a < prob.mesh.node_count(); ++a) {
        const auto& X = prob.mesh.X[a];
        prob.fix(prob.dof_u(a, 0), (lambda - 1.0) * X[0]);
        prob.fix(prob.dof_u(a, 1), 0.0);
        prob.fix(prob.dof_u(a, 2), (1.0 / lambda - 1.0) * X[2]);
    }
    solve_newton(prob);
    const auto st = element_state(prob.mesh, 0, prob.u, prob.p[0], prob.material);
    const double exact = mu * (lambda * lambda - 1.0 / (lambda * lambda));
    CHECK_NEAR((st.sigma.m[0][0] - st.sigma.m[2][2]) / exact, 1.0, 1e-6);
    CHECK_NEAR(st.J_mean, 1.0, 1e-9);
}

// 8. Плотность энергии: W = μ/2 (λ² + 2/λ − 3)
PGIB_TEST(energy_matches_analytic) {
    const double mu = 2.0, lambda = 1.5;
    const auto r = run_uniaxial(2, lambda, mu, 2000.0);
    const double W_exact = 0.5 * mu * (lambda * lambda + 2.0 / lambda - 3.0);
    CHECK_NEAR(r.W / W_exact, 1.0, 5e-3);
}

// 9. Кавитационный порог 5·C10 (Ф-46, допуск по Ф-71 ≤ 10 %).
//    Однородное всестороннее растяжение: F = λ·I, изохорная часть нулевая,
//    поэтому гидростатическое растяжение равно p = K(λ³ − 1).
PGIB_TEST(cavitation_threshold_5C10) {
    const double C10 = 1.0, mu = 2.0 * C10;
    const double K = 2000.0;
    const double threshold = 5.0 * C10;                     // = 5 МПа
    const double lambda_crit = std::cbrt(1.0 + threshold / K);

    // λ подбирается так, чтобы гидростатическое растяжение было на 2 % выше порога:
    // K(λ³ − 1) = 1,02·threshold. Умножать на 1,02 сам λ нельзя — при K = 2000 МПа
    // и пороге 5 МПа это даёт давление в 25 раз выше порога.
    (void)lambda_crit;
    const double lambda = std::cbrt(1.0 + 1.02 * threshold / K);
    const double h = 10.0;
    Problem prob;
    prob.mesh = make_box(2, 2, 2, h, h, h);
    prob.material.iso = neo_hookean(mu);
    prob.material.K = K;
    prob.initialise();
    for (std::size_t a = 0; a < prob.mesh.node_count(); ++a) {
        const auto& X = prob.mesh.X[a];
        const bool boundary = X[0] < 1e-12 || std::fabs(X[0] - h) < 1e-12 || X[1] < 1e-12 ||
                              std::fabs(X[1] - h) < 1e-12 || X[2] < 1e-12 || std::fabs(X[2] - h) < 1e-12;
        if (!boundary) continue;
        for (int i = 0; i < 3; ++i) prob.fix(prob.dof_u(a, i), (lambda - 1.0) * X[static_cast<std::size_t>(i)]);
    }
    const NewtonReport rep = solve_newton(prob);
    CHECK(rep.converged);

    const auto st = element_state(prob.mesh, 0, prob.u, prob.p[0], prob.material);
    // Гидростатическое растяжение должно равняться K(λ³−1) с точностью до знака
    const double expected = K * (std::pow(lambda, 3.0) - 1.0);
    CHECK_NEAR(st.hydrostatic_tension / expected, 1.0, 1e-6);

    // Критерий: на 2 % выше порога индикатор должен превысить единицу
    auto crit = pgib::failure::Criteria::from_C10_estimate(C10);
    const auto ev = pgib::failure::evaluate(crit, {st.lambda_max, st.W_iso_mean, st.hydrostatic_tension});
    CHECK(ev.criterion_active);
    CHECK_NEAR(ev.D_cavitation, st.hydrostatic_tension / threshold, 1e-12);
    // И порог 5·C10 воспроизводится с допуском лучше 10 % (Ф-71)
    CHECK_NEAR(ev.D_cavitation, 1.02, 0.10);
}

// 10. Индикатор повреждения по главному растяжению (ПС-1, Ф-45/Ф-49)
PGIB_TEST(damage_indicator_stretch_history) {
    auto crit = pgib::failure::Criteria{};
    crit.has_lambda_break = true;
    crit.lambda_break = 2.0;
    pgib::failure::Tracker tracker(crit);

    const double mu = 2.0;
    double D_at_1p9 = 0.0;
    double lambda_at_event = 0.0;
    int events = 0;

    // Нагружение шагами по λ: 1,1 → 2,2
    for (int step = 0; step <= 12; ++step) {
        const double lambda = 1.1 + 0.1 * step;
        Problem prob = make_uniaxial(1, lambda, mu, 2000.0);
        const NewtonReport rep = solve_newton(prob);
        if (!rep.converged) continue;
        const auto st = element_state(prob.mesh, 0, prob.u, prob.p[0], prob.material);
        const auto upd = tracker.update(step, lambda, {st.lambda_max, st.W_iso_mean, st.hydrostatic_tension});
        if (std::fabs(lambda - 1.9) < 1e-9) D_at_1p9 = upd.D;
        if (upd.new_event) { ++events; if (lambda_at_event == 0.0) lambda_at_event = lambda; }
    }

    // D нормирован по УДЛИНЕНИЮ: D = (λ−1)/(λ_break−1) = (1,9−1)/(2,0−1) = 0,9.
    // Прежняя норма λ_max/λ_break = 0,95 давала «38 % повреждения» у ненагруженной
    // детали (λ = 1) — дефект найден 12.11.2026 при построении кадров зарождения.
    CHECK_NEAR(D_at_1p9, 0.9, 5e-3);

    // Регрессия на тот самый дефект: в недеформированном состоянии D = 0, а не 1/λ_break
    {
        Problem prob = make_uniaxial(1, 1.0, mu, 2000.0);
        const NewtonReport rep = solve_newton(prob);
        CHECK(rep.converged);
        const auto st = element_state(prob.mesh, 0, prob.u, prob.p[0], prob.material);
        const auto ev = pgib::failure::evaluate(crit, {st.lambda_max, st.W_iso_mean, st.hydrostatic_tension});
        CHECK_NEAR(ev.D, 0.0, 1e-12);
    }
    // Событие фиксируется на первом шаге, где D ≥ 1: это λ чуть выше λ_break
    // (сетка шагов 0,1, поэтому допускаем попадание в интервал [λ_break; λ_break+0,2])
    CHECK(lambda_at_event >= 2.0 - 1e-6);
    CHECK(lambda_at_event <= 2.2 + 1e-6);
    CHECK(events == 1);                             // и не дублируется на каждом шаге
    CHECK(tracker.failure_occurred());
    CHECK_EQ_STR(std::string(pgib::failure::criterion_name(
                     tracker.events().empty() ? pgib::failure::Criterion::None
                                              : tracker.events().front().criterion)),
                 std::string("ПС-1: разрыв резины по главному растяжению"));
}

// 11. Баланс сил: реакции сверху и снизу равны по модулю
PGIB_TEST(reaction_balance) {
    const double lambda = 1.3, h = 10.0;
    Problem prob = make_uniaxial(2, lambda, 2.0, 2000.0);
    solve_newton(prob);
    const double sum = reaction(prob, 2);  // сумма реакций по всем закреплённым u_z
    // Внешних сил нет, поэтому суммарная реакция по направлению z равна нулю.
    // Масштаб допуска задаётся величиной самой реакции, а не самой суммой.
    const auto st = element_state(prob.mesh, 0, prob.u, prob.p[0], prob.material);
    const double scale = std::fabs(st.sigma.m[2][2]) * h * h;
    CHECK(scale > 0.0);
    CHECK_NEAR(sum, 0.0, 1e-6 * scale);
}

}  // namespace
