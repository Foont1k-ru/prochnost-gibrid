// tests/solver/test_bushing.cpp — сайлентблок: геометрия и точное решение Ривлина.
//
// Проверяется то, что можно проверить без FE-модели: размеры по заданию заказчика
// и формулы осесимметричного сдвига несжимаемого нео-Гука. FE-модель сайлентблока
// НЕ верифицирована (см. docs/ПРОТОКОЛ_САЙЛЕНТБЛОК.md): энергия выходит в 8 раз
// больше аналитики из-за нефизичного радиального движения внутри стенки.

#include <cmath>
#include <cstdio>

#include "pgib/solver_fem/bushing.hpp"
#include "pgib/solver_fem/mixed_hyperelastic.hpp"
#include "tests/framework.hpp"

using namespace pgib::sfem;

namespace {
constexpr double kC10 = 1.2072;       // резина В-14, оценка по твёрдости (A-22)
constexpr double kMu = 2.0 * kC10;
constexpr double kPi = 3.14159265358979323846;
}  // namespace

// 1. Геометрия по заданию: 60×2 снаружи, 20×3 внутри, длины 60 и 65
PGIB_TEST(bushing_geometry_from_task) {
    BushingGeometry g;
    CHECK_NEAR(g.rubber_inner_radius(), 13.0, 1e-12);   // 20/2 + 3
    CHECK_NEAR(g.rubber_outer_radius(), 28.0, 1e-12);   // 60/2 − 2
    CHECK_NEAR(g.rubber_thickness(), 15.0, 1e-12);
    CHECK_NEAR(g.rubber_length(), 60.0, 1e-12);
    CHECK_NEAR(g.inner_protrusion(), 2.5, 1e-12);       // (65 − 60)/2
}

// 2. Момент Ривлина согласован с энергией: M = dW/dφ
//    W(φ) = C10·π·L·C²·(1/r_в² − 1/r_н²),  C = 2φ/(1/r_в² − 1/r_н²)
PGIB_TEST(bushing_torque_matches_energy_derivative) {
    BushingGeometry g;
    const double ri = g.rubber_inner_radius(), ro = g.rubber_outer_radius(), L = g.rubber_length();
    const double phi = 0.1;
    const double C = 2.0 * phi / (1.0 / (ri * ri) - 1.0 / (ro * ro));
    const double W = kC10 * kPi * L * C * C * (1.0 / (ri * ri) - 1.0 / (ro * ro));  // Н·мм
    const double M_analytic = 2.0 * kPi * L * kMu * C;                             // Н·мм
    CHECK_NEAR(2.0 * W / phi, M_analytic, 1e-9 * M_analytic);   // dW/dφ = 2W/φ при W ∝ φ²
    // И через напряжение на внутренней поверхности
    const auto a = bushing_analytic(g, kMu, phi);
    const double M_stress = 2.0 * kPi * L * ri * ri * kMu * a.gamma_inner;
    CHECK_NEAR(M_stress, M_analytic, 1e-9 * M_analytic);
}

// 3. Меры сдвига: γ ∝ 1/r², λ_max по главным удлинениям
PGIB_TEST(bushing_shear_decays_as_inverse_square) {
    BushingGeometry g;
    const auto a = bushing_analytic(g, kMu, 0.5);
    const double ri = g.rubber_inner_radius(), ro = g.rubber_outer_radius();
    CHECK_NEAR(a.gamma_inner * ri * ri, a.gamma_outer * ro * ro, 1e-9 * a.gamma_inner * ri * ri);
    CHECK(a.gamma_inner > a.gamma_outer);
    // λ_max ↔ γ — взаимно обратные соотношения
    for (double gam : {0.1, 0.5, 1.0, 2.0}) {
        const double lm = lambda_max_from_shear(gam);
        CHECK_NEAR(shear_for_lambda_max(lm), gam, 1e-6);
    }
    CHECK_NEAR(lambda_max_from_shear(0.0), 1.0, 1e-15);
}

// 4. Ответ на вопрос заказчика: при каком угле поворота резина рвётся
PGIB_TEST(bushing_tear_angle_for_v14) {
    BushingGeometry g;
    const double lambda_break = 2.6;   // В-14: 1 + δ/100 при δ = 160 % (ТУ 38 0051166-98)
    const double phi_crit = bushing_angle_for_lambda(g, lambda_break);
    const double deg = phi_crit * 180.0 / kPi;
    std::printf("    λ_разрыва = %.2f достигается при повороте %.1f° (%.3f рад)\n", lambda_break, deg, phi_crit);
    // Проверка «туда-обратно»: в найденном угле λ_max действительно равен λ_разрыва
    const auto a = bushing_analytic(g, kMu, phi_crit);
    CHECK_NEAR(a.lambda_max_inner, lambda_break, 1e-6);
    CHECK(deg > 40.0 && deg < 60.0);   // порядок величины: десятки градусов, не единицы

    // Момент при разрыве и в начале — для отчёта
    const double M_crit = bushing_analytic(g, kMu, phi_crit).torque / 1000.0;
    std::printf("    момент при разрыве: %.1f Н·м; при 10°: %.1f Н·м\n", M_crit,
                bushing_analytic(g, kMu, 10.0 * kPi / 180.0).torque / 1000.0);
    CHECK(M_crit > 0.0);
}

// 5. Внутренняя поверхность нагружена сильнее: там и начнётся разрыв
PGIB_TEST(bushing_inner_surface_is_critical) {
    BushingGeometry g;
    const auto a10 = bushing_analytic(g, kMu, 10.0 * kPi / 180.0);
    const auto a20 = bushing_analytic(g, kMu, 20.0 * kPi / 180.0);
    CHECK(a20.lambda_max_inner > a10.lambda_max_inner);
    CHECK(a10.lambda_max_inner > 1.0);
    // Отношение растяжений на внутренней и внешней поверхности при малом угле ≈ (r_н/r_в)²
    const double ratio = a10.gamma_inner / a10.gamma_outer;
    CHECK_NEAR(ratio, std::pow(g.rubber_outer_radius() / g.rubber_inner_radius(), 2.0), 1e-9);
}
