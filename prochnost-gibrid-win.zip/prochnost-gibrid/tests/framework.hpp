// tests/framework.hpp — минимальная система тестов без внешних зависимостей.
//
// Обоснование: на Э1 не тянем Catch2/GoogleTest в поставку и в CI, чтобы сборка
// проверялась без сети (A-09, НФ-06). Замена на Catch2 возможна позже без
// изменения логики тестов — интерфейс совместим по смыслу.

#pragma once

#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

namespace pgib::test {

struct Case {
    const char* name;
    void (*fn)();
};

inline std::vector<Case>& registry() {
    static std::vector<Case> r;
    return r;
}
inline int& failure_count() {
    static int f = 0;
    return f;
}
inline int& check_count() {
    static int c = 0;
    return c;
}
inline const char*& current_case() {
    static const char* n = "";
    return n;
}

struct Registrar {
    Registrar(const char* name, void (*fn)()) { registry().push_back({name, fn}); }
};

inline int run_all() {
    std::printf("Тестов зарегистрировано: %zu\n\n", registry().size());
    for (const auto& c : registry()) {
        current_case() = c.name;
        const int before = failure_count();
        c.fn();
        std::printf("%s  %s\n", (failure_count() == before) ? "[ OK ]" : "[ПРОВАЛ]", c.name);
    }
    std::printf("\nПроверок: %d, провалов: %d\n", check_count(), failure_count());
    if (failure_count() == 0) {
        std::printf("ИТОГ: все тесты пройдены\n");
        return 0;
    }
    std::printf("ИТОГ: есть провалы\n");
    return 1;
}

}  // namespace pgib::test

#define PGIB_TEST(name)                                                              \
    static void name();                                                              \
    static ::pgib::test::Registrar pgib_reg_##name(#name, &name);                    \
    static void name()

#define CHECK(expr)                                                                  \
    do {                                                                             \
        ++::pgib::test::check_count();                                               \
        if (!(expr)) {                                                               \
            ++::pgib::test::failure_count();                                         \
            std::printf("    провал: %s:%d  %s\n", __FILE__, __LINE__, #expr);       \
        }                                                                            \
    } while (0)

#define CHECK_NEAR(actual, expected, eps)                                            \
    do {                                                                             \
        ++::pgib::test::check_count();                                               \
        const double a_ = static_cast<double>(actual);                               \
        const double e_ = static_cast<double>(expected);                             \
        if (!(std::fabs(a_ - e_) <= (eps))) {                                        \
            ++::pgib::test::failure_count();                                         \
            std::printf("    провал: %s:%d  |%.17g - %.17g| > %.3g\n", __FILE__,     \
                        __LINE__, a_, e_, static_cast<double>(eps));                 \
        }                                                                            \
    } while (0)

#define CHECK_EQ_STR(actual, expected)                                               \
    do {                                                                             \
        ++::pgib::test::check_count();                                               \
        const std::string a_ = (actual);                                             \
        const std::string e_ = (expected);                                           \
        if (a_ != e_) {                                                              \
            ++::pgib::test::failure_count();                                         \
            std::printf("    провал: %s:%d  \"%s\" != \"%s\"\n", __FILE__, __LINE__, \
                        a_.c_str(), e_.c_str());                                     \
        }                                                                            \
    } while (0)
