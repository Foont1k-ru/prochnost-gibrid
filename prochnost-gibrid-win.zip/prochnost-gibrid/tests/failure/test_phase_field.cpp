// tests/failure/test_phase_field.cpp — фазовое поле разрушения (В-10).
//
// Главная проверка — ОБЪЕКТИВНОСТЬ ПО СЕТКЕ: момент/нагрузка разрушения не должны
// зависеть от размера элемента, если характерная длина l_c фиксирована. Индикатор
// повреждения этого не даёт (разброс 18,9 %, ПРОТОКОЛ_Э8 §3), фазовое поле — даёт.
//
// Эталоны:
//   пиковое номинальное напряжение AT2 в 1D:  σ_c = ½·√(E·G_c/(2·l_c))
//   деградация: g(d) = (1−d)² + k
//   профиль: d(x) = exp(−|x − x₀|/l_c)

#include <cmath>
#include <cstdio>
#include <vector>

#include "pgib/failure/phase_field.hpp"
#include "pgib/solver_fem/damage_adapter.hpp"
#include "pgib/solver_fem/mixed_hyperelastic.hpp"
#include "pgib/solver_fem/phase_field_solver.hpp"
#include "pgib/solver_fem/specimen.hpp"
#include "tests/framework.hpp"

using namespace pgib::sfem;
namespace fail = pgib::failure;

namespace {

constexpr double kC10 = 1.2072;
constexpr double kMu = 2.0 * kC10;
constexpr double kNu = 0.4995;
constexpr double kK = 2.0 * kMu * (1.0 + kNu) / (3.0 * (1.0 - 2.0 * kNu));
constexpr double kE = 3.0 * kMu;   // малые деформации, ν ≈ 0,5
constexpr double kGcBar = 1.0;     // Н/мм
constexpr double kLcBar = 8.0;     // мм

// Брус 1×1×L с ослабленным центральным элементом (начальная неоднородность 10 %).
// Без неё однородная ветка повреждения остаётся равновесной и трещина не зарождается.
Problem make_bar(int nz, double L = 40.0) {
    Problem p;
    p.mesh = make_box(1, 1, nz, 1.0, 1.0, L);
    p.material.iso = neo_hookean(kMu);
    p.material.K = kK;
    setup_uniaxial(p, L, 1.0);
    return p;
}

struct BarRun {
    double P_max = 0.0;
    double lambda_at_peak = 0.0;
    double lambda_reached = 1.0;  // докуда реально досчитали
    double d_max = 0.0;
    bool newton_ok = true;        // сошлось на всём пути до конца диапазона
};

BarRun run_bar(int nz, double lambda_end, double dlam = 0.005) {
    constexpr double L = 40.0;
    Problem p = make_bar(nz, L);
    PhaseFieldState st;
    phase_field_init(p, st);
    fail::PhaseFieldParams pf;
    pf.enabled = true;
    pf.G_c = kGcBar;
    pf.l_c = kLcBar;
    st.Gc.assign(p.mesh.element_count(), kGcBar);
    st.Gc[p.mesh.element_count() / 2] = 0.9 * kGcBar;

    BarRun r;
    for (double lam = 1.0; lam <= lambda_end + 1e-12; lam += dlam) {
        set_stretch(p, lam, L);
        const auto rep = solve_staggered(p, pf, st);
        if (!rep.newton_ok) { r.newton_ok = false; break; }
        r.lambda_reached = lam;
        const double P = top_reaction(p, L);   // площадь 1×1 мм
        if (P > r.P_max) { r.P_max = P; r.lambda_at_peak = lam; }
    }
    r.d_max = phase_field_max(st);
    return r;
}

}  // namespace

// 1. Деградация и необратимость — базовые соотношения метода
PGIB_TEST(phase_field_degradation_and_irreversibility) {
    CHECK_NEAR(fail::degradation(0.0, 0.0), 1.0, 1e-15);      // целый материал
    CHECK_NEAR(fail::degradation(1.0, 0.0), 0.0, 1e-15);      // полный разрыв
    CHECK_NEAR(fail::degradation(1.0, 1e-6), 1e-6, 1e-18);    // остаточная жёсткость
    CHECK(fail::degradation(0.3, 0.0) > fail::degradation(0.6, 0.0));
    // Повреждение не зарастает
    CHECK_NEAR(fail::irreversible(0.2, 0.7), 0.7, 1e-15);
    CHECK_NEAR(fail::irreversible(0.9, 0.7), 0.9, 1e-15);
}

// 2. Обратимость формул «прочность ↔ энергия разрушения»
PGIB_TEST(phase_field_peak_stress_roundtrip) {
    const double sigma_c = 0.3364;
    const double Gc = fail::Gc_from_peak_stress_1d(kE, sigma_c, kLcBar);
    CHECK_NEAR(fail::peak_stress_1d(kE, Gc, kLcBar), sigma_c, 1e-12);
    // Прочность растёт как корень из G_c и падает как корень из l_c — обе связи
    // должны сохраняться, иначе калибровка по эксперименту развалится.
    CHECK(fail::peak_stress_1d(kE, 4.0 * Gc, kLcBar) > fail::peak_stress_1d(kE, Gc, kLcBar));
    CHECK(fail::peak_stress_1d(kE, Gc, 4.0 * kLcBar) < fail::peak_stress_1d(kE, Gc, kLcBar));
}

// 3. Допустимость параметров: l_c должна перекрывать хотя бы 2 элемента
PGIB_TEST(phase_field_admissibility) {
    fail::PhaseFieldParams pf;
    pf.enabled = true;
    pf.G_c = 1.0;
    pf.l_c = 8.0;
    CHECK(pf.admissible(1.0));      // l_c = 8 мм при h = 1 мм — да
    CHECK(!pf.admissible(5.0));     // l_c = 8 мм при h = 5 мм — нет
    CHECK(pf.why_inadmissible(5.0).find("двух элементов") != std::string::npos);
    pf.l_c = 0.0;
    CHECK(!pf.admissible(1.0));
    CHECK(pf.why_inadmissible(1.0).find("l_c") != std::string::npos);
}

// 4. Пиковая нагрузка бруса против аналитики AT2 (1D)
PGIB_TEST(phase_field_bar_peak_matches_theory) {
    const auto r = run_bar(20, 1.10);
    // Требование к тесту: досчитали ЗА пик. Дальше по ветке спада Ньютон может
    // сдаться (материал в полосе почти полностью деградирован) — на пиковую
    // нагрузку это не влияет, и притворяться, что сошлось, тест не должен.
    CHECK(r.lambda_reached > r.lambda_at_peak);
    const double sigma_c = fail::peak_stress_1d(kE, kGcBar, kLcBar);
    std::printf("    P_max = %.4f МПа, аналитика σ_c = %.4f МПа, отклонение %+.1f %%\n",
                r.P_max, sigma_c, 100.0 * (r.P_max / sigma_c - 1.0));
    // Допуск 15 % с обоснованием: аналитика выведена для ЛИНЕЙНО-УПРУГОГО материала
    // и однородного тела, а расчёт — нео-Гук при ε ≈ 7 %, с ослабленным на 10 %
    // элементом (σ_c ∝ √G_c, то есть −5 % только от неоднородности).
    CHECK_NEAR(r.P_max / sigma_c, 1.0, 0.15);
    CHECK(r.P_max > 0.0);
}

// 5. ГЛАВНОЕ: нагрузка разрушения объективна по сетке (требование Э8 ≤ 15 %)
PGIB_TEST(phase_field_mesh_objective) {
    const auto r10 = run_bar(10, 1.10);
    const auto r20 = run_bar(20, 1.10);
    const auto r40 = run_bar(40, 1.10);
    // На всех трёх сетках досчитали за пик — иначе сравнивать нечего
    CHECK(r10.lambda_reached > r10.lambda_at_peak);
    CHECK(r20.lambda_reached > r20.lambda_at_peak);
    CHECK(r40.lambda_reached > r40.lambda_at_peak);

    const double lo = std::min({r10.P_max, r20.P_max, r40.P_max});
    const double hi = std::max({r10.P_max, r20.P_max, r40.P_max});
    const double spread = (hi - lo) / hi;
    std::printf("    P_max: 10 эл. = %.4f, 20 эл. = %.4f, 40 эл. = %.4f МПа; разброс %.2f %%\n",
                r10.P_max, r20.P_max, r40.P_max, spread * 100.0);
    // Индикатор повреждения давал на этой же задаче 18,9 % — здесь разброс доли процента.
    CHECK(spread <= 0.15);       // требование Э8
    CHECK(spread <= 0.05);       // фактически полученное качество
}

// 6. Необратимость в расчёте: после разгрузки повреждение не исчезает
PGIB_TEST(phase_field_damage_does_not_heal) {
    constexpr double L = 40.0;
    Problem p = make_bar(20, L);
    PhaseFieldState st;
    phase_field_init(p, st);
    fail::PhaseFieldParams pf;
    pf.enabled = true;
    pf.G_c = kGcBar;
    pf.l_c = kLcBar;
    st.Gc.assign(p.mesh.element_count(), kGcBar);
    st.Gc[p.mesh.element_count() / 2] = 0.9 * kGcBar;

    for (double lam = 1.0; lam <= 1.081; lam += 0.01) {
        set_stretch(p, lam, L);
        const auto r = solve_staggered(p, pf, st);
        CHECK(r.newton_ok);
        if (!r.newton_ok) return;
    }
    const double d_loaded = phase_field_max(st);
    CHECK(d_loaded > 0.0);

    // Разгрузка ступенями: прыжок 1,08 → 1,00 одним шагом Ньютон не берёт
    // (деградированный материал очень мягкий, шаг по перемещению слишком велик).
    bool unload_ok = true;
    for (double lam = 1.07; lam >= 1.0001; lam -= 0.02) {
        set_stretch(p, lam, L);
        const auto ur = solve_staggered(p, pf, st);
        if (!ur.newton_ok) { unload_ok = false; break; }
    }
    CHECK(unload_ok);
    const double d_unloaded = phase_field_max(st);
    std::printf("    d при нагрузке = %.3f, после разгрузки = %.3f\n", d_loaded, d_unloaded);
    CHECK(d_unloaded >= d_loaded - 1e-12);   // не зарастает
}

// 7. В сжатии повреждения нет (движущая сила — только при растяжении)
PGIB_TEST(phase_field_no_damage_in_compression) {
    constexpr double L = 40.0;
    Problem p = make_bar(10, L);
    PhaseFieldState st;
    phase_field_init(p, st);
    fail::PhaseFieldParams pf;
    pf.enabled = true;
    pf.G_c = kGcBar;
    pf.l_c = kLcBar;
    st.Gc.assign(p.mesh.element_count(), kGcBar);

    for (double lam : {0.95, 0.90, 0.85}) {
        set_stretch(p, lam, L);
        const auto r = solve_staggered(p, pf, st);
        CHECK(r.newton_ok);
    }
    CHECK_NEAR(phase_field_max(st), 0.0, 1e-12);
}

// 8. Трещина возникает у концентратора и нагрузка после пика падает
PGIB_TEST(phase_field_crack_at_notch) {
    Problem p;
    p.mesh = make_notched_bar(6, 2, 6, 6.0, 2.0, 6.0, 2, 2, 2);
    p.material.iso = neo_hookean(kMu);
    p.material.K = kK;
    setup_uniaxial(p, 6.0, 6.0);

    PhaseFieldState st;
    phase_field_init(p, st);
    fail::PhaseFieldParams pf;
    pf.enabled = true;
    pf.G_c = 2.0;
    pf.l_c = 3.0;
    st.Gc.assign(p.mesh.element_count(), 2.0);

    double P_peak = 0.0, P_end = 0.0;
    for (double lam = 1.0; lam <= 1.7001; lam += 0.1) {
        set_stretch(p, lam, 6.0);
        const auto r = solve_staggered(p, pf, st);
        CHECK(r.newton_ok);
        if (!r.newton_ok) break;
        const double P = top_reaction(p, 6.0) / 4.0;
        if (P > P_peak) P_peak = P;
        P_end = P;
    }
    const double d_max = phase_field_max(st);
    std::printf("    P_peak = %.3f МПа, P в конце = %.3f МПа, d_max = %.3f\n", P_peak, P_end, d_max);

    CHECK(P_peak > 0.0);
    CHECK(P_end < 0.5 * P_peak);   // тело потеряло несущую способность
    CHECK(d_max > 0.7);            // повреждение дошло до разрыва

    // Локализация: узел с максимальным d — у вершины надреза (x = 4 мм) в полосе надреза
    std::size_t amax = 0;
    for (std::size_t a = 0; a < st.d.size(); ++a)
        if (st.d[a] > st.d[amax]) amax = a;
    const auto& X = p.mesh.X[amax];
    std::printf("    максимум d в узле (%.0f; %.0f; %.0f) мм\n", X[0], X[1], X[2]);
    CHECK(X[0] >= 4.0 - 1e-9);                     // вершина надреза
    CHECK(X[2] >= 2.0 - 1e-9 && X[2] <= 4.0 + 1e-9);  // полоса надреза по z
}
