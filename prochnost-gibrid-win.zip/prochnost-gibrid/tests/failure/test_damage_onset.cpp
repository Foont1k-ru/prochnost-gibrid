// tests/failure/test_damage_onset.cpp — зарождение разрушения: момент и место (Э8′).
//
// Проверяется именно то, что заказчик просил увидеть интерактивно:
//   * КОГДА начинается разрыв — момент находится бисекцией по нагрузке, а не
//     «на шаге сетки», поэтому точность задаётся явно (1e-3 по λ);
//   * ГДЕ он начинается — максимум повреждения должен стоять у концентратора,
//     а не где попало;
//   * ПО КАКОМУ МЕХАНИЗМУ — ПС-1 (растяжение), ПС-1 (энергия) и ПС-2 (кавитация)
//     считаются и подписываются раздельно.
//
// Эталоны — аналитика для нео-Гука (несжимаемый предел):
//   λ_max = λ (одноосно),  σ_h = μ(λ² − 1/λ)/3,  W = C10(λ² + 2/λ − 3).

#include <chrono>
#include <cmath>
#include <cstdio>
#include <vector>

#include "pgib/failure/damage.hpp"
#include "pgib/failure/damage_field.hpp"
#include "pgib/solver_fem/damage_adapter.hpp"
#include "pgib/solver_fem/mixed_hyperelastic.hpp"
#include "pgib/solver_fem/specimen.hpp"
#include "tests/framework.hpp"

using namespace pgib::sfem;
namespace fail = pgib::failure;

namespace {

constexpr double kC10 = 1.2072;                    // резина В-14 по твёрдости (оценка, A-22)
constexpr double kMu = 2.0 * kC10;
constexpr double kNu = 0.4995;
constexpr double kK = 2.0 * kMu * (1.0 + kNu) / (3.0 * (1.0 - 2.0 * kNu));
constexpr double kLambdaBreak = 2.6;               // 1 + δ/100 при δ = 160 %

fail::Criteria stretch_criteria() {
    fail::Criteria c;
    c.has_lambda_break = true;
    c.lambda_break = kLambdaBreak;
    return c;
}

fail::Criteria all_criteria() {
    fail::Criteria c = stretch_criteria();
    c.has_Wc = true;
    c.W_c = fail::Wc_from_uniaxial_break(kC10, kLambdaBreak);
    c.has_cavitation = true;
    c.cavitation_threshold = 5.0 * kC10;
    return c;
}

// Гладкий брус 1×1×4 — однородное одноосное состояние (эталон).
Problem smooth_bar(double lz = 4.0) {
    Problem p;
    p.mesh = make_box(1, 1, 4, 1.0, 1.0, lz);
    p.material.iso = neo_hookean(kMu);
    p.material.K = kK;
    setup_uniaxial(p, lz, 1.0);
    return p;
}

// Брус с боковым надрезом: 6×2×6, вырезаны элементы у грани +x в полосе z.
Problem notched_bar(double lz = 6.0) {
    Problem p;
    p.mesh = make_notched_bar(6, 2, 6, 6.0, 2.0, lz, 2, 2, 2);
    p.material.iso = neo_hookean(kMu);
    p.material.K = kK;
    setup_uniaxial(p, lz, 6.0);
    return p;
}

// Найти момент зарождения: сначала шагами найти скобку, затем бисекция.
struct Onset {
    fail::OnsetResult result;
    double local_stretch = 0.0;   // λ_max в точке максимума
    int element = -1;
};

Onset find_onset_for(Problem& prob, const fail::Criteria& crit, double lz,
                     double lambda_end, double step = 0.1, double tol = 1e-3) {
    Onset out;
    double lo = 1.0;
    double hi = -1.0;
    double d_lo = 0.0;

    for (double lam = 1.0; lam <= lambda_end + 1e-12; lam += step) {
        const auto r = solve_at_stretch(prob, lam, lz);
        if (!r.converged) break;
        const auto f = frame_of(prob, crit, 0, lam);
        if (f.D_max >= 1.0) { hi = lam; break; }
        lo = lam;
        d_lo = f.D_max;
    }
    if (hi < 0.0) return out;
    (void)d_lo;

    auto solve_d = [&](double lam) {
        const auto r = solve_at_stretch(prob, lam, lz);
        if (!r.converged) return -1.0;
        return frame_of(prob, crit, 0, lam).D_max;
    };
    out.result = fail::find_onset(lo, hi, solve_d, tol);
    if (out.result.found) {
        const auto r = solve_at_stretch(prob, out.result.load, lz);
        (void)r;
        const auto f = frame_of(prob, crit, 0, out.result.load);
        out.element = f.element_D_max;
        out.local_stretch = f.value_governing;
    }
    return out;
}

}  // namespace

// 1. Момент зарождения на гладком образце совпадает с λ_break (эталон = определение)
PGIB_TEST(onset_homogeneous_equals_lambda_break) {
    auto prob = smooth_bar();
    const auto onset = find_onset_for(prob, stretch_criteria(), 4.0, 3.0);
    CHECK(onset.result.found);
    CHECK_NEAR(onset.result.load, kLambdaBreak, 1e-3);   // точность поиска задана, а не «как попал шаг»
    CHECK_NEAR(onset.result.D, 1.0, 1e-3);               // в найденной точке D = 1
    CHECK(onset.result.width <= 1e-3 + 1e-12);           // скобка сужена до допуска
    CHECK_NEAR(onset.local_stretch, kLambdaBreak, 1e-2);
}

// 2. Энергетический критерий ПС-1 даёт тот же момент, если W_c согласован с λ_break
PGIB_TEST(onset_energy_criterion_agrees_with_stretch) {
    const double W_c = fail::Wc_from_uniaxial_break(kC10, kLambdaBreak);
    // Эталон: W(λ_break) для нео-Гука при одноосном растяжении
    const double W_analytic = kC10 * (kLambdaBreak * kLambdaBreak + 2.0 / kLambdaBreak - 3.0);
    CHECK_NEAR(W_c, W_analytic, 1e-12);

    fail::Criteria energy_only;
    energy_only.has_Wc = true;
    energy_only.W_c = W_c;

    auto prob = smooth_bar();
    const auto onset = find_onset_for(prob, energy_only, 4.0, 3.0);
    CHECK(onset.result.found);
    // Допуск 5e-3, а не 2e-3: W_c выведен из НЕСЖИМАЕМОЙ формулы, а расчёт идёт
    // при K = 2414 МПа, где J = 1,0016. Изохорная энергия в расчёте меньше эталона
    // на ~0,1 % (Ī1 масштабируется как J^(−2/3)), поэтому порог достигается чуть
    // позже: 2,6023 против 2,6000. Это физика конечной сжимаемости, а не ошибка
    // поиска — чистая точность поиска проверена тестом 1 (там 1e-3 выдержано).
    CHECK_NEAR(onset.result.load, kLambdaBreak, 5e-3);
}

// 3. Кавитация (ПС-2): момент совпадает с аналитическим λ из λ² − 1/λ = 3·p_c/μ
PGIB_TEST(onset_cavitation_matches_analytic) {
    const double p_c = 5.0 * kC10;
    const double lambda_analytic = fail::uniaxial_stretch_for_cavitation(kC10, p_c);

    fail::Criteria cav;
    cav.has_cavitation = true;
    cav.cavitation_threshold = p_c;

    auto prob = smooth_bar();
    const auto onset = find_onset_for(prob, cav, 4.0, 3.4, 0.1, 1e-3);
    CHECK(onset.result.found);
    // Допуск 2 %: смешанная u/P-формулировка при K = 2414 МПа отличается от
    // несжимаемого эталона на σ_h/K ≈ 0,3 %, остальное — шаг бисекции.
    CHECK_NEAR(onset.result.load / lambda_analytic, 1.0, 2e-2);
}

// 4. Надрез: зарождение РАНЬШЕ, чем на гладком образце, и ЛОКАЛИЗОВАНО у надреза
PGIB_TEST(onset_notched_earlier_and_localized) {
    auto smooth = smooth_bar();
    const auto onset_smooth = find_onset_for(smooth, stretch_criteria(), 4.0, 3.0);

    auto notched = notched_bar();
    const auto onset_notch = find_onset_for(notched, stretch_criteria(), 6.0, 2.6);
    CHECK(onset_notch.result.found);
    CHECK(onset_notch.result.load < onset_smooth.result.load);   // концентратор ускоряет разрыв

    // Проверка локализации: все элементы, близкие к максимуму, лежат в полосе надреза
    // (z ∈ [2; 4] мм при шаге 1 мм), а не размазаны по образцу.
    const auto r = solve_at_stretch(notched, onset_notch.result.load, 6.0);
    CHECK(r.converged);
    const auto f = frame_of(notched, stretch_criteria(), 0, onset_notch.result.load);
    int in_band = 0, total = 0;
    for (const auto& p : f.points) {
        if (p.evaluation.D >= 0.95 * f.D_max) {
            ++total;
            if (p.centroid[2] > 2.0 - 1e-9 && p.centroid[2] < 4.0 + 1e-9) ++in_band;
        }
    }
    CHECK(total > 0);
    CHECK(in_band == total);
    // Концентрация: локальное растяжение выше номинального
    CHECK(onset_notch.local_stretch > onset_notch.result.load);
}

// 5. История повреждения: D не убывает, событие записывается один раз (Ф-49, Ф-51)
PGIB_TEST(damage_history_monotone_single_event) {
    auto prob = smooth_bar();
    // Один механизм — ровно одно событие. (С тремя критериями событий может быть
    // больше: журнал фиксирует отдельно каждый механизм, впервые превысивший порог,
    // и это требование Э8 «подписывать механизмы раздельно», а не дефект.)
    fail::Tracker tracker(stretch_criteria());
    fail::FieldHistory hist;

    double prev_D = 0.0;
    int events = 0;
    int idx = 0;
    for (double lam = 1.0; lam <= 2.8 + 1e-12; lam += 0.1) {
        const auto r = solve_at_stretch(prob, lam, 4.0);
        CHECK(r.converged);
        (void)r;
        auto f = frame_of(prob, stretch_criteria(), idx++, lam);
        hist.update(f);
        const auto u = tracker.update(idx, lam, f.points.front().sample);
        if (u.new_event) ++events;
        CHECK(f.points.front().D_history >= prev_D - 1e-12);   // накопление, не «выздоровление»
        prev_D = f.points.front().D_history;
    }
    CHECK(events == 1);                                        // одно событие, а не поток
    CHECK(tracker.failure_occurred());
    CHECK(tracker.events().size() == 1);
}

// 6. Механизмы подписываются РАЗДЕЛЬНО (требование Э8), а не «разрушение: да»
PGIB_TEST(mechanisms_reported_separately) {
    auto prob = smooth_bar();
    const auto crit = all_criteria();
    const auto r = solve_at_stretch(prob, 2.0, 4.0);
    CHECK(r.converged);

    const auto f = frame_of(prob, crit, 0, 2.0);
    const auto& p = f.points.front();
    CHECK(p.evaluation.D_lambda > 0.0);
    CHECK(p.evaluation.D_energy > 0.0);
    CHECK(p.evaluation.D_cavitation > 0.0);
    CHECK(f.peak[1] > 0.0 && f.peak[2] > 0.0 && f.peak[3] > 0.0);

    // Названия механизмов различаются — в отчёте это разные строки
    const std::string n1 = fail::criterion_name(fail::Criterion::Psi1_Stretch);
    const std::string n2 = fail::criterion_name(fail::Criterion::Psi1_Energy);
    const std::string n3 = fail::criterion_name(fail::Criterion::Psi2_Cavitation);
    CHECK(n1 != n2);
    CHECK(n2 != n3);
    CHECK(n1 != n3);

    // Механизм-лидер определяется, а не теряется: D = max по механизмам
    CHECK(f.governing != fail::Criterion::None);
    CHECK_NEAR(f.D_max, std::max({p.evaluation.D_lambda, p.evaluation.D_energy, p.evaluation.D_cavitation}), 1e-12);
}

// 7. Бюджет кадра: пересчёт поля для 64 элементов должен укладываться в кадр 30 Гц
PGIB_TEST(frame_build_fits_30_fps_budget) {
    auto prob = notched_bar();
    const auto r = solve_at_stretch(prob, 1.6, 6.0);
    CHECK(r.converged);
    const auto crit = all_criteria();

    constexpr int kFrames = 200;
    const auto t0 = std::chrono::steady_clock::now();
    double sink = 0.0;
    for (int i = 0; i < kFrames; ++i) sink += frame_of(prob, crit, i, 1.6).D_max;
    const auto t1 = std::chrono::steady_clock::now();
    const double ms = std::chrono::duration<double, std::milli>(t1 - t0).count() / kFrames;

    std::printf("    кадр поля повреждения (64 элемента): %.3f мс\n", ms);
    CHECK(sink > 0.0);
    // 30 кадр/с — это 33,3 мс на кадр; для ядра «Точный» поле считается кратно
    // быстрее. Запас нужен потому, что 64 элемента — не предел: 100 тыс. элементов
    // при той же схеме дадут ~1,5 с, поэтому для интерактивности поле считается по
    // разреженной выборке (Э5, GPU), а не по всем элементам каждый кадр.
    CHECK(ms < 33.3);
}

// 8. Поиск момента не выдумывает результат, если зарождения в скобке нет
PGIB_TEST(onset_search_respects_absence) {
    auto prob = smooth_bar();
    fail::Criteria high;             // порог заведомо недостижим
    high.has_lambda_break = true;
    high.lambda_break = 10.0;

    const auto r = find_onset_for(prob, high, 4.0, 1.5);
    CHECK(!r.result.found);          // «нет события» — законный ответ, а не подстановка
    CHECK(r.result.load == 0.0);

    // Верхняя граница скобки ниже порога — тоже «не найдено»
    auto solve_d = [&](double lam) {
        const auto rep = solve_at_stretch(prob, lam, 4.0);
        if (!rep.converged) return -1.0;
        return frame_of(prob, high, 0, lam).D_max;
    };
    const auto res = fail::find_onset(1.0, 1.2, solve_d, 1e-3);
    CHECK(!res.found);
}
