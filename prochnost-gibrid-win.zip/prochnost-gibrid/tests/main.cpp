// tests/main.cpp — точка входа прогона тестов.

#include "tests/framework.hpp"

int main() { return ::pgib::test::run_all(); }
