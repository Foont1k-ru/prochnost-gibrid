@echo off
rem ---------------------------------------------------------------------------
rem  build.cmd — единая точка сборки ПРОЧНОСТЬ.ГИБРИД (п. 0.3 ТЗ).
rem  Каждая итерация обязана проходить: конфигурация -> сборка -> тесты ->
rem  линтеры -> (на Э1.10) установщик.
rem  Код возврата: 0 — успех, 1 — провал любого шага.
rem ---------------------------------------------------------------------------
setlocal EnableDelayedExpansion
chcp 65001 >nul
set "ROOT=%~dp0"
set "CONFIG=%~1"
if "%CONFIG%"=="" set "CONFIG=Release"
set "PRESET=windows-msvc-release"
if /I "%CONFIG%"=="Debug" set "PRESET=windows-msvc-debug"
set "FAIL=0"

echo [1/5] Конфигурация CMake (%PRESET%)
cmake --preset %PRESET%
if errorlevel 1 goto fail

echo [2/5] Сборка
cmake --build --preset %PRESET%
if errorlevel 1 goto fail

echo [3/5] Тесты
ctest --preset %PRESET% --output-on-failure
if errorlevel 1 goto fail

echo [4/5] Линтеры (архитектура, локализация, запрет констант П7)
where python >nul 2>nul
if errorlevel 1 (
  echo    ПРОВАЛ: не найден python — линтеры обязательны в конвейере.
  goto fail
)
python "%ROOT%tools\lint_layers.py" || goto fail
python "%ROOT%tools\lint_i18n.py" || goto fail
python "%ROOT%tools\lint_no_p7.py" || goto fail
python "%ROOT%tools\test_linters.py" || goto fail
python "%ROOT%tools\validate_pmat.py" || goto fail
python "%ROOT%tools\validate_pmat.py" --self-test || goto fail

echo [5/5] Установщик
if exist "%ROOT%tools\package.cmd" (
  call "%ROOT%tools\package.cmd" %CONFIG%
  if errorlevel 1 goto fail
) else (
  echo    Пропущено: tools\package.cmd появится на Э1.10 (сейчас нечего упаковывать).
)

echo.
echo СБОРКА УСПЕШНА
exit /b 0

:fail
echo.
echo СБОРКА ПРОВАЛЕНА (шаг выше)
exit /b 1
