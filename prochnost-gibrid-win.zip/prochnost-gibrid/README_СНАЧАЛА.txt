ПРОЧНОСТЬ.ГИБРИД — приёмочная сборка на Windows
================================================

1. Нужны две бесплатные программы:
   - Visual Studio 2022 Community, галочка "Разработка классических приложений на C++"
     https://visualstudio.microsoft.com/ru/vs/community/
   - Python 3.12, галочка "Add python.exe to PATH"
     https://www.python.org/downloads/windows/

2. Распакуйте этот архив целиком, например в C:\pgib

3. Двойной щелчок по файлу  ПРОВЕРКА_НА_WINDOWS.cmd
   Окно не закрывайте, идёт компиляция (5-20 минут).

4. В конце появится файл win_stand_log.txt — отправьте его разработчику.

Подробнее: docs\ИНСТРУКЦИЯ_WINDOWS_СТЕНД.md
