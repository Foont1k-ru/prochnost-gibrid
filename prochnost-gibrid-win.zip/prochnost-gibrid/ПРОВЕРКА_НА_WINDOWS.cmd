@echo off
rem ---------------------------------------------------------------------------
rem  ПРОВЕРКА_НА_WINDOWS.cmd — приёмочный стенд п. 0.3 (блокер B-03).
rem  Запускать двойным щелчком. Ничего не устанавливает сам (кроме предложения
rem  доставить Python через winget). Пишет полный журнал в win_stand_log.txt.
rem  Код возврата: 0 — сборка прошла, 1 — провал сборки, 2 — нет Visual Studio,
rem                3 — нет Python.
rem ---------------------------------------------------------------------------
setlocal EnableDelayedExpansion
chcp 65001 >nul
title ПРОЧНОСТЬ.ГИБРИД — проверка на Windows
set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "LOG=%ROOT%\win_stand_log.txt"
if exist "%LOG%" del /q "%LOG%"

echo ================================================================
echo   ПРОЧНОСТЬ.ГИБРИД — приёмочная сборка на Windows
echo ================================================================
echo   Папка проекта: %ROOT%
echo   Журнал:        %LOG%
echo.

if not exist "%ROOT%\build.cmd" (
    echo ОШИБКА: рядом со скриптом нет build.cmd.
    echo Распакуйте архив целиком и запустите скрипт из корня папки проекта.
    echo.
    pause
    exit /b 1
)

rem ---------- 1. Среда -------------------------------------------------------
echo [1/4] Ищу Visual Studio 2022 (C++ x64)...
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
set "VSDIR="
if exist "%VSWHERE%" (
    for /f "usebackq delims=" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSDIR=%%i"
)
if not defined VSDIR goto no_vs

echo       найдено: %VSDIR%
if exist "%VSDIR%\VC\Auxiliary\Build\vcvars64.bat" (
    echo       настраиваю окружение компилятора...
    call "%VSDIR%\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
) else (
    echo       ВНИМАНИЕ: в этой установке нет компонента C++ ^(vcvars64.bat^).
    goto no_vs
)
where cl >nul 2>nul || goto no_vs
where cmake >nul 2>nul || goto no_cmake

rem ---------- 2. Python ------------------------------------------------------
echo [2/4] Проверяю Python (нужен линтерам и валидатору карточек)...
where python >nul 2>nul
if errorlevel 1 goto no_python
for /f "delims=" %%v in ('python --version 2^>^&1') do set "PYVER=%%v"
echo       найдено: !PYVER!

rem ---------- 3. Сведения о машине -------------------------------------------
echo [3/4] Записываю сведения о стенде в журнал...
>>"%LOG%" echo === ПРОЧНОСТЬ.ГИБРИД: приёмочный стенд Windows ===
>>"%LOG%" echo Дата: %DATE% %TIME%
>>"%LOG%" echo Папка проекта: %ROOT%
>>"%LOG%" ver
>>"%LOG%" echo.
>>"%LOG%" echo --- Visual Studio ---
>>"%LOG%" "%VSWHERE%" -latest -property displayName,installationVersion,installationPath 2>nul
>>"%LOG%" echo.
>>"%LOG%" echo --- Компилятор ---
>>"%LOG%" cl 2>&1
>>"%LOG%" echo.
>>"%LOG%" echo --- CMake ---
>>"%LOG%" cmake --version 2>&1
>>"%LOG%" echo.
>>"%LOG%" echo --- Python ---
>>"%LOG%" python --version 2>&1
>>"%LOG%" echo.
>>"%LOG%" echo === НАЧАЛО СБОРКИ ===
>>"%LOG%" echo.

rem ---------- 4. Сборка ------------------------------------------------------
echo [4/4] Запускаю build.cmd Release — это займёт от 5 до 20 минут.
echo       Не закрывайте окно, даже если кажется, что всё замерло: идёт компиляция.
echo.
call "%ROOT%\build.cmd" Release >>"%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
>>"%LOG%" echo.
>>"%LOG%" echo === КОНЕЦ СБОРКИ, код возврата %RC% ===

echo.
echo ----------------------------------------------------------------
if "%RC%"=="0" (
    echo   РЕЗУЛЬТАТ: СБОРКА УСПЕШНА
) else (
    echo   РЕЗУЛЬТАТ: СБОРКА ПРОВАЛЕНА ^(код %RC%^)
)
echo ----------------------------------------------------------------
echo.
echo   Журнал сохранён:
echo   %LOG%
echo.
echo   Отправьте этот файл разработчику ^(win_stand_log.txt^).
echo   Он небольшой, обычный текстовый файл — можно письмом или в мессенджере.
echo.
pause
exit /b %RC%

:no_vs
echo.
echo ----------------------------------------------------------------
echo   НЕ НАЙДЕН Visual Studio 2022 с компонентом C++ x64
echo ----------------------------------------------------------------
echo   Что сделать:
echo   1^) Скачать бесплатную Visual Studio 2022 Community:
echo      https://visualstudio.microsoft.com/ru/vs/community/
echo   2^) В установщике выбрать рабочую нагрузку
echo      "Разработка классических приложений на C++"
echo      ^(Desktop development with C++^), ничего больше не нужно.
echo   3^) Перезапустить этот файл.
echo.
pause
exit /b 2

:no_cmake
echo.
echo   Не найден cmake. Он входит в состав Visual Studio 2022 —
echo   проверьте, что отмечен компонент "C++ CMake tools for Windows"
echo   ^(в установщике VS: Отдельные компоненты^).
echo.
pause
exit /b 2

:no_python
echo.
echo ----------------------------------------------------------------
echo   НЕ НАЙДЕН Python 3
echo ----------------------------------------------------------------
echo   Без него не работают линтеры и валидатор карточек материала,
echo   а build.cmd считает это провалом.
echo.
echo   Вариант А ^(проще^): установить через winget прямо сейчас.
where winget >nul 2>nul
if errorlevel 1 goto python_manual
echo   winget найден — можно поставить автоматически.
set "ANS="
set /p "ANS=   Установить Python сейчас? [Д/н] "
if /I "!ANS!"=="н" goto python_manual
if /I "!ANS!"=="n" goto python_manual
winget install --id Python.Python.3.12 -e --accept-source-agreements --accept-package-agreements
echo.
echo   Готово. ЗАКРОЙТЕ это окно и запустите ПРОВЕРКА_НА_WINDOWS.cmd заново —
echo   чтобы новый Python попал в PATH.
echo.
pause
exit /b 3

:python_manual
echo   Вариант Б: скачать с https://www.python.org/downloads/windows/
echo   При установке ОБЯЗАТЕЛЬНО отметить галочку
echo   "Add python.exe to PATH".
echo   Затем запустить этот файл заново.
echo.
pause
exit /b 3
