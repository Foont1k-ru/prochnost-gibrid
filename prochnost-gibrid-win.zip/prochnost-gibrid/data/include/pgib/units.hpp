// pgib/units.hpp — типизированные размерные величины.
//
// Закрывает: Ф-37 (единицы мм–т–с–Н–МПа), п. 20 («смешение систем внутри ядра
// запрещено архитектурно»), A-01.
//
// Принцип: величина хранит значение в БАЗОВЫХ единицах системы мм–т–с–Н–МПа.
// Система самосогласована: 1 Н = 1 т·мм/с², 1 МПа = 1 Н/мм²,
// 1 кг/м³ = 1e-9 т/мм³. Проверяется тестами tests/units.
//
// Голый double для размерной величины в публичном интерфейсе запрещён:
// сложение и сравнение величин разных размерностей не компилируются.

#pragma once

#include <cmath>
#include <cstdio>
#include <string>
#include <type_traits>

namespace pgib::units {

// Физическая размерность. Расширяется только вместе с тестом на неё.
enum class Dim {
    Length,
    Area,
    Volume,
    Mass,
    Time,
    Force,
    Stress,        // = давление: 1 МПа = 1 Н/мм²
    Density,
    Temperature,
    TemperatureGradient,
    Angle,
    Moment,
    Energy,
    Velocity,
};

namespace detail {
constexpr double kPi = 3.14159265358979323846;

template <Dim D>
struct DimName;
// Служебная таблица для сообщений об ошибках (только отладка/логи).
#define PGIB_DIM_NAME(d, s)      \
    template <>                  \
    struct DimName<Dim::d> {     \
        static constexpr const char* value = s; \
    }
PGIB_DIM_NAME(Length, "длина");
PGIB_DIM_NAME(Area, "площадь");
PGIB_DIM_NAME(Volume, "объём");
PGIB_DIM_NAME(Mass, "масса");
PGIB_DIM_NAME(Time, "время");
PGIB_DIM_NAME(Force, "сила");
PGIB_DIM_NAME(Stress, "напряжение");
PGIB_DIM_NAME(Density, "плотность");
PGIB_DIM_NAME(Temperature, "температура");
PGIB_DIM_NAME(TemperatureGradient, "градиент температуры");
PGIB_DIM_NAME(Angle, "угол");
PGIB_DIM_NAME(Moment, "момент");
PGIB_DIM_NAME(Energy, "энергия");
PGIB_DIM_NAME(Velocity, "скорость");
#undef PGIB_DIM_NAME
}  // namespace detail

// Единица измерения размерности D. factor — во сколько базовых единиц входит одна
// такая единица (например, для дюйма при базе «мм» factor = 25.4).
template <Dim D>
struct Unit {
    const char* symbol;
    double factor;
};

template <Dim D>
class Quantity;

namespace u {
// Длина (база — мм)
inline constexpr Unit<Dim::Length> mm{"мм", 1.0};
inline constexpr Unit<Dim::Length> cm{"см", 10.0};
inline constexpr Unit<Dim::Length> m{"м", 1000.0};
inline constexpr Unit<Dim::Length> inch{"дюйм", 25.4};
// Площадь (база — мм²)
inline constexpr Unit<Dim::Area> mm2{"мм²", 1.0};
inline constexpr Unit<Dim::Area> cm2{"см²", 100.0};
inline constexpr Unit<Dim::Area> m2{"м²", 1.0e6};
// Объём (база — мм³)
inline constexpr Unit<Dim::Volume> mm3{"мм³", 1.0};
inline constexpr Unit<Dim::Volume> litre{"л", 1.0e6};
// Масса (база — т)
inline constexpr Unit<Dim::Mass> t{"т", 1.0};
inline constexpr Unit<Dim::Mass> kg{"кг", 1.0e-3};
inline constexpr Unit<Dim::Mass> g{"г", 1.0e-6};
// Время (база — с)
inline constexpr Unit<Dim::Time> s{"с", 1.0};
inline constexpr Unit<Dim::Time> ms{"мс", 1.0e-3};
// Сила (база — Н)
inline constexpr Unit<Dim::Force> N{"Н", 1.0};
inline constexpr Unit<Dim::Force> kN{"кН", 1.0e3};
// Напряжение/давление (база — МПа = Н/мм²)
inline constexpr Unit<Dim::Stress> Pa{"Па", 1.0e-6};
inline constexpr Unit<Dim::Stress> kPa{"кПа", 1.0e-3};
inline constexpr Unit<Dim::Stress> MPa{"МПа", 1.0};
inline constexpr Unit<Dim::Stress> GPa{"ГПа", 1.0e3};
// Плотность (база — т/мм³)
inline constexpr Unit<Dim::Density> t_mm3{"т/мм³", 1.0};
// 1 кг/м³ = 1e-3 т / 1e9 мм³ = 1e-12 т/мм³
inline constexpr Unit<Dim::Density> kg_m3{"кг/м³", 1.0e-12};
// Температура (база — °C; используется для приращений и абсолютных значений)
inline constexpr Unit<Dim::Temperature> degC{"°C", 1.0};
inline constexpr Unit<Dim::Temperature> K{"K", 1.0};
// Градиент температуры (база — °C/мм)
inline constexpr Unit<Dim::TemperatureGradient> degC_per_mm{"°C/мм", 1.0};
inline constexpr Unit<Dim::TemperatureGradient> degC_per_m{"°C/м", 1.0e-3};
// Угол (база — рад)
inline constexpr Unit<Dim::Angle> rad{"рад", 1.0};
inline constexpr Unit<Dim::Angle> deg{"°", detail::kPi / 180.0};
// Момент (база — Н·мм)
inline constexpr Unit<Dim::Moment> Nmm{"Н·мм", 1.0};
inline constexpr Unit<Dim::Moment> Nm{"Н·м", 1.0e3};
// Энергия (база — Н·мм = мДж)
inline constexpr Unit<Dim::Energy> Nmm_e{"Н·мм", 1.0};
inline constexpr Unit<Dim::Energy> J{"Дж", 1.0e3};
inline constexpr Unit<Dim::Energy> mJ{"мДж", 1.0};
// Скорость (база — мм/с)
inline constexpr Unit<Dim::Velocity> mm_s{"мм/с", 1.0};
inline constexpr Unit<Dim::Velocity> m_s{"м/с", 1000.0};
}  // namespace u

// Размерная величина. Создаётся только явно: Quantity::from(value, unit).
template <Dim D>
class Quantity {
public:
    using DimTag = std::integral_constant<Dim, D>;

    constexpr Quantity() = default;

    static constexpr Quantity from_base(double value_in_base) { return Quantity{value_in_base}; }
    static constexpr Quantity from(double value, Unit<D> unit) { return Quantity{value * unit.factor}; }
    static constexpr Quantity zero() { return Quantity{0.0}; }

    constexpr double base() const { return value_; }
    constexpr double in(Unit<D> unit) const { return value_ / unit.factor; }
    constexpr bool is_finite() const { return std::isfinite(value_); }

    constexpr Quantity operator-() const { return Quantity{-value_}; }
    constexpr Quantity operator+(Quantity other) const { return Quantity{value_ + other.value_}; }
    constexpr Quantity operator-(Quantity other) const { return Quantity{value_ - other.value_}; }
    constexpr Quantity& operator+=(Quantity other) { value_ += other.value_; return *this; }
    constexpr Quantity& operator-=(Quantity other) { value_ -= other.value_; return *this; }

    constexpr Quantity operator*(double k) const { return Quantity{value_ * k}; }
    constexpr Quantity operator/(double k) const { return Quantity{value_ / k}; }
    friend constexpr Quantity operator*(double k, Quantity q) { return q * k; }

    // Отношение однородных величин — безразмерное число.
    constexpr double operator/(Quantity other) const { return value_ / other.value_; }

    constexpr auto operator<=>(const Quantity&) const = default;

private:
    explicit constexpr Quantity(double base_value) : value_(base_value) {}
    double value_{0.0};
};

// --- Курируемые межразмерные операции ---------------------------------------
// Только те комбинации, которые реально нужны ядру. Любая новая комбинация
// добавляется вместе с тестом на физическую согласованность (A-01).
template <Dim D>
constexpr Quantity<D> operator*(Quantity<D> q, double k) {
    return q * k;
}

inline constexpr Quantity<Dim::Area> area(Quantity<Dim::Length> a, Quantity<Dim::Length> b) {
    return Quantity<Dim::Area>::from_base(a.base() * b.base());
}
inline constexpr Quantity<Dim::Volume> volume(Quantity<Dim::Length> a, Quantity<Dim::Length> b,
                                              Quantity<Dim::Length> c) {
    return Quantity<Dim::Volume>::from_base(a.base() * b.base() * c.base());
}
// F = m·a, где ускорение задаётся длиной и временем: a = L/t²
inline constexpr Quantity<Dim::Force> force_from_mass(Quantity<Dim::Mass> m, Quantity<Dim::Length> l,
                                                      Quantity<Dim::Time> t) {
    return Quantity<Dim::Force>::from_base((m.base() * l.base()) / (t.base() * t.base()));
}
// σ = F/A
inline constexpr Quantity<Dim::Stress> stress(Quantity<Dim::Force> f, Quantity<Dim::Area> a) {
    return Quantity<Dim::Stress>::from_base(f.base() / a.base());
}
// M = F·L
inline constexpr Quantity<Dim::Moment> moment(Quantity<Dim::Force> f, Quantity<Dim::Length> l) {
    return Quantity<Dim::Moment>::from_base(f.base() * l.base());
}
// K = σ/ε, где ε — безразмерная деформация: используется в проверках материалов.
inline constexpr Quantity<Dim::Stress> stress_from_strain(double strain, Quantity<Dim::Stress> modulus) {
    return Quantity<Dim::Stress>::from_base(strain * modulus.base());
}
// ρ = m/V
inline constexpr Quantity<Dim::Density> density(Quantity<Dim::Mass> m, Quantity<Dim::Volume> v) {
    return Quantity<Dim::Density>::from_base(m.base() / v.base());
}
// E = F·L
inline constexpr Quantity<Dim::Energy> energy(Quantity<Dim::Force> f, Quantity<Dim::Length> l) {
    return Quantity<Dim::Energy>::from_base(f.base() * l.base());
}

// --- Оформление по ГОСТ для интерфейса и отчёта ------------------------------
// Десятичный разделитель — запятая (ГОСТ 8.417, привычная русская запись).
// Отрицательные значения получают типографский минус U+2212 в UI-слое;
// здесь — обычный дефис, чтобы строку можно было использовать и в CSV.
inline std::string format(double value_in_unit, const char* symbol, int decimals) {
    char buf[64];
    std::snprintf(buf, sizeof(buf), "%.*f", decimals, value_in_unit);
    std::string out(buf);
    for (char& c : out) {
        if (c == '.') c = ',';
    }
    out += " ";
    out += symbol;
    return out;
}

template <Dim D>
std::string format(Quantity<D> q, Unit<D> unit, int decimals = 3) {
    return format(q.in(unit), unit.symbol, decimals);
}

}  // namespace pgib::units
