// pgib/result.hpp — результат операции с русским сообщением об ошибке.
//
// Закрывает: НФ-04 (сообщение с причиной и действием), арх. §2 (запрет исключений
// через границу DLL), A-15 (C++20: собственный тип вместо std::expected из C++23).
//
// Правило: код ошибки — стабильный (PGIB-E-NNNN), текст — из ru.json по ключу,
// поэтому сообщение локализуемо и не «прибито» к исходнику (п. 0.7).

#pragma once

#include <string>
#include <string_view>
#include <utility>
#include <variant>

namespace pgib {

enum class ErrorCode : int {
    Ok = 0,
    // 1xxx — данные и модель
    UnknownDimension = 1001,
    UnitMismatch = 1002,
    InvalidRange = 1003,
    MissingData = 1004,
    SchemaViolation = 1005,
    // 2xxx — геометрия
    GeometryInvalid = 2001,
    ImportFailed = 2002,
    UnitsAmbiguous = 2003,
    HealingFailed = 2004,
    // 3xxx — материалы
    MaterialInvalid = 3001,
    MaterialInconsistent = 3002,
    MaterialLowReliability = 3003,
    // 4xxx — сетка и решатель (появятся на Э2+)
    MeshFailed = 4001,
    SolverDiverged = 4002,
    MemoryInsufficient = 4003,
    // 5xxx — ввод-вывод и проекты
    ProjectOpenFailed = 5001,
    ProjectSchemaTooNew = 5002,
    FileWriteFailed = 5003,
};

// Код + ключ строки в ru.json + техническая подробность (в лог, не в диалог).
struct Error {
    ErrorCode code{ErrorCode::Ok};
    std::string message_key;   // ключ в resources/i18n/ru.json
    std::string detail;        // техническая подробность для журнала

    [[nodiscard]] int numeric_code() const { return static_cast<int>(code); }
};

// Тот же приём, что std::expected: либо значение, либо ошибка.
template <class T>
class Result {
public:
    Result(T value) : data_(std::move(value)) {}
    Result(Error error) : data_(std::move(error)) {}

    [[nodiscard]] bool has_value() const { return std::holds_alternative<T>(data_); }
    explicit operator bool() const { return has_value(); }

    [[nodiscard]] const T& value() const { return std::get<T>(data_); }
    [[nodiscard]] T& value() { return std::get<T>(data_); }
    [[nodiscard]] const Error& error() const { return std::get<Error>(data_); }

    [[nodiscard]] const T& value_or(const T& fallback) const {
        return has_value() ? std::get<T>(data_) : fallback;
    }

private:
    std::variant<T, Error> data_;
};

// Результат без значения — для операций «получилось/не получилось».
class Status {
public:
    Status() = default;
    Status(Error error) : error_(std::move(error)) {}
    [[nodiscard]] bool ok() const { return error_.code == ErrorCode::Ok; }
    explicit operator bool() const { return ok(); }
    [[nodiscard]] const Error& error() const { return error_; }

private:
    Error error_{};
};

inline Status make_error(ErrorCode code, std::string_view message_key, std::string detail = {}) {
    Status st{Error{code, std::string(message_key), std::move(detail)}};
    return st;
}

}  // namespace pgib
