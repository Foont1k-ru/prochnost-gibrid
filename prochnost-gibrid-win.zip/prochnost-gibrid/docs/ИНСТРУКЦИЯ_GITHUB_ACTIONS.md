# Сборка на Windows через GitHub: пошагово с телефона

Своего ПК не нужно. GitHub даёт бесплатную машину с Windows и MSVC на 5–15 минут.
От вас — **два действия на сайте GitHub**: загрузить архив и вставить один текстовый файл.

Понадобится: аккаунт GitHub (бесплатный, регистрация ~2 минуты) и файл
**`prochnost-gibrid-win.zip`** (281 КБ, лежит в рабочей папке — скачайте его на телефон
заранее, до начала шагов).

---

## Шаг 1. Создать репозиторий

1. Открыть https://github.com и войти (или зарегистрироваться).
2. Кнопка **«+»** справа сверху → **New repository**.
3. Repository name: `prochnost-gibrid`
4. Выбрать **Public** (проще: без ограничений минут, ничего секретного в коде нет).
5. Кнопка **Create repository**.

## Шаг 2. Загрузить архив

1. На странице пустого репозитория: ссылка **«uploading an existing file»**.
2. **choose your files** → выбрать `prochnost-gibrid-win.zip`.
3. Внизу **Commit changes**.

 Архив — это весь проект целиком (110 файлов внутри). Ничего распаковывать не надо:
 это сделает машина GitHub.

## Шаг 3. Добавить файл сборки

1. На главной странице репозитория: **Add file** → **Create new file**.
2. В поле имени файла вписать целиком, вместе со слэшами:

```
.github/workflows/windows.yml
```

3. В большое поле вставить текст ниже — **целиком, ничего не меняя**:

```yaml
name: Windows приёмочная сборка

on: [push, workflow_dispatch]

jobs:
  build:
    runs-on: windows-latest
    timeout-minutes: 60
    steps:
      - uses: actions/checkout@v4

      - name: Разложить исходники (если загружен архив проекта)
        shell: bash
        run: |
          shopt -s nullglob
          for z in *.zip; do
            echo "Распаковываю $z"
            if command -v unzip >/dev/null 2>&1; then
              unzip -q -o "$z"
            else
              powershell -NoProfile -Command "Expand-Archive -Path '$z' -DestinationPath . -Force"
            fi
          done
          B="$(find . -name build.cmd -not -path './.github/*' -print -quit)"
          if [ -z "$B" ]; then
            echo "::error::build.cmd не найден — загрузите архив prochnost-gibrid-win.zip в корень репозитория"
            exit 1
          fi
          echo "Найден build.cmd: $B"
          echo "SRC=$(dirname "$B")" >> "$GITHUB_ENV"

      - uses: actions/setup-python@v5
        with:
          python-version: '3.12'

      - uses: ilammy/msvc-dev-cmd@v1
        with:
          arch: x64

      - name: Сборка (build.cmd Release)
        shell: cmd
        working-directory: ${{ env.SRC }}
        run: |
          call build.cmd Release > win_stand_log.txt 2>&1
          set RC=%ERRORLEVEL%
          type win_stand_log.txt
          exit /b %RC%

      - name: Сохранить журнал и результаты
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: windows-stand
          path: |
            ${{ env.SRC }}/win_stand_log.txt
            ${{ env.SRC }}/out/**
          if-no-files-found: warn
```

4. **Commit changes** (зелёная кнопка внизу). Сборка запустится сама.

## Шаг 4. Посмотреть результат

1. Вкладка **Actions** вверху репозитория.
2. Сверху будет запуск «Windows приёмочная сборка» с жёлтым кружком (идёт),
   зелёной галочкой (успех) или красным крестом (провал). Ждать 5–15 минут,
   страницу можно обновлять.
3. Нажать на запуск → внизу страницы раздел **Artifacts** → скачать
   **`windows-stand`**. Внутри `win_stand_log.txt` — полный журнал.
4. Открыть запуск, нажать на шаг **«Сборка (build.cmd Release)»** — там весь вывод
   текстом, его можно выделить и скопировать.

## Шаг 5. Прислать мне

Что угодно из этого (по возрастанию удобства для меня):

- файл `win_stand_log.txt` из Artifacts — **лучше всего**, приложите его в чат;
- ссылку на репозиторий, если он публичный — я прочитаю сам;
- копию текста из шага «Сборка», начиная с последних 40 строк;
- скриншот последнего экрана, если ничего другого не выходит.

---

## Если что-то пошло не так

| Что видно | Что это значит |
|---|---|
| Красный крест на шаге «Разложить исходники», «build.cmd не найден» | Архив не попал в корень репозитория. Проверьте, что `prochnost-gibrid-win.zip` лежит рядом с файлом `README.md`, а не в подпапке. |
| Красный крест на «Сборка», ошибка `CMake Error` | Скорее всего несовместимость с MSVC — именно за этим мы и идём. Присылайте журнал, я правлю. |
| Ошибка `MSB8020` / «не найдена платформа» | В окружении не поднялся MSVC — напишите, поменяю способ настройки на другой. |
| Жёлтый кружок висит больше 20 минут | Так бывает на первом запуске (скачивание образов). Подождите; если больше 40 — отмените и запустите заново кнопкой **Re-run all jobs**. |
| «Workflows aren't being run on this repository» | В настройках репозитория Actions выключены: Settings → Actions → General → Allow all actions. |

Ничего страшного, если с первого раза не выйдет: журнал покажет конкретную строку,
я поправлю код и пришлю новый архив — вы повторите шаг 2 (загрузка файла) и всё.
