#!/usr/bin/env python3
"""new_material.py — добавить СВОЙ материал в библиотеку (заказ 12.11.2026).

Сценарий «пользователь добавляет материал со своими техническими и физическими
характеристиками» без правки кода: скрипт берёт шаблон
materials/templates/novyy_material.pmat, подставляет название и группу, кладёт
результат в materials/user/ и сразу прогоняет валидатор.

Почему отдельная папка materials/user: карточки библиотеки поставляются с
продуктом и обновляются при обновлении, пользовательские — нет. Смешивать их
нельзя, иначе обновление затрёт данные заказчика.

ПРИМЕРЫ
  python3 tools/new_material.py --name "Резина ИРП-1287" --group Резины
  python3 tools/new_material.py --name "Сталь 20Х2Н4А" --group "Стали конструкционные"
  python3 tools/new_material.py --list-groups
После создания файл правится в любом текстовом редакторе; незаполненные поля
оставляются null — программа не подставит за пользователя «похожие» числа,
а честно покажет, какие критерии разрушения посчитать нельзя (Ф-86).
"""
from __future__ import annotations

import argparse
import json
import pathlib
import re
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
TEMPLATE = ROOT / "materials" / "templates" / "novyy_material.pmat"
SCHEMA = ROOT / "materials" / "schema" / "pmat.schema.json"
USER_DIR = ROOT / "materials" / "user"

TRANSLIT = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e", "ж": "zh",
    "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m", "н": "n", "о": "o",
    "п": "p", "р": "r", "с": "s", "т": "t", "у": "u", "ф": "f", "х": "h", "ц": "c",
    "ч": "ch", "ш": "sh", "щ": "sch", "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu",
    "я": "ya",
}


def slugify(name: str) -> str:
    out = "".join(TRANSLIT.get(ch, ch) for ch in name.lower())
    return re.sub(r"[^a-z0-9]+", "_", out).strip("_") or "material"


def groups() -> list[str]:
    schema = json.loads(SCHEMA.read_text(encoding="utf-8"))
    return schema["properties"]["group"]["enum"]


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description="Создать карточку своего материала (.pmat)")
    ap.add_argument("--name", help="название материала, как его увидит пользователь")
    ap.add_argument("--group", help="группа материала (см. --list-groups)")
    ap.add_argument("--file", help="имя файла без расширения (по умолчанию из названия)")
    ap.add_argument("--list-groups", action="store_true", help="показать допустимые группы")
    args = ap.parse_args(argv[1:])

    if args.list_groups:
        print("Допустимые группы материала:")
        for g in groups():
            print("  " + g)
        return 0

    if not args.name:
        ap.error("укажите --name или --list-groups")

    group = args.group or "Резины"
    if group not in groups():
        print(f"ОШИБКА: группа «{group}» не входит в схему. Допустимо: {', '.join(groups())}")
        return 1

    slug = args.file or slugify(args.name)
    USER_DIR.mkdir(parents=True, exist_ok=True)
    target = USER_DIR / f"{slug}.pmat"
    if target.exists():
        print(f"ОШИБКА: {target.relative_to(ROOT)} уже существует — не перезаписываю данные пользователя")
        return 1

    card = json.loads(TEMPLATE.read_text(encoding="utf-8"))
    card["name"] = args.name
    card["group"] = group
    card["source"] = "паспорт партии № ___ от __.__.____ — заполните до расчёта"
    card["reliability"] = "паспорт производителя"
    target.write_text(json.dumps(card, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Создана карточка: {target.relative_to(ROOT)}")

    # Сразу проверяем: карточка с null-полями должна ПРОЙТИ, но с предупреждениями.
    validator = ROOT / "tools" / "validate_pmat.py"
    print("\nПроверка валидатором:")
    res = subprocess.run([sys.executable, str(validator), str(target)], capture_output=True, text=True)
    print(res.stdout.strip() or res.stderr.strip())
    print("\nДальше: откройте файл, заполните плотность, C10 (или твёрдость), λ_разрыва, W_c, T_c.")
    print("Незаполненное оставляйте null — программа покажет, что именно нельзя посчитать.")
    return res.returncode


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
