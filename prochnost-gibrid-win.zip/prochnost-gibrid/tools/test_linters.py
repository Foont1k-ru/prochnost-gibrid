#!/usr/bin/env python3
"""test_linters.py — самотест линтеров.

Требование DoD Э1.0: линтер обязан падать на заведомо внесённом нарушении.
Линтер, который «всегда зелёный», — это заглушка (п. 0.2), а не контроль.

Для каждого линтера создаётся временное дерево с нарушением и без него;
проверяется код возврата.
"""
# P7-ALLOW-FILE: самотест обязан содержать константы П7 как тестовые данные.
from __future__ import annotations

import json
import os
import pathlib
import subprocess
import sys
import tempfile

TOOLS = pathlib.Path(__file__).resolve().parent
PY = sys.executable

failures: list[str] = []


def run(linter: str, root: pathlib.Path) -> tuple[int, str]:
    env = dict(os.environ, PGIB_ROOT=str(root))
    proc = subprocess.run([PY, str(TOOLS / linter)], capture_output=True, text=True, env=env)
    return proc.returncode, proc.stdout + proc.stderr


def expect(name: str, linter: str, root: pathlib.Path, expected_rc: int, needle: str = "") -> None:
    rc, out = run(linter, root)
    ok = rc == expected_rc and (needle in out if needle else True)
    mark = "  OK  " if ok else " ПРОВАЛ"
    print(f"[{mark}] {name} (код {rc}, ожидался {expected_rc})")
    if not ok:
        failures.append(name)
        print("        вывод линтера:\n" + "\n".join("        " + l for l in out.splitlines()[:12]))


def write(root: pathlib.Path, rel: str, text: str) -> None:
    path = root / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def make_i18n(root: pathlib.Path, strings: dict, latin_allow: list[str] | None = None) -> None:
    data = {"meta": {"language": "ru", "schemaVersion": 1},
            "latinAllow": latin_allow or ["STEP"],
            "strings": strings}
    write(root, "resources/i18n/ru.json", json.dumps(data, ensure_ascii=False, indent=2))


GOOD_ENTRY = {
    "text": "Открыть",
    "tooltip_title": "Открыть модель",
    "tooltip_text": "Импорт геометрии из файла.",
    "tooltip_example": "деталь.step",
    "tooltip_unit": "мм",
    "help_anchor": "import/otkryt",
}


def main() -> int:
    print("=== Самотест линтера локализации ===")
    with tempfile.TemporaryDirectory() as td:
        base = pathlib.Path(td)

        # 1. Корректный ресурс
        r = base / "ok"; make_i18n(r, {"action.open": GOOD_ENTRY})
        expect("корректная строка принята", "lint_i18n.py", r, 0)

        # 2. Нет подсказки у интерактивного элемента
        r = base / "no_tooltip"
        make_i18n(r, {"action.open": {"text": "Открыть", "help_anchor": "a/b"}})
        expect("отсутствие подсказки отловлено", "lint_i18n.py", r, 1, "tooltip_title")

        # 3. Английская строка
        r = base / "english"
        make_i18n(r, {"action.open": {"text": "Open file", **{k: v for k, v in GOOD_ENTRY.items() if k != "text"}}})
        expect("английская строка отловлена", "lint_i18n.py", r, 1, "кириллиц")

        # 4. Англицизм
        r = base / "anglicism"
        bad = dict(GOOD_ENTRY); bad["text"] = "Сбросить на дефолт"
        make_i18n(r, {"action.reset": bad})
        expect("англицизм отловлен", "lint_i18n.py", r, 1, "дефолт")

        # 5. Недопустимый латинский токен и разрешённый
        r = base / "latin_bad"
        bad = dict(GOOD_ENTRY); bad["text"] = "Открыть через OPENGL"
        make_i18n(r, {"action.open": bad})
        expect("недопустимый латиница-токен отловлен", "lint_i18n.py", r, 1, "OPENGL")

        r = base / "latin_ok"
        ok = dict(GOOD_ENTRY); ok["text"] = "Открыть файл STEP"
        make_i18n(r, {"action.open": ok})
        expect("разрешённый токен STEP принят", "lint_i18n.py", r, 0)

        # 6. Кириллица в исходнике UI
        r = base / "ui_literal"; make_i18n(r, {"action.open": GOOD_ENTRY})
        write(r, "ui/main_window.cpp", 'void f(){ label->setText("Открыть"); }\n')
        expect("кириллица в исходнике UI отловлена", "lint_i18n.py", r, 1, "ru.json")

    print()
    print("=== Самотест запрета констант П7 ===")
    with tempfile.TemporaryDirectory() as td:
        base = pathlib.Path(td)
        r = base / "clean"; write(r, "cad/src/extract.cpp", "double wall = 12.0; // толщина из модели\n")
        expect("чистый файл принят", "lint_no_p7.py", r, 0)

        r = base / "p7"; write(r, "cad/src/extract.cpp", "double r = 213.5;\n")
        expect("радиус сферы из П7 отловлен", "lint_no_p7.py", r, 1, "213.5")

        r = base / "p7_low"; write(r, "cad/src/extract.cpp", "double base_d = 482.0;\n")
        expect("диаметр 482 отловлен", "lint_no_p7.py", r, 1, "482")

        r = base / "p7_low_ctx"; write(r, "cad/src/extract.cpp", "double diameter = 57;\n")
        expect("число в геометрическом контексте отловлено", "lint_no_p7.py", r, 1, "57")

        r = base / "p7_low_ok"; write(r, "cad/src/loop.cpp", "for (int i = 0; i < 57; ++i) {}\n")
        expect("то же число без геометрии принято", "lint_no_p7.py", r, 0)

        r = base / "p7_allow"; write(r, "cad/src/x.cpp", "double r = 213.5; // P7-ALLOW разбор эталона\n")
        expect("явное исключение P7-ALLOW принято", "lint_no_p7.py", r, 0)

        r = base / "p7_ref"; write(r, "tests/reference/p7_expected.json", '{"R": 213.5}\n')
        expect("эталон в tests/reference разрешён", "lint_no_p7.py", r, 0)

    print()
    print("=== Самотест правил зависимостей ===")
    with tempfile.TemporaryDirectory() as td:
        base = pathlib.Path(td)
        r = base / "clean"
        write(r, "ui/main.cpp", '#include "app/model.hpp"\n#include <QWidget>\n')
        write(r, "data/include/pgib/units.hpp", "#include <cmath>\n")
        write(r, "app/model.hpp", "")
        expect("корректные зависимости приняты", "lint_layers.py", r, 0)

        r = base / "ui_to_cad"
        write(r, "ui/main.cpp", '#include "cad/import.hpp"\n')
        expect("ui -> cad отловлено", "lint_layers.py", r, 1, "не может включать слой")

        r = base / "data_occ"
        write(r, "data/include/pgib/geom.hpp", "#include <TopoDS_Shape.hxx>\n")
        expect("OCC в слое data отловлен", "lint_layers.py", r, 1, "запрещённая")

        r = base / "cmake"
        write(r, "CMakeLists.txt", "target_link_libraries(pgib_ui PRIVATE pgib_cad)\n")
        expect("линковка ui -> cad отловлена", "lint_layers.py", r, 1, "запрещено матрицей")

    print()
    if failures:
        print(f"ИТОГ: самотест линтеров ПРОВАЛЕН — {len(failures)} случаев: {', '.join(failures)}")
        return 1
    print("ИТОГ: самотест линтеров пройден — все линтеры ловят нарушения")
    return 0


if __name__ == "__main__":
    sys.exit(main())
