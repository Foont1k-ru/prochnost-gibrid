#!/usr/bin/env python3
"""lint_layers.py — контроль правил зависимостей между слоями (Ф-22).

Матрица разрешённых зависимостей — docs/01_АРХИТЕКТУРА.md, §1. Здесь она
продублирована как данные: расхождение документа и линтера — дефект, поэтому
менять нужно оба места одним коммитом.

Проверяется:
  1. #include между слоями по матрице;
  2. запрещённые библиотеки по слоям (data и ui не знают OCC/Kratos/VTK);
  3. target_link_libraries в CMake — по той же матрице.
"""
from __future__ import annotations

import os
import pathlib
import re
import sys

ROOT = pathlib.Path(os.environ.get("PGIB_ROOT", pathlib.Path(__file__).resolve().parent.parent))

LAYERS = [
    "data", "io", "materials", "cad", "mesh", "contact", "failure",
    "solver_fem", "solver_expl", "solver_fast", "post", "verify", "report", "app", "ui", "help",
]

# Слой -> какие слои ему разрешено включать.
ALLOWED = {
    "data": set(),
    "io": {"data", "materials", "mesh"},
    "materials": {"data", "io"},
    "cad": {"data", "io", "materials"},
    "mesh": {"data", "io", "cad"},
    "contact": {"data", "materials", "mesh", "failure"},
    "failure": {"data", "materials"},
    "solver_fem": {"data", "io", "materials", "mesh", "contact", "failure"},
    "solver_expl": {"data", "io", "materials", "mesh", "contact", "failure"},
    "solver_fast": {"data", "io", "materials", "mesh", "contact", "failure"},
    "post": {"data", "io", "materials", "mesh", "failure"},
    "verify": {"data", "materials", "mesh", "contact", "failure", "post"},
    "report": {"data", "io", "materials", "mesh", "failure", "post", "verify"},
    "app": {"data", "io", "materials", "cad", "mesh", "contact", "failure",
            "solver_fem", "solver_expl", "solver_fast", "post", "verify", "report"},
    "ui": {"data", "materials", "post", "verify", "report", "app", "help"},
    "help": set(),
}

# Запрещённые внешние библиотеки по слоям (арх. §1, §2).
FORBIDDEN_INCLUDE = {
    "data": [r"TopoDS_", r"^Kratos", r"^vtk", r"^Q[A-Z]", r"<Q[A-Z]\w+>", r"pybind11"],
    "ui": [r"TopoDS_", r"^Kratos", r"^vtk"],
    "help": [r"TopoDS_", r"^Kratos", r"^vtk"],
}

INCLUDE_RE = re.compile(r'^\s*#\s*include\s*[<"]([^>"]+)[>"]')
LINK_RE = re.compile(r"target_link_libraries\s*\(\s*(\S+)([^)]*)\)", re.S)

violations: list[str] = []
scanned = 0


def layer_of_include(inc: str) -> str | None:
    parts = [p for p in inc.replace("\\", "/").split("/") if p and p != "pgib"]
    for part in parts:
        if part in LAYERS:
            return part
    return None


def check_file(path: pathlib.Path, src_layer: str) -> None:
    global scanned
    scanned += 1
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return
    rel = path.relative_to(ROOT)
    for lineno, line in enumerate(text.splitlines(), 1):
        m = INCLUDE_RE.match(line)
        if not m:
            continue
        inc = m.group(1)
        dep = layer_of_include(inc)
        if dep and dep != src_layer and dep not in ALLOWED.get(src_layer, set()):
            violations.append(
                f"{rel}:{lineno}: слой «{src_layer}» не может включать слой «{dep}» "
                f"({inc}) — нарушение матрицы docs/01_АРХИТЕКТУРА.md, §1"
            )
        for pattern in FORBIDDEN_INCLUDE.get(src_layer, []):
            if re.search(pattern, inc):
                violations.append(
                    f"{rel}:{lineno}: слой «{src_layer}» не может включать «{inc}» "
                    f"(запрещённая зависимость)"
                )


def check_cmake() -> None:
    for cmake in ROOT.rglob("CMakeLists.txt"):
        if any(p in {"build", ".git"} for p in cmake.relative_to(ROOT).parts):
            continue
        text = cmake.read_text(encoding="utf-8", errors="replace")
        for m in LINK_RE.finditer(text):
            target = m.group(1)
            deps = m.group(2).split()
            src = next((l for l in LAYERS if target == f"pgib_{l}" or target.startswith(f"pgib_{l}")), None)
            if not src:
                continue
            for d in deps:
                dep = next((l for l in LAYERS if d == f"pgib_{l}" or d.startswith(f"pgib_{l}")), None)
                if dep and dep != src and dep not in ALLOWED.get(src, set()):
                    violations.append(
                        f"{cmake.relative_to(ROOT)}: таргет {target} линкуется с {d} — "
                        f"запрещено матрицей зависимостей"
                    )


def main() -> int:
    for layer in LAYERS:
        layer_dir = ROOT / layer
        if not layer_dir.is_dir():
            continue
        for path in layer_dir.rglob("*"):
            if path.suffix in {".cpp", ".hpp", ".h", ".cc", ".cxx", ".hxx"} and path.is_file():
                check_file(path, layer)
    # Слой data физически лежит в data/include — уже покрыт. Заголовки ядра:
    check_cmake()

    if violations:
        print(f"ПРОВАЛ: нарушений правил зависимостей — {len(violations)}")
        for v in violations:
            print("  - " + v)
        return 1

    print(f"Правила зависимостей: OK — проверено файлов {scanned}, слоёв {len(LAYERS)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
