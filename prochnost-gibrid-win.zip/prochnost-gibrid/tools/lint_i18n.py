#!/usr/bin/env python3
"""lint_i18n.py — контроль локализации и подсказок (п. 0.7, Ф-77, Ф-80).

Проверки:
  1. Схема ru.json: язык, непустые строки, обязательное поле text.
  2. Для интерактивных элементов — полная четвёрка подсказки и якорь справки (Ф-77).
  3. В тексте есть кириллица (английских строк в UI быть не может).
  4. Латинские токены допустимы только из списка latinAllow (STEP, МПа и т. п.).
  5. Чёрный список англицизмов с предложенной заменой (Ф-80).
  6. Формат якоря справки.
  7. В каталоге ui/ нет строковых литералов с кириллицей (строки — только из ресурса).

Код возврата: 0 — чисто, 1 — есть нарушения.
Корень проекта можно переопределить переменной PGIB_ROOT (нужно для самотестов).
"""
from __future__ import annotations

import json
import os
import pathlib
import re
import sys

ROOT = pathlib.Path(os.environ.get("PGIB_ROOT", pathlib.Path(__file__).resolve().parent.parent))
RU_PATH = ROOT / "resources" / "i18n" / "ru.json"

REQUIRED_TOOLTIP = ("tooltip_title", "tooltip_text", "tooltip_example", "tooltip_unit", "help_anchor")

KEY_RE = re.compile(r"^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$")
ANCHOR_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*(?:/[a-z0-9]+(?:-[a-z0-9]+)*)*$")
LATIN_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9]*")
CYRILLIC_RE = re.compile(r"[А-Яа-яЁё]")

# Англицизмы, которых не должно быть в интерфейсе (Ф-80). Замена — в отчёте.
BANNED = {
    "дефолт": "значение по умолчанию",
    "баг": "дефект",
    "фича": "возможность",
    "апдейт": "обновление",
    "сэмпл": "образец",
    "тулбар": "панель инструментов",
    "скролл": "прокрутка",
    "клик": "щелчок",
    "юзать": "использовать",
    "рантайм": "среда исполнения",
    "перформанс": "производительность",
    "фидбек": "отзыв",
}

errors: list[str] = []


def err(msg: str) -> None:
    errors.append(msg)


def check_entry(key: str, entry: dict, latin_allow: set[str]) -> None:
    if not KEY_RE.match(key):
        err(f"[{key}] неверный формат ключа: ожидается «группа.имя» строчными латинскими буквами")

    text = entry.get("text")
    if not isinstance(text, str) or not text.strip():
        err(f"[{key}] отсутствует или пусто поле text")
        return

    interactive = entry.get("interactive", True)
    if interactive:
        for field in REQUIRED_TOOLTIP:
            value = entry.get(field)
            if not isinstance(value, str) or not value.strip():
                err(f"[{key}] интерактивный элемент без поля подсказки «{field}» (Ф-77: 100 % элементов)")

    anchor = entry.get("help_anchor")
    if isinstance(anchor, str) and anchor.strip() and not ANCHOR_RE.match(anchor):
        err(f"[{key}] неверный формат help_anchor: «{anchor}» (ожидается например model/pasport-modeli)")

    # 3. Кириллица обязательна
    if not CYRILLIC_RE.search(text):
        err(f"[{key}] в тексте нет кириллицы: «{text}» — английские строки в интерфейсе запрещены (п. 0.7)")

    # 4. Латинские токены
    allowed_here = latin_allow | set(entry.get("allow_latin", []))
    for token in LATIN_TOKEN_RE.findall(text):
        if token not in allowed_here:
            err(f"[{key}] недопустимый латинский токен «{token}» в тексте «{text}» "
                f"(добавьте в latinAllow только если это название формата)")

    # 5. Англицизмы
    low = text.lower()
    for word, replacement in BANNED.items():
        if word in low:
            err(f"[{key}] англицизм «{word}» — замените на «{replacement}» (Ф-80)")

    # Дополнительно проверяем подсказки на кириллицу и англицизмы
    for field in ("tooltip_title", "tooltip_text", "tooltip_example"):
        value = entry.get(field)
        if isinstance(value, str) and value.strip():
            if not CYRILLIC_RE.search(value) and value.strip() not in {"—", "-"}:
                err(f"[{key}.{field}] подсказка без кириллицы: «{value}»")
            for word in BANNED:
                if word in value.lower():
                    err(f"[{key}.{field}] англицизм «{word}» в подсказке (Ф-80)")


def check_sources() -> None:
    """В исходниках UI не должно быть строковых литералов с кириллицей (п. 0.7)."""
    ui_dir = ROOT / "ui"
    if not ui_dir.is_dir():
        return
    literal_re = re.compile(r'"(?:[^"\\]|\\.)*"')
    for path in ui_dir.rglob("*"):
        if path.suffix not in {".cpp", ".hpp", ".h", ".cc", ".ui", ".qml"}:
            continue
        for lineno, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            stripped = line.strip()
            if stripped.startswith("//") or stripped.startswith("*"):
                continue
            for literal in literal_re.findall(line):
                if CYRILLIC_RE.search(literal):
                    err(f"{path.relative_to(ROOT)}:{lineno}: строка с кириллицей в исходнике — "
                        f"вынесите в ru.json: {literal[:40]}")


def main() -> int:
    if not RU_PATH.is_file():
        print(f"ПРОВАЛ: не найден файл строк {RU_PATH}")
        return 1
    try:
        data = json.loads(RU_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"ПРОВАЛ: ru.json не является корректным JSON: {exc}")
        return 1

    meta = data.get("meta", {})
    if meta.get("language") != "ru":
        err("meta.language должен быть \"ru\": интерфейс только на русском (п. 0.7)")
    if not isinstance(meta.get("schemaVersion"), int):
        err("meta.schemaVersion отсутствует или не является целым числом")

    latin_allow = set(data.get("latinAllow", []))
    strings = data.get("strings", {})
    if not strings:
        err("раздел strings пуст")

    for key, entry in strings.items():
        if not isinstance(entry, dict):
            err(f"[{key}] значение должно быть объектом")
            continue
        check_entry(key, entry, latin_allow)

    check_sources()

    interactive_count = sum(1 for e in strings.values() if isinstance(e, dict) and e.get("interactive", True))
    if errors:
        print(f"ПРОВАЛ: нарушений локализации — {len(errors)}")
        for e in errors:
            print("  - " + e)
        return 1

    print(f"Локализация: OK — строк {len(strings)}, интерактивных {interactive_count}, "
          f"все с подсказками и якорями справки")
    return 0


if __name__ == "__main__":
    sys.exit(main())
