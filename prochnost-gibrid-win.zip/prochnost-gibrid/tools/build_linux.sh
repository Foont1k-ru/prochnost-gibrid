#!/usr/bin/env bash
# build_linux.sh — проверочная сборка кросс-платформенной части ядра (A-09).
# Назначение: убедиться, что слой data и линтеры живы на GCC, не дожидаясь
# Windows-стенда. Полная сборка продукта — только через build.cmd (MSVC + Qt + OCC).
set -euo pipefail
export PATH="$PATH:/usr/local/bin:$HOME/.local/bin"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "[1/4] Конфигурация"
cmake -S . -B build/linux-gcc-debug -DCMAKE_BUILD_TYPE=Debug -DPGIB_BUILD_UI=OFF >/dev/null

echo "[2/4] Сборка"
cmake --build build/linux-gcc-debug -j"$(nproc)"

echo "[3/4] Тесты"
ctest --test-dir build/linux-gcc-debug --output-on-failure
echo
echo "[3б] Протокол верификации"
./build/linux-gcc-debug/pgib_verify_report

echo "[3в] Кадры зарождения разрушения (Э8′)"
./build/linux-gcc-debug/pgib_damage_view build/linux-gcc-debug/out/damage | sed -n '1,22p'

echo "[3г] Развитие трещины по фазовому полю (В-10)"
./build/linux-gcc-debug/pgib_crack_view build/linux-gcc-debug/out/crack | sed -n '1,20p'

echo "[4/4] Линтеры"
python3 tools/lint_layers.py
python3 tools/lint_i18n.py
python3 tools/lint_no_p7.py
python3 tools/test_linters.py
python3 tools/validate_pmat.py --self-test

echo "[4б] Валидация всей библиотеки материалов"
python3 tools/validate_pmat.py | tail -3

echo "[4в] Сценарий «добавить свой материал»"
python3 tools/new_material.py --name "Проверка шаблона" --file _check_template >/dev/null
python3 tools/validate_pmat.py materials/user/_check_template.pmat | grep -E "ПРИНЯТА|ОТКЛОНЕНА"
rm -f materials/user/_check_template.pmat

echo "ПРОВЕРОЧНАЯ СБОРКА УСПЕШНА"
