#!/usr/bin/env python3
"""lint_no_p7.py — запрет констант Приложения П7 в коде и ресурсах (Ф-11, A-14).

П7.3 ТЗ: справочная геометрия ПКГ-180x35 не может быть ни значением по умолчанию,
ни параметром генератора геометрии, ни «зашитым» размером в ядре. Источник истины —
импортированная модель (Ф-05).

Двухуровневая проверка:
  * высокоэнтропийные числа (482; 213,5; 28,5; 209) — запрещены везде, кроме
    docs/ и tests/reference/ (там они эталон приёмочного теста);
  * низкоэнтропийные числа (57; 180; 35) — запрещены только в строке с признаками
    геометрического контекста (диаметр, радиус, высота, проход, bore и т. п.),
    иначе линтер был бы бесполезен из-за ложных срабатываний.

Обход — комментарий P7-ALLOW с обоснованием в той же строке (ревью обязательно).
"""
from __future__ import annotations

# P7-ALLOW-FILE: линтер обязан содержать константы П7 — это его предмет.
import os
import pathlib
import re
import sys

ROOT = pathlib.Path(os.environ.get("PGIB_ROOT", pathlib.Path(__file__).resolve().parent.parent))

HIGH_ENTROPY = {
    "482": "нижний диаметр полусферы",
    "213.5": "радиус сферы",
    "213,5": "радиус сферы",
    "28.5": "половина расстояния между центрами",
    "28,5": "половина расстояния между центрами",
    "209": "полная высота уплотнителя",
}
LOW_ENTROPY = {"57": "расстояние между центрами", "180": "условный проход"}

GEOM_CONTEXT = re.compile(
    r"диаметр|радиус|высот|проход|толщин|перемычк|"
    r"diameter|radius|height|bore|thickness|"
    r"\bd_|\bR_|\bH_|\bD_",
    re.IGNORECASE,
)

SKIP_PREFIXES = ("docs/", ".git/", "build/", "node_modules/", "__pycache__/", "tests/reference/")
FILE_ALLOW_MARK = "P7-ALLOW-FILE"
# Каталог tests/reference исключён: это единственное место, где значения П7 законны
# (эталон для теста сверки Ф-06/П7.3, продуктом не читается).
SCAN_EXT = {".cpp", ".hpp", ".h", ".cc", ".cxx", ".py", ".json", ".txt", ".cmake", ".ini", ".qrc", ".ui"}
SCAN_NAMES = {"CMakeLists.txt", "build.cmd", "CMakePresets.json"}

NUMBER_RE = re.compile(r"(?<![\w.])(\d+[.,]\d+|\d+)(?![\w.])")
ALLOW_MARK = "P7-ALLOW"


def is_skipped(path: pathlib.Path) -> bool:
    rel = path.relative_to(ROOT).as_posix()
    return any(rel.startswith(prefix) or f"/{prefix}" in rel for prefix in SKIP_PREFIXES)


def has_file_allow(path: pathlib.Path) -> bool:
    """Файл может объявить себя исключением: маркер P7-ALLOW-FILE в первых строках.

    Так помечается сам линтер и его самотест — они обязаны содержать эти числа
    по своему смыслу. Каждое такое исключение проходит ревью.
    """
    try:
        head = path.read_text(encoding="utf-8", errors="replace").splitlines()[:20]
    except OSError:
        return False
    return any(FILE_ALLOW_MARK in line for line in head)


def should_scan(path: pathlib.Path) -> bool:
    if is_skipped(path):
        return False
    return path.suffix in SCAN_EXT or path.name in SCAN_NAMES


def main() -> int:
    violations: list[str] = []
    scanned = 0

    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or not should_scan(path):
            continue
        if has_file_allow(path):
            continue
        scanned += 1
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            continue
        for lineno, line in enumerate(lines, 1):
            if ALLOW_MARK in line:
                continue
            if line.strip().startswith(("//", "#", "*", "REM", "rem")):
                # Комментарии тоже проверяем на низкоэнтропийные числа только в
                # геометрическом контексте — иначе документация в коде шумит.
                pass
            has_context = bool(GEOM_CONTEXT.search(line))
            for token in NUMBER_RE.findall(line):
                normalized = token.replace(",", ".")
                variants = {token, normalized}
                if normalized.endswith(".0"):
                    variants.add(normalized[:-2])
                if variants & set(HIGH_ENTROPY):
                    violations.append(
                        f"{path.relative_to(ROOT)}:{lineno}: константа П7 «{token}» "
                        f"({HIGH_ENTROPY.get(normalized) or HIGH_ENTROPY.get(token)}) — "
                        f"геометрия берётся только из модели (Ф-05, П7.3)"
                    )
                elif variants & set(LOW_ENTROPY) and has_context:
                    violations.append(
                        f"{path.relative_to(ROOT)}:{lineno}: константа П7 «{token}» "
                        f"({LOW_ENTROPY.get(token) or LOW_ENTROPY.get(normalized)}) в геометрическом контексте "
                        f"— если это не П7, добавьте комментарий {ALLOW_MARK} с обоснованием"
                    )

    if violations:
        print(f"ПРОВАЛ: найдено {len(violations)} запрещённых констант Приложения П7")
        for v in violations:
            print("  - " + v)
        return 1

    print(f"Запрет констант П7: OK — проверено файлов {scanned}, нарушений нет")
    return 0


if __name__ == "__main__":
    sys.exit(main())
