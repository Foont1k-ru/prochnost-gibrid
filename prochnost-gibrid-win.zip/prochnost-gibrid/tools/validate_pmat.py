#!/usr/bin/env python3
"""validate_pmat.py — проверка карточек материалов (.pmat).

Реализует правила п. Ф-30 (валидация), соотношения п. Ф-29 (mu0 = 2·C10, K = 2/D1),
политику Ф-32 (оценка → жёлтый светофор) и Ф-86 (null → критерий не вычисляется).

Отдельно проверяется физическая согласованность «K ↔ ν ↔ G» для сверхупругих
карточек: при заданных mu0 и K вычисляется подразумеваемый коэффициент Пуассона
и сравнивается с объявленным. Расхождение — предупреждение, а не отказ: ν часто
округляют, но пользователь должен это видеть.

Код возврата: 0 — карточка принята (возможно с предупреждениями), 1 — отклонена.
Режим --self-test прогоняет встроенные случаи и проверяет, что валидатор ловит
ошибки (линтер/валидатор без самотеста — заглушка, п. 0.2).
"""
from __future__ import annotations

import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent

ALLOWED_UNITS = {
    "кг/м³", "МПа", "ГПа", "кПа", "Па", "безразмерный", "1/МПа", "1/°C", "мкм",
    "Вт/(м·°C)", "Дж/(кг·°C)", "Н/м", "кДж/м²", "Дж/м²", "кгс/см²", "мм",
}
REQUIRED_TOP = ("schemaVersion", "name", "group", "source", "reliability")
RELIABILITY = {"справочник", "стандарт", "паспорт производителя", "оценка"}
PROV_STATUS = {"документ", "производное", "оценка", "справочник"}


class Report:
    def __init__(self, name: str) -> None:
        self.name = name
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.missing: list[str] = []  # null-поля: критерий не вычисляется (Ф-86)

    def err(self, m: str) -> None:
        self.errors.append(m)

    def warn(self, m: str) -> None:
        self.warnings.append(m)

    def q(self, path: str, unit_expected: str | None = None) -> float | None:
        """Достаёт значение величины вида {value, unit} с проверкой единицы."""
        node = CUR[0]
        for part in path.split("."):
            if not isinstance(node, dict) or part not in node:
                return None
            node = node[part]
        if node is None:
            self.missing.append(path)
            return None
        # null — ЛЕГАЛЬНОЕ состояние (Ф-86): величина не задана, критерий не вычисляется.
        # Дефект 12.11.2026: свежая карточка из шаблона отклонялась за «значение должно быть
        # числом» — то есть пользователь не мог завести материал и заполнить его постепенно.
        if isinstance(node, dict) and "value" in node and node["value"] is None:
            self.missing.append(path)
            return None
        if not isinstance(node, dict) or "value" not in node or "unit" not in node:
            self.err(f"{path}: ожидается объект {{value, unit}}")
            return None
        unit = node["unit"]
        if unit not in ALLOWED_UNITS:
            self.err(f"{path}: неизвестная единица «{unit}»")
        if unit_expected and unit != unit_expected:
            self.err(f"{path}: единица «{unit}», ожидалась «{unit_expected}»")
        if not isinstance(node["value"], (int, float)):
            self.err(f"{path}: значение должно быть числом")
            return None
        return float(node["value"])


CUR: list[dict] = [{}]  # текущая карточка для rep.q(); индекс 0 всегда есть


def is_rubber_marker(card: dict) -> bool:
    """Карточка резины (для проверок, зависящих от группы)."""
    return card.get("group") == "Резины"


def validate(card: dict) -> Report:
    CUR[0] = card
    rep = Report(card.get("name", "без имени"))

    for field in REQUIRED_TOP:
        if field not in card or card[field] in (None, ""):
            rep.err(f"отсутствует обязательное поле «{field}»")
    if card.get("reliability") not in RELIABILITY and "reliability" in card:
        rep.err(f"недопустимый класс достоверности «{card.get('reliability')}»")
    if card.get("reliability") == "оценка":
        rep.warn("класс достоверности «оценка»: погрешность до ±30 %, светофор ЖЁЛТЫЙ (Ф-32)")

    rho = rep.q("density", "кг/м³")
    if rho is not None and rho <= 0:
        rep.err("плотность должна быть положительной")
    if rho is None:
        rep.warn("плотность не задана: расчёт собственного веса, инерционных и динамических "
                 "нагрузок («Удар») недоступен")

    # --- документ-основание, условия эксплуатации, твёрдость, провенанс (Ф-28) ---
    doc = card.get("document")
    if doc is not None and not (isinstance(doc, str) and doc.strip()):
        rep.err("поле «document» должно быть непустой строкой (ТУ/ГОСТ/паспорт)")

    oper = card.get("operating")
    if oper is not None:
        if not isinstance(oper, dict):
            rep.err("operating: ожидается объект")
        else:
            tmin, tmax = oper.get("temperature_min_C"), oper.get("temperature_max_C")
            for key, val in (("temperature_min_C", tmin), ("temperature_max_C", tmax)):
                if val is not None and not isinstance(val, (int, float)):
                    rep.err(f"operating.{key}: ожидается число, °C")
            if isinstance(tmin, (int, float)) and isinstance(tmax, (int, float)):
                if not (-273.15 < tmin < tmax):
                    rep.err(f"operating: требуется −273,15 < t_min ({tmin}) < t_max ({tmax})")
            medium = oper.get("medium")
            if medium is not None and not (isinstance(medium, list) and all(isinstance(m, str) for m in medium)):
                rep.err("operating.medium: ожидается список строк (рабочие среды)")

    hard = card.get("hardness")
    if hard is not None:
        if not isinstance(hard, dict):
            rep.err("hardness: ожидается объект")
        else:
            hmin, hmax = hard.get("shore_A_min"), hard.get("shore_A_max")
            for key, val in (("shore_A_min", hmin), ("shore_A_max", hmax)):
                if val is not None and not isinstance(val, (int, float)):
                    rep.err(f"hardness.{key}: ожидается число")
                elif isinstance(val, (int, float)) and not (20.0 <= val <= 100.0):
                    rep.warn(f"hardness.{key} = {val}: вне обычного диапазона твёрдости по Шору А (20…100)")
            if isinstance(hmin, (int, float)) and isinstance(hmax, (int, float)) and hmin > hmax:
                rep.err(f"hardness: shore_A_min ({hmin}) больше shore_A_max ({hmax})")
            if (is_rubber_marker(card) and hard.get("source") in (None, "")
                    and (hmin is not None or hmax is not None)):
                rep.warn("hardness: не указан источник твёрдости")

    prov = card.get("provenance")
    if prov is None:
        rep.warn("поле «provenance» отсутствует: не видно, какие величины взяты из документа, "
                 "а какие получены оценкой (Ф-28)")
    elif not isinstance(prov, list):
        rep.err("provenance: ожидается список записей {field, status, source}")
    else:
        estimated, derived = [], []
        for i, entry in enumerate(prov):
            if not isinstance(entry, dict):
                rep.err(f"provenance[{i}]: ожидается объект")
                continue
            field, status = entry.get("field"), entry.get("status")
            if not (isinstance(field, str) and field.strip()):
                rep.err(f"provenance[{i}]: не указано поле «field»")
            if status not in PROV_STATUS:
                rep.err(f"provenance[{i}]: недопустимый статус «{status}» (допустимо: "
                        + ", ".join(sorted(PROV_STATUS)) + ")")
            elif status == "оценка":
                estimated.append(field or "?")
            elif status == "производное":
                derived.append(field or "?")
        if estimated:
            rep.warn("поля-оценки: " + ", ".join(estimated)
                     + " — погрешность до ±30 %, светофор ЖЁЛТЫЙ, требуется паспорт/испытание (Ф-32)")
        if derived:
            rep.warn("производные величины: " + ", ".join(derived)
                     + " — получены пересчётом, а не измерением")

    # --- линейная упругость (Ф-30) ---
    E = rep.q("elastic.E", "МПа")
    nu = rep.q("elastic.nu")
    if E is not None and E <= 0:
        rep.err("модуль упругости E должен быть > 0")
    if nu is not None:
        if not (-1.0 < nu < 0.5):
            rep.err(f"коэффициент Пуассона ν = {nu} вне диапазона (-1; 0,5)")
        if nu > 0.49:
            rep.warn(f"ν = {nu} > 0,49: обязательна смешанная u/P-формулировка, Tet4 запрещён (Ф-25, п. 20.5)")
    G = rep.q("elastic.G")
    K = rep.q("elastic.K")
    if E is not None and nu is not None and nu < 0.5:
        K_from = E / (3.0 * (1.0 - 2.0 * nu))
        G_from = E / (2.0 * (1.0 + nu))
        if K is not None and K > 0 and abs(K - K_from) / K > 0.10:
            rep.warn(f"объявленный K = {K:g} МПа расходится с E/(3(1-2ν)) = {K_from:g} МПа более чем на 10 %")
        if G is not None and G > 0 and abs(G - G_from) / G > 0.10:
            rep.warn(f"объявленный G = {G:g} МПа расходится с E/(2(1+ν)) = {G_from:g} МПа более чем на 10 %")

    sigma = rep.q("strength.sigma_yield", "МПа")
    if sigma is not None and E is not None and sigma > E / 10.0:
        rep.warn(f"предел текучести {sigma:g} МПа выглядит завышенным при E = {E:g} МПа")

    # --- сверхупругость (Ф-29) ---
    hyper = card.get("hyperelastic")
    if isinstance(hyper, dict):
        c10 = rep.q("hyperelastic.C10", "МПа")
        mu0 = rep.q("hyperelastic.mu0", "МПа")
        D1 = rep.q("hyperelastic.D1")
        Kh = rep.q("hyperelastic.K", "МПа")
        nuh = rep.q("hyperelastic.poisson")

        if c10 is not None:
            if c10 <= 0:
                rep.err("C10 должен быть > 0 (иначе материал неустойчив при малых деформациях)")
            if mu0 is not None and abs(mu0 - 2.0 * c10) / (2.0 * c10) > 0.01:
                rep.err(f"нарушено соотношение mu0 = 2·C10: mu0 = {mu0:g}, 2·C10 = {2.0 * c10:g} (Ф-29)")
            if mu0 is None:
                rep.warn(f"mu0 не задан; должен быть 2·C10 = {2.0 * c10:g} МПа")
        if Kh is not None and D1:
            if abs(Kh - 2.0 / D1) / Kh > 0.01:
                rep.err(f"нарушено соотношение K = 2/D1: K = {Kh:g}, 2/D1 = {2.0 / D1:g} (Ф-29)")
        if D1 is not None and D1 < 0:
            rep.err("D1 должен быть положительным (сжимаемость)")
        # Физическая согласованность ν ↔ (K, G=mu0/2 для нео-Гука)
        if nuh is not None and Kh is not None and mu0 is not None and Kh > 0:
            # Для нео-Гука модуль сдвига G = mu0 = 2·C10 (Ф-29). Здесь ранее стояло
            # mu0/2 — вдвое заниженный G давал ложные предупреждения о несогласованности
            # и маскировал настоящие (дефект найден 12.11.2026 при сборке библиотеки).
            G_eq = mu0
            nu_impl = (3.0 * Kh - 2.0 * G_eq) / (2.0 * (3.0 * Kh + G_eq))
            gap_decl = 0.5 - nuh
            gap_impl = 0.5 - nu_impl
            if gap_decl > 0 and abs(gap_impl - gap_decl) / gap_decl > 0.05:
                rep.warn(
                    f"ν = {nuh} не согласован с парой K = {Kh:g} МПа и mu0 = {mu0:g} МПа: "
                    f"подразумеваемое ν = {nu_impl:.5f} (расхождение по «зазору несжимаемости» "
                    f"{abs(gap_impl - gap_decl) / gap_decl * 100:.0f} %). Это не ошибка расчёта, "
                    f"но объявленное ν и D1 дают разную степень сжимаемости — уточнить по паспорту"
                )
        if nuh is not None and not (-1.0 < nuh < 0.5):
            rep.err(f"коэффициент Пуассона сверхупругой модели ν = {nuh} вне диапазона (-1; 0,5)")
        model = hyper.get("model")
        if model is None:
            rep.err("не задана модель сверхупругости")
        elif model not in {"NeoHookean", "MooneyRivlin", "Yeoh", "Ogden", "ArrudaBoyce", "Gent"}:
            rep.err(f"неизвестная модель сверхупругости «{model}»")
        if model == "Yeoh" and c10 is not None and card.get("hyperelastic", {}).get("C20") is None:
            rep.warn("для модели Йео желательно задать C20 и C30")

    # --- разрушение (Ф-52, Ф-86) ---
    # Проверки ниже относятся к резине: для металлов критерии другие (ПС-6),
    # и предупреждать сталь про «энергию раздира» было бы шумом.
    fail = card.get("failure")
    is_rubber = card.get("group") == "Резины"
    if isinstance(fail, dict) and is_rubber:
        for key in ("lambda_break", "W_c", "T_c"):
            if fail.get(key) is None:
                rep.missing.append(f"failure.{key}")
        if fail.get("lambda_break") is None:
            rep.warn("lambda_break не задан: критерий ПС-1 не вычисляется (нужно испытание по ГОСТ 270-75), светофор ЖЁЛТЫЙ")
        if fail.get("T_c") is None:
            rep.warn("энергия раздира T_c не задана: критерии ПС-1/ПС-4 не вычисляются (ГОСТ 262-93)")
        fatigue = fail.get("fatigue") or {}
        if any(fatigue.get(k) is None for k in ("T0", "C", "m")):
            rep.warn("параметры усталости T0, C, m не заданы: ресурс по циклике (ПС-4, Ф-48) не вычисляется")
        bond = fail.get("bond") or {}
        if any(bond.get(k) is None for k in ("G_Ic", "G_IIc", "tau_bond")):
            rep.warn("параметры связи G_Ic, G_IIc, tau_bond не заданы: отслоение (ПС-2, Ф-47) не вычисляется")

    if isinstance(fail, dict) and not is_rubber:
        for key in ("lambda_break", "W_c", "T_c"):
            if fail.get(key) is None:
                continue
        if not (card.get("strength") or {}).get("sigma_ultimate"):
            rep.warn("нет предела прочности: для ПС-6 (клыки) потребуется паспорт")
        if not ((card.get("plasticity") or {}).get("true_stress_strain")):
            rep.warn("кривая упрочнения не задана: пластические деформации клыков (ПС-6) не вычисляются")

    # --- пластичность ---
    plast = card.get("plasticity")
    if isinstance(plast, dict):
        curve = plast.get("true_stress_strain")
        if isinstance(curve, list):
            if curve:
                for i, point in enumerate(curve):
                    if not (isinstance(point, list) and len(point) == 2):
                        rep.err(f"plasticity.true_stress_strain[{i}]: ожидается пара [деформация, напряжение]")
    return rep


def print_report(rep: Report, path: pathlib.Path | None = None) -> bool:
    head = f"Карточка: {rep.name}" + (f"  ({path.name})" if path else "")
    print(head)
    if rep.errors:
        print(f"  ОТКЛОНЕНА, ошибок: {len(rep.errors)}")
        for e in rep.errors:
            print("    ! " + e)
    if rep.warnings:
        print(f"  предупреждений: {len(rep.warnings)}")
        for w in rep.warnings:
            print("    - " + w)
    if rep.missing:
        print(f"  поля null (критерий не вычисляется, Ф-86): {len(set(rep.missing))}")
    if not rep.errors:
        print("  ПРИНЯТА" + (" (с предупреждениями)" if rep.warnings else ""))
    return not rep.errors


def self_test() -> int:
    good = {
        "schemaVersion": 1, "name": "тест", "group": "Резины", "source": "тест", "reliability": "паспорт производителя",
        "density": {"value": 1350, "unit": "кг/м³"},
        "hyperelastic": {"model": "Yeoh", "C10": {"value": 1.0, "unit": "МПа"},
                         "mu0": {"value": 2.0, "unit": "МПа"}, "K": {"value": 2000.0, "unit": "МПа"},
                         "D1": {"value": 0.001, "unit": "1/МПа"}, "poisson": {"value": 0.4995, "unit": "безразмерный"}},
    }
    cases: list[tuple[str, dict, bool]] = [
        ("корректная карточка", good, True),
        ("нет источника", {k: v for k, v in good.items() if k != "source"}, False),
        ("E < 0", {**good, "elastic": {"E": {"value": -5, "unit": "МПа"}}}, False),
        ("ν = 0,7", {**good, "elastic": {"E": {"value": 100, "unit": "МПа"}, "nu": {"value": 0.7, "unit": "безразмерный"}}}, False),
        ("mu0 ≠ 2·C10", {**good, "hyperelastic": {**good["hyperelastic"], "mu0": {"value": 3.0, "unit": "МПа"}}}, False),
        ("K ≠ 2/D1", {**good, "hyperelastic": {**good["hyperelastic"], "D1": {"value": 0.0005, "unit": "1/МПа"}}}, False),
        ("неизвестная единица", {**good, "density": {"value": 1350, "unit": "фунт/фут³"}}, False),
        ("оценка → жёлтый", {**good, "reliability": "оценка"}, True),
        # --- проверки, добавленные 12.11.2026 вместе с блоками document/operating/hardness/provenance ---
        ("недопустимый статус провенанса",
         {**good, "provenance": [{"field": "density", "status": "вроде так"}]}, False),
        ("провенанс без имени поля",
         {**good, "provenance": [{"status": "оценка"}]}, False),
        ("оценка в провенансе → жёлтый",
         {**good, "provenance": [{"field": "density", "status": "оценка", "source": "x"}]}, True),
        ("t_min > t_max", {**good, "operating": {"temperature_min_C": 120, "temperature_max_C": -10}}, False),
        ("твёрдость min > max", {**good, "hardness": {"shore_A_min": 80, "shore_A_max": 60}}, False),
        ("твёрдость 120 Шор А — подозрительно",
         {**good, "hardness": {"shore_A_min": 60, "shore_A_max": 120, "source": "т"}}, True),
        ("нет плотности → предупреждение",
         {k: v for k, v in good.items() if k != "density"}, True),
        # Шаблон нового материала: все величины null. Обязан ПРОЙТИ (Ф-86), иначе
        # пользователь не может завести свой материал и заполнять его постепенно.
        ("пустой шаблон (все null) → принять",
         {"schemaVersion": 1, "name": "мой материал", "group": "Резины",
          "source": "паспорт № ___", "reliability": "паспорт производителя",
          "density": {"value": None, "unit": "кг/м³"},
          "hyperelastic": {"model": "NeoHookean",
                           "C10": {"value": None, "unit": "МПа"},
                           "mu0": {"value": None, "unit": "МПа"},
                           "K": {"value": None, "unit": "МПа"}}}, True),
    ]
    failures = 0
    print("=== Самотест валидатора карточек материала ===")
    for name, card, should_pass in cases:
        rep = validate(card)
        CUR[0] = {}
        ok = (not rep.errors) == should_pass
        print(f"[{'  OK  ' if ok else ' ПРОВАЛ'}] {name}: ожидалось {'принять' if should_pass else 'отклонить'}, "
              f"получено {'принять' if not rep.errors else 'отклонить'}")
        if not ok:
            failures += 1
            for e in rep.errors:
                print("       " + e)
    print(f"\nИТОГ самотеста: {'пройден' if failures == 0 else f'ПРОВАЛЕН ({failures})'}")
    return 0 if failures == 0 else 1


def main(argv: list[str]) -> int:
    if "--self-test" in argv:
        return self_test()

    library = ROOT / "materials" / "library"
    paths = [pathlib.Path(a) for a in argv[1:]] or sorted(library.rglob("*.pmat"))
    if not paths:
        print("ПРОВАЛ: не найдено ни одной карточки .pmat")
        return 1

    CUR.append({})
    all_ok = True
    print(f"Проверка карточек материалов: {len(paths)} шт.\n")
    for path in paths:
        try:
            card = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            print(f"Файл {path.name}: не читается ({exc})")
            all_ok = False
            continue
        rep = validate(card)
        all_ok &= print_report(rep, path)
        print()
    print(f"ИТОГ: {'все карточки приняты' if all_ok else 'есть отклонённые карточки'}")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
