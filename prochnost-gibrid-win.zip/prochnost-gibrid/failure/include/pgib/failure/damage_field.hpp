// pgib/failure/damage_field.hpp — поле повреждения по кадрам нагружения и
// субшаговая локализация момента зарождения разрушения (Э8′).
//
// Отвечает на заказ от 12.11.2026: нужно ВИДЕТЬ, как тело начинает рваться, и
// видеть именно МОМЕНТ зарождения, а не «на этом шаге уже порвалось».
//
// Что здесь есть:
//   * FieldFrame — кадр: для каждого элемента λ_max, W, гидростатическое
//     растяжение, D по каждому механизму отдельно и итоговый D (Ф-49);
//   * FieldHistory — D = max по истории нагружения (индикатор не «гаснет» при
//     разгрузке, п. Ф-49);
//   * find_onset() — бисекция по параметру нагружения: момент, когда D достигает
//     1, находится с заданной точностью, а не «попал в узел сетки шагов»;
//   * раздельные счётчики превышений по механизмам: ПС-1 по растяжению,
//     ПС-1 по энергии, ПС-2 по кавитации подписываются в отчёте отдельно
//     (требование Э8), а не сливаются в одно «разрушение: да».
//
// Чего здесь нет (объявлено, а не спрятано):
//   * геометрии трещины (фазовое поле / CZM) — В-10, отдельный шаг;
//   * удаления элементов — запрещено в неявном ядре (Ф-50);
//   * усталости ПС-4 и энергии раздира Лейка–Томаса (A-19).

#pragma once

#include <array>
#include <cmath>
#include <cstddef>
#include <limits>
#include <vector>

#include "pgib/failure/damage.hpp"

namespace pgib::failure {

// Индекс критерия в массивах-счётчиках: 1 — ПС-1 растяжение, 2 — ПС-1 энергия,
// 3 — ПС-2 кавитация. Ноль не используется (Criterion::None).
constexpr int kMechanismCount = 4;
inline int mechanism_index(Criterion c) { return static_cast<int>(c); }

struct FieldPoint {
    int element = -1;
    std::array<double, 3> centroid{0.0, 0.0, 0.0};
    Sample sample{};
    Evaluation evaluation{};
    double D_history = 0.0;  // максимум D по истории нагружения (Ф-49)
};

struct FieldFrame {
    int index = 0;
    double load = 0.0;       // параметр нагружения: удлинение λ или перемещение
    std::vector<FieldPoint> points;
    double D_max = 0.0;
    int element_D_max = -1;
    Criterion governing = Criterion::None;       // механизм, дающий D_max
    double value_governing = 0.0;                // значение величины этого механизма
    double threshold_governing = 0.0;            // его порог
    std::array<int, kMechanismCount> over{};     // сколько точек превысили порог по механизму
    std::array<double, kMechanismCount> peak{};  // максимум D по механизму
    bool onset = false;                          // кадр соответствует зарождению
};

// Сборка кадра из «сырых» замеров. samples[i] отвечает centroids[i].
inline FieldFrame make_frame(int index, double load, const Criteria& crit,
                             const std::vector<Sample>& samples,
                             const std::vector<std::array<double, 3>>& centroids) {
    FieldFrame f;
    f.index = index;
    f.load = load;
    f.points.resize(samples.size());
    for (std::size_t i = 0; i < samples.size(); ++i) {
        FieldPoint& p = f.points[i];
        p.element = static_cast<int>(i);
        p.centroid = i < centroids.size() ? centroids[i] : std::array<double, 3>{0.0, 0.0, 0.0};
        p.sample = samples[i];
        p.evaluation = evaluate(crit, samples[i]);
        p.D_history = p.evaluation.D;

        // Счётчики ведутся ПО КАЖДОМУ механизму отдельно, а не только по тому,
        // который сейчас лидирует. Дефект 12.11.2026: раньше peak[] заполнялся
        // лишь для механизма-лидера, и в кадре, где лидирует растяжение, вклад
        // кавитации выглядел нулевым — в отчёте это была бы ложь «ПС-2 не достигнут».
        const std::array<double, kMechanismCount> d_mech{
            {0.0, p.evaluation.D_lambda, p.evaluation.D_energy, p.evaluation.D_cavitation}};
        for (int m = 1; m < kMechanismCount; ++m) {
            const double d = d_mech[static_cast<std::size_t>(m)];
            if (d > 0.0) f.peak[static_cast<std::size_t>(m)] = std::max(f.peak[static_cast<std::size_t>(m)], d);
            if (d >= 1.0) ++f.over[static_cast<std::size_t>(m)];
        }

        if (p.evaluation.D > f.D_max) {
            f.D_max = p.evaluation.D;
            f.element_D_max = p.element;
            f.governing = p.evaluation.governing;
            const auto& s = p.sample;
            switch (p.evaluation.governing) {
                case Criterion::Psi1_Stretch: f.value_governing = s.lambda_max; f.threshold_governing = crit.lambda_break; break;
                case Criterion::Psi1_Energy: f.value_governing = s.W; f.threshold_governing = crit.W_c; break;
                case Criterion::Psi2_Cavitation:
                    f.value_governing = s.hydrostatic_tension;
                    f.threshold_governing = crit.cavitation_threshold;
                    break;
                default: break;
            }
        }
    }
    f.onset = f.D_max >= 1.0;
    return f;
}

// История: D в каждой точке — невозрастающая величина (накопленное повреждение).
// Без этого при разгрузке картинка «выздоравливающего» материала обманула бы
// пользователя: трещина уже зародилась, обратно она не зарастает.
class FieldHistory {
public:
    void update(FieldFrame& f) {
        if (history_.size() != f.points.size()) history_.assign(f.points.size(), 0.0);
        for (std::size_t i = 0; i < f.points.size(); ++i) {
            history_[i] = std::max(history_[i], f.points[i].evaluation.D);
            f.points[i].D_history = history_[i];
        }
        if (D_peak_ < f.D_max) D_peak_ = f.D_max;
    }
    [[nodiscard]] double D_peak() const { return D_peak_; }
    [[nodiscard]] const std::vector<double>& history() const { return history_; }

private:
    std::vector<double> history_;
    double D_peak_ = 0.0;
};

// ---------------------------------------------------------------------------
// Локализация момента зарождения.
// solve(load) должен привести модель к нагрузке load и вернуть максимальный D.
// Предусловие: D(lo) < 1, D(hi) ≥ 1 (скобка уже найдена основным шагом).
// Постусловие: |hi − lo| ≤ tol, D(load) ≥ 1 и D(load − tol) < 1 — то есть момент
// зарождения зажат в интервал шириной tol по параметру нагружения.
// ---------------------------------------------------------------------------
struct OnsetResult {
    bool found = false;
    double load = 0.0;          // момент зарождения (верхняя граница скобки)
    double D = 0.0;             // D в найденной точке (≥ 1)
    int iterations = 0;
    double width = 0.0;         // достигнутая ширина скобки
};

template <class SolveFn>
OnsetResult find_onset(double lo, double hi, SolveFn&& solve, double tol = 1e-3, int max_iter = 60) {
    OnsetResult r;
    if (!(hi > lo) || !(tol > 0.0)) return r;

    const double d_lo = solve(lo);
    if (d_lo >= 1.0) {  // зарождение уже слева от скобки — искать нечего
        r.found = true;
        r.load = lo;
        r.D = d_lo;
        r.width = 0.0;
        return r;
    }
    double d_hi = solve(hi);
    if (d_hi < 1.0) return r;  // зарождения в скобке нет

    for (int it = 0; it < max_iter; ++it) {
        ++r.iterations;
        if (hi - lo <= tol) break;
        const double mid = 0.5 * (lo + hi);
        const double d_mid = solve(mid);
        if (d_mid >= 1.0) {
            hi = mid;
            d_hi = d_mid;
        } else {
            lo = mid;
        }
    }
    r.found = true;
    r.load = hi;
    r.D = d_hi;
    r.width = hi - lo;
    return r;
}

// Оценка W_c по разрыву при одноосном растяжении (нео-Гук):
// W = C10·(λ² + 2/λ − 3) при λ = λ_break.
// Это ОЦЕНКА (Ф-32): она согласует энергетический критерий с деформационным,
// но не заменяет испытание по ГОСТ 262-93.
inline double Wc_from_uniaxial_break(double C10, double lambda_break) {
    if (C10 <= 0.0 || lambda_break <= 0.0) return 0.0;
    return C10 * (lambda_break * lambda_break + 2.0 / lambda_break - 3.0);
}

// Порог кавитации при одноосном растяжении: решение λ² − 1/λ = 3·p_c/μ,
// μ = 2·C10. Нужен для проверки, что найденный момент совпадает с аналитикой.
inline double uniaxial_stretch_for_cavitation(double C10, double p_c) {
    if (C10 <= 0.0 || p_c <= 0.0) return std::numeric_limits<double>::quiet_NaN();
    const double target = 3.0 * p_c / (2.0 * C10);
    double lo = 1.0, hi = 10.0;
    for (int i = 0; i < 200; ++i) {
        const double mid = 0.5 * (lo + hi);
        if (mid * mid - 1.0 / mid < target) lo = mid; else hi = mid;
    }
    return 0.5 * (lo + hi);
}

}  // namespace pgib::failure
