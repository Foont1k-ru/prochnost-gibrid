// pgib/failure/damage.hpp — индикатор повреждения и критерии предельных состояний.
//
// Закрывает (первый шаг, проверяемый на аналитике):
//   ПС-1 / Ф-45 — разрыв резины: критическое главное растяжение λ_break и
//                 критическая плотность энергии W_c как локальные критерии;
//   ПС-2 / Ф-46 — кавитация: порог по гидростатическому растяжению (≈ 5·C10);
//   Ф-49 режим 1 — поле повреждения D = max по истории, БЕЗ удаления элементов
//                 (обязательный режим для отчётных расчётов);
//   Ф-51 — журнал событий (шаг/нагрузка/критерий/значение).
//
// ЧЕГО ЗДЕСЬ НЕТ (и это объявлено, а не спрятано):
//   * энергия раздира Лейка–Томаса G = k_g·W·a и усталость ПС-4 — отдельный шаг;
//   * CZM-отслоение и фазовое поле (В-10) — отдельный шаг;
//   * удаление элементов — запрещено в неявном ядре (Ф-50), реализуется только
//     в явном (Э6) и только с регуляризацией.

#pragma once

#include <cmath>
#include <cstddef>
#include <string>
#include <vector>

namespace pgib::failure {

enum class Criterion {
    None = 0,
    Psi1_Stretch = 1,     // ПС-1: λ_max ≥ λ_break
    Psi1_Energy = 2,      // ПС-1: W ≥ W_c
    Psi2_Cavitation = 3,  // ПС-2: гидростатическое растяжение ≥ порога
};

inline const char* criterion_name(Criterion c) {
    switch (c) {
        case Criterion::Psi1_Stretch: return "ПС-1: разрыв резины по главному растяжению";
        case Criterion::Psi1_Energy: return "ПС-1: разрыв резины по плотности энергии";
        case Criterion::Psi2_Cavitation: return "ПС-2: кавитация по гидростатическому растяжению";
        default: return "нет";
    }
}

// Пороговые значения. Незаданный порог (null в карточке материала, Ф-86)
// означает: критерий НЕ вычисляется, светофор достоверности жёлтый.
struct Criteria {
    bool has_lambda_break = false;
    double lambda_break = 0.0;

    bool has_Wc = false;
    double W_c = 0.0;  // МПа

    bool has_cavitation = false;
    double cavitation_threshold = 0.0;  // МПа, ≈ 5·C10

    // Приближение 5·C10 (Ф-46) — только как оценка, требует пометки в паспорте.
    static Criteria from_C10_estimate(double C10, bool estimate = true) {
        Criteria c;
        c.has_cavitation = true;
        c.cavitation_threshold = 5.0 * C10;
        (void)estimate;
        return c;
    }
};

struct Sample {
    double lambda_max = 1.0;             // наибольшее главное растяжение
    double W = 0.0;                      // плотность энергии деформации, МПа
    double hydrostatic_tension = 0.0;    // −tr(σ)/3, МПа (положительно при растяжении)
};

struct Evaluation {
    double D_lambda = 0.0;
    double D_energy = 0.0;
    double D_cavitation = 0.0;
    double D = 0.0;                 // итоговый индикатор 0…1 (может превысить 1)
    Criterion governing = Criterion::None;
    bool criterion_active = false;  // превышен хотя бы один порог
};

// Оценка в точке. D = max по доступным критериям (энергетический критерий
// считается только при наличии W_c, иначе он не «ноль», а «не вычисляется»).
inline Evaluation evaluate(const Criteria& crit, const Sample& s) {
    Evaluation ev;
    if (crit.has_lambda_break && crit.lambda_break > 1.0) {
        // D нормируется по УДЛИНЕНИЮ, а не по растяжению: D = (λ−1)/(λ_break−1).
        // Дефект, найденный 12.11.2026 при построении кадров: при λ_max/λ_break
        // ненагруженная деталь (λ = 1) показывала D = 1/2,6 = 0,38, то есть
        // «повреждена на 38 %» прямо из сборки. Условие зарождения D ≥ 1 при этом
        // не меняется (D = 1 ⟺ λ_max = λ_break), меняется только начало отсчёта,
        // и цветовая карта перестаёт врать.
        ev.D_lambda = (s.lambda_max - 1.0) / (crit.lambda_break - 1.0);
        if (ev.D_lambda > ev.D) { ev.D = ev.D_lambda; ev.governing = Criterion::Psi1_Stretch; }
    }
    if (crit.has_Wc && crit.W_c > 0.0) {
        ev.D_energy = s.W / crit.W_c;
        if (ev.D_energy > ev.D) { ev.D = ev.D_energy; ev.governing = Criterion::Psi1_Energy; }
    }
    if (crit.has_cavitation && crit.cavitation_threshold > 0.0 && s.hydrostatic_tension > 0.0) {
        ev.D_cavitation = s.hydrostatic_tension / crit.cavitation_threshold;
        if (ev.D_cavitation > ev.D) { ev.D = ev.D_cavitation; ev.governing = Criterion::Psi2_Cavitation; }
    }
    ev.criterion_active = ev.D >= 1.0;
    return ev;
}

struct Event {
    int step = 0;
    double load = 0.0;         // параметр нагружения (перемещение, давление)
    Criterion criterion = Criterion::None;
    double value = 0.0;        // фактическое значение
    double threshold = 0.0;    // порог
};

// Отслеживание повреждения по истории нагружения (Ф-49, режим «индикатор»).
// Событие записывается один раз при первом достижении порога — как в журнале
// событий, который потом попадает в отчёт и на таймлайн (Ф-51, Ф-65).
class Tracker {
public:
    explicit Tracker(Criteria crit) : criteria_(crit) {}

    struct Update {
        double D = 0.0;
        bool new_event = false;
        Event event{};
    };

    Update update(int step, double load, const Sample& s) {
        const Evaluation ev = evaluate(criteria_, s);
        Update out;
        out.D = ev.D;
        if (ev.D > D_history_) D_history_ = ev.D;

        if (ev.criterion_active && ev.governing != last_recorded_) {
            Event e;
            e.step = step;
            e.load = load;
            e.criterion = ev.governing;
            switch (ev.governing) {
                case Criterion::Psi1_Stretch: e.value = s.lambda_max; e.threshold = criteria_.lambda_break; break;
                case Criterion::Psi1_Energy: e.value = s.W; e.threshold = criteria_.W_c; break;
                case Criterion::Psi2_Cavitation:
                    e.value = s.hydrostatic_tension;
                    e.threshold = criteria_.cavitation_threshold;
                    break;
                default: break;
            }
            events_.push_back(e);
            last_recorded_ = ev.governing;
            out.new_event = true;
            out.event = e;
        }
        return out;
    }

    [[nodiscard]] double D_history() const { return D_history_; }
    [[nodiscard]] const std::vector<Event>& events() const { return events_; }
    [[nodiscard]] const Criteria& criteria() const { return criteria_; }
    [[nodiscard]] bool failure_occurred() const { return D_history_ >= 1.0; }

private:
    Criteria criteria_;
    double D_history_ = 0.0;
    Criterion last_recorded_ = Criterion::None;
    std::vector<Event> events_;
};

}  // namespace pgib::failure
